# InBatch Report - Dockerized

## Quick Start

```bash
cd inbatch-report
docker compose up -d --build
```

Wait for build, then seed:
```bash
docker compose exec server node seed.js
```

Open: http://localhost:4500

## Demo
- admin / admin123
- user / user123

## Stop
```bash
docker compose down
```

## Clean all data
```bash
docker compose down -v
```
