export async function renderReport(batchNumber) {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="app-layout">
      ${renderNavbar('report')}
      <div class="main-content">
        <div class="toolbar">
          <button id="btnNewBatch" class="btn-toolbar">New Batch</button>
          <button id="btnRefresh" class="btn-toolbar">Refresh</button>
          <div class="batch-selector"><label>Batch:</label><select id="batchSelect"><option value="">-- Select Batch --</option></select></div>
        </div>
        <div class="report-header"><h1>Enhanced Revenue Batch Control Report</h1></div>
        <div class="summary-panel" id="summaryPanel"><div class="summary-placeholder">Please select a batch to view the report</div></div>
        <div class="detail-section" id="detailSection" style="display:none;">
          <div class="section-header"><h3>Batch Entries</h3><div class="section-actions"><button id="btnExportPDF" class="btn-secondary btn-sm">Export PDF</button><button id="btnAddEntry" class="btn-primary btn-sm">Add Entry</button></div></div>
          <div class="table-wrapper">
            <table class="detail-table" id="detailTable"><thead><tr><th>Constituent Name</th><th>Constituent Lookup ID</th><th>Date</th><th>Revenue Type</th><th>Amount</th><th>Payment Method</th><th>Appeal</th><th>Designation / Event</th><th></th></tr></thead><tbody></tbody></table>
          </div>
          <div class="footer-info"><span id="footerDate"></span><span>Prepared by: BLACKBAUD\Ba</span><span>Page 1 of 1</span></div>
        </div>
      </div>
    </div>
    <div class="modal" id="batchModal"><div class="modal-content"><div class="modal-header"><h3>Create New Batch</h3><button class="modal-close" id="closeBatchModal">&times;</button></div>
      <form id="batchForm">
        <div class="form-row"><label>Batch Number</label><input type="text" id="newBatchNumber" required /></div>
        <div class="form-row"><label>Status</label><select id="newBatchStatus"><option>Open</option><option>Committed</option><option>Pending</option></select></div>
        <div class="form-row"><label>Owner</label><input type="text" id="newBatchOwner" /></div>
        <div class="form-row"><label>Projected #</label><input type="number" id="newProjectedCount" value="0" /></div>
        <div class="form-row"><label>Projected Total ($)</label><input type="number" step="0.01" id="newProjectedTotal" value="0" /></div>
        <div class="form-actions"><button type="submit" class="btn-primary">Create</button><button type="button" class="btn-secondary" id="cancelBatchModal">Cancel</button></div>
      </form>
    </div></div>
    <div class="modal" id="entryModal"><div class="modal-content"><div class="modal-header"><h3>Add Entry</h3><button class="modal-close" id="closeEntryModal">&times;</button></div>
      <form id="entryForm">
        <div class="form-row"><label>Constituent Name</label><input type="text" id="entryName" required /></div>
        <div class="form-row"><label>Lookup ID</label><input type="text" id="entryLookupId" required /></div>
        <div class="form-row"><label>Date</label><input type="date" id="entryDate" required /></div>
        <div class="form-row"><label>Revenue Type</label><select id="entryRevenueType"><option>Payment (donation)</option><option>Pledge</option><option>Recurring Gift</option><option>MG Claim</option></select></div>
        <div class="form-row"><label>Amount ($)</label><input type="number" step="0.01" id="entryAmount" required /></div>
        <div class="form-row"><label>Payment Method</label><select id="entryMethod"><option>Check</option><option>Cash</option><option>Credit Card</option><option>Wire Transfer</option></select></div>
        <div class="form-row"><label>Appeal</label><input type="text" id="entryAppeal" value="NEWSLETTER" /></div>
        <div class="form-row"><label>Designation / Event</label><input type="text" id="entryDesignation" value="Library Fund" /></div>
        <div class="form-actions"><button type="submit" class="btn-primary">Add Entry</button><button type="button" class="btn-secondary" id="cancelEntryModal">Cancel</button></div>
      </form>
    </div></div>
  `;
  bindNav(); await loadBatchList(batchNumber); bindReportEvents();
}
function renderNavbar(active) {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  return `<nav class="sidebar"><div class="sidebar-logo">📋 InBatch</div><ul class="sidebar-menu">
    <li><a href="#/dashboard" class="${active === 'dashboard' ? 'active' : ''}">📊 Dashboard</a></li>
    <li><a href="#/report" class="${active === 'report' ? 'active' : ''}">📋 Batch Report</a></li>
  </ul><div class="sidebar-footer"><div class="user-info"><div class="user-name">${user.fullName || user.username}</div><div class="user-role">${user.role}</div></div><button id="logoutBtn" class="btn-logout">Logout</button></div></nav>`;
}
function bindNav() {
  document.getElementById('logoutBtn')?.addEventListener('click', () => { localStorage.removeItem('token'); localStorage.removeItem('user'); window.location.hash = '#/login'; });
}
let currentBatch = null, batches = [];
async function loadBatchList(preselect) {
  const { api } = await import('../api.js');
  batches = await api.getBatches();
  const select = document.getElementById('batchSelect');
  select.innerHTML = '<option value="">-- Select Batch --</option>' + batches.map(b => `<option value="${b.batchNumber}">Batch ${b.batchNumber} - ${b.status}</option>`).join('');
  if (preselect) { select.value = preselect; select.dispatchEvent(new Event('change')); }
}
function bindReportEvents() {
  document.getElementById('batchSelect').addEventListener('change', loadBatch);
  document.getElementById('btnRefresh').addEventListener('click', () => loadBatchList());
  document.getElementById('btnNewBatch').addEventListener('click', () => openModal('batchModal'));
  document.getElementById('closeBatchModal').addEventListener('click', () => closeModal('batchModal'));
  document.getElementById('cancelBatchModal').addEventListener('click', () => closeModal('batchModal'));
  document.getElementById('batchForm').addEventListener('submit', createBatch);
  document.getElementById('btnAddEntry').addEventListener('click', () => openModal('entryModal'));
  document.getElementById('btnExportPDF').addEventListener('click', exportPDF);
  document.getElementById('closeEntryModal').addEventListener('click', () => closeModal('entryModal'));
  document.getElementById('cancelEntryModal').addEventListener('click', () => closeModal('entryModal'));
  document.getElementById('entryForm').addEventListener('submit', addEntry);
}
function openModal(id) { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }
function fmt$(n) { return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n || 0); }
function fmtD(d) { if (!d) return ''; const x = new Date(d); return (x.getMonth()+1)+'/'+x.getDate()+'/'+x.getFullYear(); }
async function loadBatch(e) {
  const num = e?.target?.value || document.getElementById('batchSelect').value;
  if (!num) { document.getElementById('summaryPanel').innerHTML = '<div class="summary-placeholder">Please select a batch to view the report</div>'; document.getElementById('detailSection').style.display = 'none'; return; }
  const { api } = await import('../api.js'); currentBatch = await api.getBatch(num);
  renderSummary(currentBatch); renderEntries(currentBatch.entries); document.getElementById('detailSection').style.display = 'block';
}
function renderSummary(batch) {
  document.getElementById('summaryPanel').innerHTML = `<div class="summary-grid"><div class="summary-col">
    <div class="summary-row"><span class="label">Batch number:</span><span class="value">${batch.batchNumber}</span></div>
    <div class="summary-row"><span class="label">Status:</span><span class="value">${batch.status}</span></div>
    <div class="summary-row"><span class="label">Owner:</span><span class="value">${batch.owner||'-'}</span></div>
    <div class="summary-row"><span class="label">Exception batch number:</span><span class="value">${batch.exceptionBatchNumber||''}</span></div></div><div class="summary-col">
    <div class="summary-row"><span class="label">Projected #:</span><span class="value">${batch.projectedCount||0}</span></div>
    <div class="summary-row"><span class="label">Committed #:</span><span class="value">${batch.committedCount||0}</span></div>
    <div class="summary-row"><span class="label">Payments:</span><span class="value">${batch.payments||0}</span></div>
    <div class="summary-row"><span class="label">Pledges:</span><span class="value">${batch.pledges||0}</span></div>
    <div class="summary-row"><span class="label">Recurring gifts:</span><span class="value">${batch.recurringGifts||0}</span></div>
    <div class="summary-row"><span class="label">MG claims:</span><span class="value">${batch.mgClaims||0}</span></div></div><div class="summary-col">
    <div class="summary-row"><span class="label">Projected total:</span><span class="value currency">${fmt$(batch.projectedTotal)}</span></div>
    <div class="summary-row"><span class="label">Current total:</span><span class="value currency">${fmt$(batch.currentTotal)}</span></div>
    <div class="summary-row"><span class="label">Total payments:</span><span class="value currency">${fmt$(batch.totalPayments)}</span></div>
    <div class="summary-row"><span class="label">Total pledges:</span><span class="value currency">${fmt$(batch.totalPledges)}</span></div>
    <div class="summary-row"><span class="label">Total recurring gifts:</span><span class="value currency">${fmt$(batch.totalRecurringGifts)}</span></div>
    <div class="summary-row"><span class="label">Total MG claims:</span><span class="value currency">${fmt$(batch.totalMGClaims)}</span></div></div></div>`;
}
function renderEntries(entries) {
  const tbody = document.querySelector('#detailTable tbody');
  if (!entries || !entries.length) { tbody.innerHTML = '<tr><td colspan="9" class="empty-cell">No entries found</td></tr>'; document.getElementById('footerDate').textContent = ''; return; }
  tbody.innerHTML = entries.map(e => `<tr><td>${e.constituentName}</td><td>${e.constituentLookupId}</td><td>${fmtD(e.date)}</td><td>${e.revenueType}</td><td class="currency">${fmt$(e.amount)}</td><td>${e.paymentMethod}</td><td>${e.appeal}</td><td>${e.designationEvent}</td><td><button class="btn-delete" data-id="${e._id}" title="Delete">🗑</button></td></tr>`).join('');
  document.querySelectorAll('.btn-delete').forEach(btn => btn.addEventListener('click', () => deleteEntry(btn.dataset.id)));
  document.getElementById('footerDate').textContent = fmtD(new Date()) + ' at ' + new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}
async function createBatch(e) {
  e.preventDefault(); const { api } = await import('../api.js');
  const data = { batchNumber: document.getElementById('newBatchNumber').value, status: document.getElementById('newBatchStatus').value, owner: document.getElementById('newBatchOwner').value, projectedCount: parseInt(document.getElementById('newProjectedCount').value) || 0, projectedTotal: parseFloat(document.getElementById('newProjectedTotal').value) || 0, entries: [] };
  await api.createBatch(data); closeModal('batchModal'); e.target.reset(); await loadBatchList(data.batchNumber);
}
async function addEntry(e) {
  e.preventDefault(); if (!currentBatch) return; const { api } = await import('../api.js');
  const data = { constituentName: document.getElementById('entryName').value, constituentLookupId: document.getElementById('entryLookupId').value, date: document.getElementById('entryDate').value, revenueType: document.getElementById('entryRevenueType').value, amount: parseFloat(document.getElementById('entryAmount').value), paymentMethod: document.getElementById('entryMethod').value, appeal: document.getElementById('entryAppeal').value, designationEvent: document.getElementById('entryDesignation').value };
  await api.addEntry(currentBatch.batchNumber, data); closeModal('entryModal'); e.target.reset();
  currentBatch = await api.getBatch(currentBatch.batchNumber); renderSummary(currentBatch); renderEntries(currentBatch.entries);
}
async function deleteEntry(id) {
  if (!confirm('Delete this entry?')) return; const { api } = await import('../api.js');
  await api.deleteEntry(currentBatch.batchNumber, id); currentBatch = await api.getBatch(currentBatch.batchNumber);
  renderSummary(currentBatch); renderEntries(currentBatch.entries);
}
function exportPDF() { if (!currentBatch) return alert('Please select a batch first'); import('../api.js').then(({ api }) => api.exportPDF(currentBatch.batchNumber)); }
