export async function renderDashboard() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="app-layout">
      ${renderNavbar('dashboard')}
      <div class="main-content">
        <h1>📊 Dashboard</h1>
        <div class="stats-grid" id="statsGrid"><div class="stat-card loading">Loading...</div></div>
        <div class="charts-row">
          <div class="chart-card"><h3>Revenue by Month</h3><canvas id="monthlyChart"></canvas></div>
          <div class="chart-card"><h3>Batch Status</h3><canvas id="statusChart"></canvas></div>
        </div>
        <div class="recent-batches">
          <h3>Recent Batches</h3>
          <table class="simple-table" id="recentTable"><thead><tr><th>Batch #</th><th>Status</th><th>Owner</th><th>Total</th></tr></thead><tbody></tbody></table>
        </div>
      </div>
    </div>
  `;
  bindNav(); loadDashboardData();
}
function renderNavbar(active) {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  return `<nav class="sidebar"><div class="sidebar-logo">📋 InBatch</div><ul class="sidebar-menu">
    <li><a href="#/dashboard" class="${active === 'dashboard' ? 'active' : ''}">📊 Dashboard</a></li>
    <li><a href="#/report" class="${active === 'report' ? 'active' : ''}">📋 Batch Report</a></li>
  </ul><div class="sidebar-footer"><div class="user-info"><div class="user-name">${user.fullName || user.username}</div><div class="user-role">${user.role}</div></div><button id="logoutBtn" class="btn-logout">Logout</button></div></nav>`;
}
function bindNav() {
  document.getElementById('logoutBtn')?.addEventListener('click', () => {
    localStorage.removeItem('token'); localStorage.removeItem('user'); window.location.hash = '#/login';
  });
}
async function loadDashboardData() {
  const { api } = await import('../api.js');
  try {
    const [stats, batches] = await Promise.all([api.getStats(), api.getBatches()]);
    document.getElementById('statsGrid').innerHTML = `
      <div class="stat-card blue"><div class="stat-value">${stats.totalBatches}</div><div class="stat-label">Total Batches</div></div>
      <div class="stat-card green"><div class="stat-value">$${stats.totalRevenue.toLocaleString()}</div><div class="stat-label">Total Revenue</div></div>
      <div class="stat-card orange"><div class="stat-value">${stats.totalEntries}</div><div class="stat-label">Total Entries</div></div>
      <div class="stat-card purple"><div class="stat-value">${Object.keys(stats.statusCounts).length}</div><div class="stat-label">Status Types</div></div>`;
    const months = Object.keys(stats.monthly).sort();
    new Chart(document.getElementById('monthlyChart'), {
      type: 'bar', data: { labels: months.map(m => { const [y, mo] = m.split('-'); return mo + '/' + y; }), datasets: [{ label: 'Revenue ($)', data: months.map(m => stats.monthly[m]), backgroundColor: '#2e6da4', borderRadius: 4 }] },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { callback: v => '$' + v } } } }
    });
    new Chart(document.getElementById('statusChart'), {
      type: 'doughnut', data: { labels: Object.keys(stats.statusCounts), datasets: [{ data: Object.values(stats.statusCounts), backgroundColor: ['#2e6da4', '#5cb85c', '#f0ad4e', '#d9534f'] }] },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
    });
    document.querySelector('#recentTable tbody').innerHTML = batches.slice(0, 5).map(b =>
      `<tr><td><a href="#/report?batch=${b.batchNumber}">Batch ${b.batchNumber}</a></td><td><span class="badge ${b.status.toLowerCase().replace(' ', '-')}">${b.status}</span></td><td>${b.owner || '-'}</td><td class="currency">$${(b.currentTotal || 0).toLocaleString()}</td></tr>`
    ).join('');
  } catch (err) { document.getElementById('statsGrid').innerHTML = `<div class="stat-card error">Error: ${err.message}</div>`; }
}
