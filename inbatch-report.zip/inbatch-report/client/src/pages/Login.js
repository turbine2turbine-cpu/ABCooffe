export function renderLogin() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="auth-container">
      <div class="auth-box">
        <div class="auth-logo">📋 InBatch</div>
        <h2>Revenue Batch Control System</h2>
        <div class="auth-tabs">
          <button class="auth-tab active" id="tabLogin">Login</button>
          <button class="auth-tab" id="tabRegister">Register</button>
        </div>
        <form id="loginForm" class="auth-form">
          <input type="text" id="loginUser" placeholder="Username" required />
          <input type="password" id="loginPass" placeholder="Password" required />
          <button type="submit" class="btn-primary btn-block">Sign In</button>
          <p class="hint">Demo: admin / admin123</p>
        </form>
        <form id="registerForm" class="auth-form" style="display:none">
          <input type="text" id="regUser" placeholder="Username" required />
          <input type="email" id="regEmail" placeholder="Email" required />
          <input type="text" id="regFullName" placeholder="Full Name" />
          <input type="password" id="regPass" placeholder="Password" required />
          <button type="submit" class="btn-primary btn-block">Create Account</button>
        </form>
        <div id="authError" class="auth-error"></div>
      </div>
    </div>
  `;
  document.getElementById('tabLogin').addEventListener('click', () => switchTab('login'));
  document.getElementById('tabRegister').addEventListener('click', () => switchTab('register'));
  document.getElementById('loginForm').addEventListener('submit', handleLogin);
  document.getElementById('registerForm').addEventListener('submit', handleRegister);
}
function switchTab(tab) {
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
  document.getElementById(tab === 'login' ? 'tabLogin' : 'tabRegister').classList.add('active');
  document.getElementById('loginForm').style.display = tab === 'login' ? 'block' : 'none';
  document.getElementById('registerForm').style.display = tab === 'register' ? 'block' : 'none';
  document.getElementById('authError').textContent = '';
}
async function handleLogin(e) {
  e.preventDefault();
  const { api } = await import('../api.js');
  try {
    const res = await api.login({ username: document.getElementById('loginUser').value, password: document.getElementById('loginPass').value });
    localStorage.setItem('token', res.token); localStorage.setItem('user', JSON.stringify(res.user));
    window.location.hash = '#/dashboard';
  } catch (err) { document.getElementById('authError').textContent = err.message; }
}
async function handleRegister(e) {
  e.preventDefault();
  const { api } = await import('../api.js');
  try {
    const res = await api.register({ username: document.getElementById('regUser').value, email: document.getElementById('regEmail').value, fullName: document.getElementById('regFullName').value, password: document.getElementById('regPass').value });
    localStorage.setItem('token', res.token); localStorage.setItem('user', JSON.stringify(res.user));
    window.location.hash = '#/dashboard';
  } catch (err) { document.getElementById('authError').textContent = err.message; }
}
