import './style.css';
function checkAuth() { return !!localStorage.getItem('token'); }
async function router() {
  const hash = window.location.hash || '#/login';
  if (!checkAuth() && !hash.startsWith('#/login')) { window.location.hash = '#/login'; return; }
  if (hash.startsWith('#/dashboard')) { const { renderDashboard } = await import('./pages/Dashboard.js'); renderDashboard(); }
  else if (hash.startsWith('#/report')) { const params = new URLSearchParams(hash.split('?')[1]); const { renderReport } = await import('./pages/Report.js'); renderReport(params.get('batch')); }
  else { const { renderLogin } = await import('./pages/Login.js'); renderLogin(); }
}
window.addEventListener('hashchange', router);
window.addEventListener('load', router);
