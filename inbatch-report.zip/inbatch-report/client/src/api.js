const API_URL = '/api';
function getToken() { return localStorage.getItem('token') || ''; }
function getAuthHeaders() { return { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getToken()}` }; }
async function fetchJSON(url, options = {}) {
  const res = await fetch(url, { headers: getAuthHeaders(), ...options });
  if (res.status === 401) { localStorage.removeItem('token'); localStorage.removeItem('user'); window.location.hash = '#/login'; throw new Error('Session expired'); }
  if (!res.ok) { const err = await res.json().catch(() => ({})); throw new Error(err.error || `HTTP ${res.status}`); }
  return res.json();
}
export const api = {
  login: (data) => fetchJSON(`${API_URL}/auth/login`, { method: 'POST', body: JSON.stringify(data) }),
  register: (data) => fetchJSON(`${API_URL}/auth/register`, { method: 'POST', body: JSON.stringify(data) }),
  me: () => fetchJSON(`${API_URL}/auth/me`),
  getBatches: () => fetchJSON(`${API_URL}/batches`),
  getBatch: (num) => fetchJSON(`${API_URL}/batches/${num}`),
  getStats: () => fetchJSON(`${API_URL}/batches/stats`),
  createBatch: (data) => fetchJSON(`${API_URL}/batches`, { method: 'POST', body: JSON.stringify(data) }),
  addEntry: (num, data) => fetchJSON(`${API_URL}/batches/${num}/entries`, { method: 'POST', body: JSON.stringify(data) }),
  deleteEntry: (num, id) => fetchJSON(`${API_URL}/batches/${num}/entries/${id}`, { method: 'DELETE' }),
  deleteBatch: (num) => fetchJSON(`${API_URL}/batches/${num}`, { method: 'DELETE' }),
  exportPDF: (num) => { window.open(`${API_URL}/pdf/${num}?token=${encodeURIComponent(getToken())}`, '_blank'); }
};
