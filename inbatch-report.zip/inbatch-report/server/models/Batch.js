import mongoose from 'mongoose';
const entrySchema = new mongoose.Schema({
  constituentName: String, constituentLookupId: String, date: Date,
  revenueType: String, amount: { type: Number, default: 0 },
  paymentMethod: String, appeal: String, designationEvent: String
}, { _id: true });
const batchSchema = new mongoose.Schema({
  batchNumber: { type: String, required: true, unique: true },
  status: { type: String, enum: ['Open','Committed','Pending','Exception'], default: 'Open' },
  owner: String, exceptionBatchNumber: String,
  projectedCount: { type: Number, default: 0 }, committedCount: { type: Number, default: 0 },
  payments: { type: Number, default: 0 }, pledges: { type: Number, default: 0 },
  recurringGifts: { type: Number, default: 0 }, mgClaims: { type: Number, default: 0 },
  projectedTotal: { type: Number, default: 0 }, currentTotal: { type: Number, default: 0 },
  totalPayments: { type: Number, default: 0 }, totalPledges: { type: Number, default: 0 },
  totalRecurringGifts: { type: Number, default: 0 }, totalMGClaims: { type: Number, default: 0 },
  entries: [entrySchema]
}, { timestamps: true });
export default mongoose.model('Batch', batchSchema);
