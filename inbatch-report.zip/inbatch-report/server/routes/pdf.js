import express from 'express';
import puppeteer from 'puppeteer';
import Batch from '../models/Batch.js';
import { authenticate } from '../middleware/auth.js';
const router = express.Router();

function fmt$(n) { return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n || 0); }
function fmtD(d) { if (!d) return ''; const x = new Date(d); return (x.getMonth()+1)+'/'+x.getDate()+'/'+x.getFullYear(); }

router.get('/:batchNumber', authenticate, async (req, res) => {
  try {
    const b = await Batch.findOne({ batchNumber: req.params.batchNumber });
    if (!b) return res.status(404).json({ error: 'Not found' });
    const rows = b.entries.map(e => `<tr><td>${e.constituentName}</td><td>${e.constituentLookupId}</td><td>${fmtD(e.date)}</td><td>${e.revenueType}</td><td style="text-align:right">${fmt$(e.amount)}</td><td>${e.paymentMethod}</td><td>${e.appeal}</td><td>${e.designationEvent}</td></tr>`).join('');
    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
body{font-family:'Segoe UI',Arial,sans-serif;font-size:12px;margin:0;padding:20px}
.header{background:linear-gradient(to bottom,#5b9bd5,#2e6da4);color:white;padding:12px 16px;margin:-20px -20px 0 -20px}
.header h1{margin:0;font-size:18px}
.summary{background:#f5f5f5;padding:16px;margin:0 -20px;border-bottom:2px solid #ccc}
.sg{display:flex;justify-content:space-between}
.sc{width:32%}
.r{display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px dotted #ccc}
.l{font-weight:600}
table{width:100%;border-collapse:collapse;margin-top:10px;font-size:11px}
th{background:#dbe9f5;padding:6px 8px;text-align:left;border-bottom:2px solid #5b9bd5}
td{padding:5px 8px;border-bottom:1px solid #ddd}
.f{margin-top:10px;font-size:10px;color:#666;display:flex;justify-content:space-between}
</style></head><body>
<div class="header"><h1>Enhanced Revenue Batch Control Report</h1></div>
<div class="summary"><div class="sg">
<div class="sc"><div class="r"><span class="l">Batch number:</span><span>${b.batchNumber}</span></div><div class="r"><span class="l">Status:</span><span>${b.status}</span></div><div class="r"><span class="l">Owner:</span><span>${b.owner||'-'}</span></div><div class="r"><span class="l">Exception batch number:</span><span>${b.exceptionBatchNumber||''}</span></div></div>
<div class="sc"><div class="r"><span class="l">Projected #:</span><span>${b.projectedCount||0}</span></div><div class="r"><span class="l">Committed #:</span><span>${b.committedCount||0}</span></div><div class="r"><span class="l">Payments:</span><span>${b.payments||0}</span></div><div class="r"><span class="l">Pledges:</span><span>${b.pledges||0}</span></div><div class="r"><span class="l">Recurring gifts:</span><span>${b.recurringGifts||0}</span></div><div class="r"><span class="l">MG claims:</span><span>${b.mgClaims||0}</span></div></div>
<div class="sc"><div class="r"><span class="l">Projected total:</span><span>${fmt$(b.projectedTotal)}</span></div><div class="r"><span class="l">Current total:</span><span>${fmt$(b.currentTotal)}</span></div><div class="r"><span class="l">Total payments:</span><span>${fmt$(b.totalPayments)}</span></div><div class="r"><span class="l">Total pledges:</span><span>${fmt$(b.totalPledges)}</span></div><div class="r"><span class="l">Total recurring gifts:</span><span>${fmt$(b.totalRecurringGifts)}</span></div><div class="r"><span class="l">Total MG claims:</span><span>${fmt$(b.totalMGClaims)}</span></div></div>
</div></div>
<table><thead><tr><th>Constituent Name</th><th>Constituent Lookup ID</th><th>Date</th><th>Revenue Type</th><th style="text-align:right">Amount</th><th>Payment Method</th><th>Appeal</th><th>Designation / Event</th></tr></thead>
<tbody>${rows||'<tr><td colspan="8" style="text-align:center">No entries</td></tr>'}</tbody></table>
<div class="f"><span>${fmtD(new Date())} at ${new Date().toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'})}</span><span>Prepared by: ${b.owner||'System'}</span><span>Page 1 of 1</span></div>
</body></html>`;

    const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox','--disable-setuid-sandbox'] });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdf = await page.pdf({ format: 'A4', printBackground: true, margin: { top: '0', right: '0', bottom: '0', left: '0' } });
    await browser.close();
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="batch_${b.batchNumber}_report.pdf"`);
    res.send(pdf);
  } catch (err) { console.error('PDF error:', err); res.status(500).json({ error: err.message }); }
});

export default router;
