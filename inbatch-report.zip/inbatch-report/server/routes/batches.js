import express from 'express';
import Batch from '../models/Batch.js';
import { authenticate } from '../middleware/auth.js';
const router = express.Router();
router.use(authenticate);

function recalc(batch) {
  batch.committedCount = batch.entries.length;
  batch.payments = batch.entries.filter(e => e.revenueType?.toLowerCase().includes('payment')).length;
  batch.pledges = batch.entries.filter(e => e.revenueType?.toLowerCase().includes('pledge')).length;
  batch.recurringGifts = batch.entries.filter(e => e.revenueType?.toLowerCase().includes('recurring')).length;
  batch.mgClaims = batch.entries.filter(e => e.revenueType?.toLowerCase().includes('mg')).length;
  batch.totalPayments = batch.entries.filter(e => e.revenueType?.toLowerCase().includes('payment')).reduce((s, e) => s + (e.amount || 0), 0);
  batch.totalPledges = batch.entries.filter(e => e.revenueType?.toLowerCase().includes('pledge')).reduce((s, e) => s + (e.amount || 0), 0);
  batch.totalRecurringGifts = batch.entries.filter(e => e.revenueType?.toLowerCase().includes('recurring')).reduce((s, e) => s + (e.amount || 0), 0);
  batch.totalMGClaims = batch.entries.filter(e => e.revenueType?.toLowerCase().includes('mg')).reduce((s, e) => s + (e.amount || 0), 0);
  batch.currentTotal = batch.entries.reduce((s, e) => s + (e.amount || 0), 0);
}

router.get('/', async (req, res) => {
  const batches = await Batch.find({}, { batchNumber: 1, status: 1, owner: 1, currentTotal: 1, projectedTotal: 1, createdAt: 1 }).sort({ createdAt: -1 });
  res.json(batches);
});

router.get('/stats', async (req, res) => {
  const all = await Batch.find();
  const totalBatches = all.length;
  const totalRevenue = all.reduce((s, b) => s + (b.currentTotal || 0), 0);
  const totalEntries = all.reduce((s, b) => s + b.entries.length, 0);
  const statusCounts = {}; all.forEach(b => { statusCounts[b.status] = (statusCounts[b.status] || 0) + 1; });
  const monthly = {}; all.forEach(b => b.entries.forEach(e => { if (e.date) { const k = e.date.toISOString().slice(0, 7); monthly[k] = (monthly[k] || 0) + (e.amount || 0); } }));
  res.json({ totalBatches, totalRevenue, totalEntries, statusCounts, monthly });
});

router.get('/:batchNumber', async (req, res) => {
  const batch = await Batch.findOne({ batchNumber: req.params.batchNumber });
  if (!batch) return res.status(404).json({ error: 'Not found' });
  res.json(batch);
});

router.post('/', async (req, res) => { const batch = new Batch(req.body); await batch.save(); res.status(201).json(batch); });

router.put('/:batchNumber', async (req, res) => {
  const batch = await Batch.findOneAndUpdate({ batchNumber: req.params.batchNumber }, req.body, { new: true });
  if (!batch) return res.status(404).json({ error: 'Not found' }); res.json(batch);
});

router.post('/:batchNumber/entries', async (req, res) => {
  const batch = await Batch.findOne({ batchNumber: req.params.batchNumber });
  if (!batch) return res.status(404).json({ error: 'Not found' });
  batch.entries.push(req.body); recalc(batch); await batch.save(); res.status(201).json(batch);
});

router.delete('/:batchNumber/entries/:entryId', async (req, res) => {
  const batch = await Batch.findOne({ batchNumber: req.params.batchNumber });
  if (!batch) return res.status(404).json({ error: 'Not found' });
  batch.entries = batch.entries.filter(e => e._id.toString() !== req.params.entryId); recalc(batch); await batch.save(); res.json(batch);
});

router.delete('/:batchNumber', async (req, res) => { await Batch.findOneAndDelete({ batchNumber: req.params.batchNumber }); res.json({ message: 'Deleted' }); });

export default router;
