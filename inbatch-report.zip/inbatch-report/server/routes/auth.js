import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { username, email, password, fullName } = req.body;
    if (await User.findOne({ $or: [{ username }, { email }] })) return res.status(400).json({ error: 'Exists' });
    const user = new User({ username, email, password: await bcrypt.hash(password, 10), fullName });
    await user.save();
    const token = jwt.sign({ userId: user._id, username, role: user.role }, process.env.JWT_SECRET || 'fallback', { expiresIn: '7d' });
    res.status(201).json({ token, user: { username, email, role: user.role, fullName } });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user || !await bcrypt.compare(password, user.password)) return res.status(400).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ userId: user._id, username, role: user.role }, process.env.JWT_SECRET || 'fallback', { expiresIn: '7d' });
    res.json({ token, user: { username, email: user.email, role: user.role, fullName: user.fullName } });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.get('/me', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) return res.status(401).json({ error: 'No token' });
    const decoded = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET || 'fallback');
    const user = await User.findById(decoded.userId).select('-password');
    res.json(user);
  } catch (err) { res.status(401).json({ error: 'Invalid token' }); }
});

export default router;
