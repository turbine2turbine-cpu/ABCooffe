import jwt from 'jsonwebtoken';
export const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) return res.status(401).json({ error: 'No token' });
  try { req.user = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET || 'fallback'); next(); }
  catch (err) { res.status(401).json({ error: 'Invalid token' }); }
};
export const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin required' });
  next();
};
