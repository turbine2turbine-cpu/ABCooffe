import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import batchRoutes from './routes/batches.js';
import pdfRoutes from './routes/pdf.js';

dotenv.config();
const app = express();
app.use(cors({ origin: ['http://localhost:3000','http://localhost','http://inbatch-client'], credentials: true }));
app.use(express.json());

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://admin:secret123@mongodb:27017/inbatch?authSource=admin';
mongoose.connect(MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => { console.error('MongoDB error:', err.message); process.exit(1); });

app.use('/api/auth', authRoutes);
app.use('/api/batches', batchRoutes);
app.use('/api/pdf', pdfRoutes);
app.get('/health', (req, res) => res.json({ status: 'ok' }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => console.log(`Server on http://0.0.0.0:${PORT}`));
