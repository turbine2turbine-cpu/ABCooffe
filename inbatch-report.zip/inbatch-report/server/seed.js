import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
dotenv.config();
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://admin:secret123@mongodb:27017/inbatch?authSource=admin';
await mongoose.connect(MONGODB_URI);

const userSchema = new mongoose.Schema({ username: String, email: String, password: String, role: { type: String, default: 'user' }, fullName: String });
const User = mongoose.model('User', userSchema);
const entrySchema = new mongoose.Schema({ constituentName: String, constituentLookupId: String, date: Date, revenueType: String, amount: Number, paymentMethod: String, appeal: String, designationEvent: String }, { _id: true });
const batchSchema = new mongoose.Schema({ batchNumber: { type: String, unique: true }, status: String, owner: String, exceptionBatchNumber: String, projectedCount: Number, committedCount: Number, payments: Number, pledges: Number, recurringGifts: Number, mgClaims: Number, projectedTotal: Number, currentTotal: Number, totalPayments: Number, totalPledges: Number, totalRecurringGifts: Number, totalMGClaims: Number, entries: [entrySchema] }, { timestamps: true });
const Batch = mongoose.model('Batch', batchSchema);

await User.deleteMany({}); await Batch.deleteMany({});
const adminPass = await bcrypt.hash('admin123', 10);
await User.create({ username: 'admin', email: 'admin@inbatch.com', password: adminPass, role: 'admin', fullName: 'Administrator' });
const userPass = await bcrypt.hash('user123', 10);
await User.create({ username: 'user', email: 'user@inbatch.com', password: userPass, role: 'user', fullName: 'Demo User' });
await Batch.create({ batchNumber: '56', status: 'Committed', owner: 'BBNT\\Ba', exceptionBatchNumber: '', projectedCount: 4, committedCount: 4, payments: 4, pledges: 0, recurringGifts: 0, mgClaims: 0, projectedTotal: 1250.00, currentTotal: 1250.00, totalPayments: 1250.00, totalPledges: 0, totalRecurringGifts: 0, totalMGClaims: 0, entries: [
  { constituentName: 'Max G. Taylor', constituentLookupId: '77', date: new Date('2014-01-09'), revenueType: 'Payment (donation)', amount: 500.00, paymentMethod: 'Check', appeal: 'NEWSLETTER', designationEvent: 'Library Fund' },
  { constituentName: 'John T. Smith', constituentLookupId: '71', date: new Date('2014-01-09'), revenueType: 'Payment (donation)', amount: 150.00, paymentMethod: 'Cash', appeal: 'NEWSLETTER', designationEvent: 'Library Fund' },
  { constituentName: 'Mary Young', constituentLookupId: '8-10000137', date: new Date('2014-01-09'), revenueType: 'Payment (donation)', amount: 100.00, paymentMethod: 'Check', appeal: 'NEWSLETTER', designationEvent: 'Library Fund' },
  { constituentName: 'Kenneth Parker', constituentLookupId: '125', date: new Date('2014-01-09'), revenueType: 'Payment (donation)', amount: 500.00, paymentMethod: 'Cash', appeal: 'NEWSLETTER', designationEvent: 'Library Fund' }
]});
console.log('Seeded: admin/admin123, user/user123, Batch 56');
process.exit(0);
