-- PlantMaster Database Schema
-- TimescaleDB + PostgreSQL for recipe management and time-series data

-- Enable TimescaleDB extension
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_code VARCHAR(50) UNIQUE NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Recipes table
CREATE TABLE IF NOT EXISTS recipes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipe_code VARCHAR(50) UNIQUE NOT NULL,
    recipe_name VARCHAR(200) NOT NULL,
    product_id UUID REFERENCES products(id),
    version INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    created_by VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Recipe parameters table (33 process parameters per recipe profile)
CREATE TABLE IF NOT EXISTS recipe_parameters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipe_id UUID NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
    param_name VARCHAR(100) NOT NULL,
    param_type VARCHAR(20) NOT NULL DEFAULT 'REAL',
    value_default JSONB,
    value_min NUMERIC,
    value_max NUMERIC,
    plc_tag VARCHAR(200),
    unit VARCHAR(20),
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(recipe_id, param_name)
);

-- Recipe download history
CREATE TABLE IF NOT EXISTS recipe_downloads (
    time TIMESTAMPTZ NOT NULL,
    recipe_id UUID NOT NULL,
    plc_id VARCHAR(50) NOT NULL,
    downloaded_by VARCHAR(100),
    status VARCHAR(20) NOT NULL,
    error_message TEXT,
    duration_ms INTEGER,
    plc_ack BOOLEAN DEFAULT false
);
SELECT create_hypertable('recipe_downloads', 'time', chunk_time_interval => INTERVAL '7 days', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_downloads_recipe ON recipe_downloads (recipe_id, time DESC);
CREATE INDEX IF NOT EXISTS idx_downloads_plc ON recipe_downloads (plc_id, time DESC);

-- PLC tag values (time-series)
CREATE TABLE IF NOT EXISTS plc_tag_values (
    time TIMESTAMPTZ NOT NULL,
    plc_id VARCHAR(50) NOT NULL,
    tag_name VARCHAR(200) NOT NULL,
    tag_value DOUBLE PRECISION,
    tag_quality INTEGER DEFAULT 192,
    recipe_id UUID
);
SELECT create_hypertable('plc_tag_values', 'time', chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_tag_values_plc_tag ON plc_tag_values (plc_id, tag_name, time DESC);
CREATE INDEX IF NOT EXISTS idx_tag_values_recipe ON plc_tag_values (recipe_id, time DESC);

-- Process events / alarms
CREATE TABLE IF NOT EXISTS process_events (
    time TIMESTAMPTZ NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    plc_id VARCHAR(50),
    recipe_id UUID,
    severity INTEGER DEFAULT 1,
    message TEXT,
    acknowledged BOOLEAN DEFAULT false,
    acknowledged_by VARCHAR(100),
    acknowledged_at TIMESTAMPTZ
);
SELECT create_hypertable('process_events', 'time', chunk_time_interval => INTERVAL '7 days', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_events_type ON process_events (event_type, time DESC);
CREATE INDEX IF NOT EXISTS idx_events_unack ON process_events (acknowledged, time DESC) WHERE acknowledged = false;

-- PLC configurations
CREATE TABLE IF NOT EXISTS plc_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plc_id VARCHAR(50) UNIQUE NOT NULL,
    host VARCHAR(100) NOT NULL,
    slot INTEGER DEFAULT 0,
    timeout INTEGER DEFAULT 5,
    protocol VARCHAR(20) DEFAULT 'pylogix',
    opcua_endpoint VARCHAR(500),
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Production orders
CREATE TABLE IF NOT EXISTS production_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    po_number VARCHAR(50) UNIQUE NOT NULL,
    recipe_id UUID NOT NULL REFERENCES recipes(id),
    plc_id VARCHAR(50),
    quantity INTEGER NOT NULL DEFAULT 0,
    status VARCHAR(20) DEFAULT 'pending',
    priority INTEGER DEFAULT 5,
    scheduled_date DATE,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    operator VARCHAR(100) DEFAULT 'system',
    notes TEXT,
    created_by VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_orders_status ON production_orders (status, scheduled_date);
CREATE INDEX IF NOT EXISTS idx_orders_recipe ON production_orders (recipe_id);

CREATE TABLE IF NOT EXISTS order_executions (
    time TIMESTAMPTZ NOT NULL,
    order_id UUID NOT NULL,
    po_number VARCHAR(50) NOT NULL,
    recipe_id UUID NOT NULL,
    plc_id VARCHAR(50) NOT NULL,
    event_type VARCHAR(50),
    tag_name VARCHAR(200),
    tag_value DOUBLE PRECISION,
    message TEXT
);
SELECT create_hypertable('order_executions', 'time', chunk_time_interval => INTERVAL '7 days', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_exec_order ON order_executions (order_id, time DESC);
CREATE INDEX IF NOT EXISTS idx_exec_po ON order_executions (po_number, time DESC);

-- Production Data table (stores final production metrics for completed/cancelled batches)
CREATE TABLE IF NOT EXISTS production_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES production_orders(id) ON DELETE CASCADE,
    po_number VARCHAR(50) NOT NULL,
    recipe_id UUID REFERENCES recipes(id),
    plc_id VARCHAR(50),
    status VARCHAR(20) NOT NULL DEFAULT 'running',
    init_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    -- Temperatures
    bean_temp_start NUMERIC(8,2),
    bean_temp_end NUMERIC(8,2),
    drop_temp NUMERIC(8,2),
    charge_temp NUMERIC(8,2),
    turnaround_temp NUMERIC(8,2),
    ta_temp NUMERIC(8,2),
    first_crack_temp NUMERIC(8,2),
    exhaust_temp_avg NUMERIC(8,2),
    inlet_temp_avg NUMERIC(8,2),
    drum_temp_avg NUMERIC(8,2),
    -- Times
    roast_time NUMERIC(8,2),
    dev_time NUMERIC(8,2),
    cool_time NUMERIC(8,2),
    drying_phase NUMERIC(8,2),
    maillard_phase NUMERIC(8,2),
    first_crack_time NUMERIC(8,2),
    -- Loss / Yield
    moisture_loss NUMERIC(8,2),
    weight_loss NUMERIC(8,2),
    -- Equipment settings
    burner_power_avg NUMERIC(8,2),
    fan_speed_avg NUMERIC(8,2),
    gas_pressure_avg NUMERIC(8,2),
    air_flow_avg NUMERIC(8,2),
    drum_speed NUMERIC(8,2),
    -- Misc
    operator VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_production_data_order ON production_data (order_id);
CREATE INDEX IF NOT EXISTS idx_production_data_po ON production_data (po_number);
CREATE INDEX IF NOT EXISTS idx_production_data_status ON production_data (status, completed_at DESC);

INSERT INTO products (product_code, product_name, description) VALUES
    ('ORIGIN-ETH', 'Ethiopian Coffee', 'High altitude heirloom varieties'),
    ('ORIGIN-COL', 'Colombian Coffee', 'Washed process Arabica'),
    ('ORIGIN-BRA', 'Brazilian Coffee', 'Natural process Santos'),
    ('ORIGIN-KEN', 'Kenyan Coffee', 'AA grade SL28/SL34'),
    ('ORIGIN-GUA', 'Guatemalan Coffee', 'Antigua volcanic soil')
ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'ESP-001', 'Ethiopia Yirgacheffe Light Roast', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-ETH' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'ESP-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'ESP-002', 'Ethiopia Sidamo Medium Roast', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-ETH' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '750', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '220', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '72', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '185', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '180', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '150', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '222', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '50', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '195', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '212', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '200', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '480', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '52', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '240', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '14.0', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.0', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '660', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '88', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '15.2', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'ESP-002' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'COL-001', 'Colombia Huila Light Roast', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-COL' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '800', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '210', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '65', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '175', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '195', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '135', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '215', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '54', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '188', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '205', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '195', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '450', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '45', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '230', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '12.8', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '8.0', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '630', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '82', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.5', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'COL-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'COL-002', 'Colombia Narino Medium-Dark', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-COL' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '720', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '225', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '75', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '190', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '175', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '160', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '228', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '48', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '200', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '215', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '202', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '500', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '55', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '245', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '15.0', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '6.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '690', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '30', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '90', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '16.0', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'COL-002' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'BRA-001', 'Brazil Santos Medium', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-BRA' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '760', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '218', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '70', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '182', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '185', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '145', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '220', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '53', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '192', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '210', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '198', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '470', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '50', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '238', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.5', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.2', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '650', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '85', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'BRA-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'BRA-002', 'Brazil Cerrado Dark Roast', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-BRA' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '700', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '230', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '78', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '195', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '170', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '170', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '232', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '46', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '205', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '220', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '205', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '520', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '58', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '250', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '15.5', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '6.0', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '720', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '45', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '92', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '16.5', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'BRA-002' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'KEN-001', 'Kenya AA Light-Medium', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-KEN' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '820', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '212', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '66', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '178', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '192', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '138', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '216', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '55', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '189', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '206', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '196', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '455', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '46', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '232', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.0', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.8', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '640', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '83', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.2', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'KEN-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'KEN-002', 'Kenya Nyeri Medium', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-KEN' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '740', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '222', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '73', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '188', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '178', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '155', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '226', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '51', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '198', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '214', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '201', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '490', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '53', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '242', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '14.5', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '6.8', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '680', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '20', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '89', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '15.5', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'KEN-002' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'GUA-001', 'Guatemala Antigua Light', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-GUA' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '840', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '208', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '64', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '172', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '198', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '132', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '214', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '56', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '187', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '204', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '194', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '440', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '44', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '228', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '12.5', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '8.2', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '620', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '80', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.0', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'GUA-001' ON CONFLICT DO NOTHING;

INSERT INTO recipes (recipe_code, recipe_name, product_id, version, is_active, created_by)
SELECT 'GUA-002', 'Guatemala Huehuetenango Medium-Dark', id, 1, true, 'admin' FROM products WHERE product_code = 'ORIGIN-GUA' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '710', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '228', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '76', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '192', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '172', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '165', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '230', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '49', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '202', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '218', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '204', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '510', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '56', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '248', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '15.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '6.2', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '700', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '35', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '93', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '16.2', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'GUA-002' ON CONFLICT DO NOTHING;

INSERT INTO plc_configs (plc_id, host, slot, protocol, description) VALUES
    ('LINE_A_PLC', '192.168.20.10', 0, 'pylogix', 'Roaster A - Probat'),
    ('LINE_B_PLC', '192.168.20.11', 0, 'pylogix', 'Roaster B - Probat'),
    ('LINE_C_PLC', '192.168.20.12', 0, 'pylogix', 'Roaster C - Giesen')
ON CONFLICT DO NOTHING;