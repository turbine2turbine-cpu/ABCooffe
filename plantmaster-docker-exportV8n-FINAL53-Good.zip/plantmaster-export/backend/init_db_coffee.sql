-- ============================================
-- 20 COFFEE ROASTING PROFILES WITH 33 PARAMETERS EACH
-- ============================================

-- Profile: Ethiopia Yirgacheffe Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('ETH-001', 'Ethiopia Yirgacheffe Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'ETH-001'
ON CONFLICT DO NOTHING;

-- Profile: Ethiopia Sidamo Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('ETH-002', 'Ethiopia Sidamo Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'ETH-002'
ON CONFLICT DO NOTHING;

-- Profile: Colombia Huila Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('COL-001', 'Colombia Huila Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'COL-001'
ON CONFLICT DO NOTHING;

-- Profile: Colombia Supremo Dark
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('COL-002', 'Colombia Supremo Dark', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'COL-002'
ON CONFLICT DO NOTHING;

-- Profile: Brazil Santos Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('BRA-001', 'Brazil Santos Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'BRA-001'
ON CONFLICT DO NOTHING;

-- Profile: Brazil Cerrado Dark
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('BRA-002', 'Brazil Cerrado Dark', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'BRA-002'
ON CONFLICT DO NOTHING;

-- Profile: Guatemala Antigua Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('GUA-001', 'Guatemala Antigua Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'GUA-001'
ON CONFLICT DO NOTHING;

-- Profile: Guatemala Huehuetenango Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('GUA-002', 'Guatemala Huehuetenango Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'GUA-002'
ON CONFLICT DO NOTHING;

-- Profile: Kenya AA Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('KEN-001', 'Kenya AA Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'KEN-001'
ON CONFLICT DO NOTHING;

-- Profile: Kenya PB Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('KEN-002', 'Kenya PB Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'KEN-002'
ON CONFLICT DO NOTHING;

-- Profile: Costa Rica Tarrazu Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('CRI-001', 'Costa Rica Tarrazu Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'CRI-001'
ON CONFLICT DO NOTHING;

-- Profile: Costa Rica Honey Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('CRI-002', 'Costa Rica Honey Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'CRI-002'
ON CONFLICT DO NOTHING;

-- Profile: Sumatra Mandheling Dark
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('SUM-001', 'Sumatra Mandheling Dark', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'SUM-001'
ON CONFLICT DO NOTHING;

-- Profile: Sumatra Lintong Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('SUM-002', 'Sumatra Lintong Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'SUM-002'
ON CONFLICT DO NOTHING;

-- Profile: Java Arabica Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('JAV-001', 'Java Arabica Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'JAV-001'
ON CONFLICT DO NOTHING;

-- Profile: Java Estate Dark
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('JAV-002', 'Java Estate Dark', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'JAV-002'
ON CONFLICT DO NOTHING;

-- Profile: Tanzania Peaberry Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('TAN-001', 'Tanzania Peaberry Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'TAN-001'
ON CONFLICT DO NOTHING;

-- Profile: Tanzania AA Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('TAN-002', 'Tanzania AA Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'TAN-002'
ON CONFLICT DO NOTHING;

-- Profile: Rwanda Bourbon Light
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('RWA-001', 'Rwanda Bourbon Light', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'RWA-001'
ON CONFLICT DO NOTHING;

-- Profile: Rwanda Cooperative Medium
INSERT INTO recipes (recipe_code, recipe_name, version, is_active, created_by)
VALUES ('RWA-002', 'Rwanda Cooperative Medium', 1, true, 'admin')
ON CONFLICT DO NOTHING;

INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'AirFlow', 'REAL', '780', 500, 1200, 'RoasterA.AirFlow', 'm3/h', 1
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BatchSize', 'REAL', '15', 5, 30, 'RoasterA.BatchSize', 'kg', 2
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTemp', 'REAL', '215', 160, 260, 'RoasterA.BeanTemp', 'C', 3
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempEnd', 'REAL', '201', 180, 240, 'RoasterA.BeanTempEnd', 'C', 4
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BeanTempStart', 'REAL', '23', 18, 30, 'RoasterA.BeanTempStart', 'C', 5
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'BurnerPower', 'REAL', '68', 30, 100, 'RoasterA.BurnerPower', '%', 6
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ChargeTemp', 'REAL', '180', 140, 220, 'RoasterA.ChargeTemp', 'C', 7
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolTime', 'REAL', '190', 60, 300, 'RoasterA.CoolTime', 'sec', 8
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'CoolingTime', 'REAL', '190', 60, 300, 'RoasterA.CoolingTime', 'sec', 9
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevTime', 'REAL', '140', 60, 300, 'RoasterA.DevTime', 'sec', 10
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentRatio', 'REAL', '17.26', 8, 25, 'RoasterA.DevelopmentRatio', '%', 11
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DevelopmentTime', 'REAL', '140', 60, 300, 'RoasterA.DevelopmentTime', 'sec', 12
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DropTemp', 'REAL', '218', 180, 240, 'RoasterA.DropTemp', 'C', 13
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumSpeed', 'REAL', '52', 30, 80, 'RoasterA.DrumSpeed', 'RPM', 14
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DrumTemp', 'REAL', '190', 150, 250, 'RoasterA.DrumTemp', 'C', 15
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'DryingPhase', 'REAL', '232', 180, 300, 'RoasterA.DryingPhase', 'sec', 16
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'ExhaustTemp', 'REAL', '208', 150, 280, 'RoasterA.ExhaustTemp', 'C', 17
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Temp', 'REAL', '197', 180, 210, 'RoasterA.FC_Temp', 'C', 18
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FC_Time', 'REAL', '465', 300, 720, 'RoasterA.FC_Time', 'sec', 19
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FanSpeed', 'REAL', '84', 50, 100, 'RoasterA.FanSpeed', '%', 20
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'FirstCrackTemp', 'REAL', '197', 180, 210, 'RoasterA.FirstCrackTemp', 'C', 21
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'GasPressure', 'REAL', '48', 20, 80, 'RoasterA.GasPressure', 'mbar', 22
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'Humidity', 'REAL', '44', 30, 70, 'RoasterA.Humidity', '%RH', 23
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'InletTemp', 'REAL', '235', 180, 300, 'RoasterA.InletTemp', 'C', 24
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MaillardPhase', 'REAL', '174', 120, 240, 'RoasterA.MaillardPhase', 'sec', 25
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'MoistureLoss', 'REAL', '13.2', 8, 18, 'RoasterA.MoistureLoss', '%', 26
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RateOfRise', 'REAL', '7.5', 3, 15, 'RoasterA.RateOfRise', 'C/min', 27
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoR', 'REAL', '7.5', 3, 15, 'RoasterA.RoR', 'C/min', 28
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'RoastTime', 'REAL', '645', 300, 900, 'RoasterA.RoastTime', 'sec', 29
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'SC_Time', 'REAL', '0', 0, 900, 'RoasterA.SC_Time', 'sec', 30
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TATemp', 'REAL', '84', 60, 120, 'RoasterA.TATemp', 'C', 31
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'TurnaroundTemp', 'REAL', '84', 60, 120, 'RoasterA.TurnaroundTemp', 'C', 32
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
INSERT INTO recipe_parameters (recipe_id, param_name, param_type, value_default, value_min, value_max, plc_tag, unit, sort_order)
SELECT r.id, 'WeightLoss', 'REAL', '14.8', 10, 20, 'RoasterA.WeightLoss', '%', 33
FROM recipes r WHERE r.recipe_code = 'RWA-002'
ON CONFLICT DO NOTHING;
