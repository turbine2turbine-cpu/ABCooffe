import asyncio
import logging
import random
from datetime import datetime
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

SIM_TAGS = [
    "RoasterAProd.BeanTempStart", "RoasterAProd.BeanTempEnd", "RoasterAProd.DropTemp",
    "RoasterAProd.ChargeTemp", "RoasterAProd.TurnaroundTemp", "RoasterAProd.TATemp",
    "RoasterAProd.FirstCrackTemp", "RoasterAProd.ExhaustTemp", "RoasterAProd.InletTemp",
    "RoasterAProd.DrumTemp", "RoasterAProd.RoastTime", "RoasterAProd.DevTime",
    "RoasterAProd.CoolTime", "RoasterAProd.DryingPhase", "RoasterAProd.MaillardPhase",
    "RoasterAProd.FC_Time", "RoasterAProd.MoistureLoss", "RoasterAProd.WeightLoss",
    "RoasterAProd.BurnerPower", "RoasterAProd.FanSpeed", "RoasterAProd.GasPressure",
    "RoasterAProd.AirFlow", "RoasterAProd.DrumSpeed",
]

class ProductionDataSimulator:
    def __init__(self):
        self._enabled = False
        self._running = False
        self._task = None
        self._current_values = {}
        self._plc_id = "LINE_A_PLC"
        self._poll_interval = 1.0
        self._last_update = None

    @property
    def enabled(self):
        return self._enabled

    @property
    def current_values(self):
        return self._current_values.copy()

    @property
    def status(self):
        return {
            "enabled": self._enabled,
            "running": self._running,
            "plc_id": self._plc_id,
            "poll_interval": self._poll_interval,
            "last_update": self._last_update.isoformat() if self._last_update else None,
            "tag_count": len(self._current_values),
        }

    def _generate_values(self):
        return {
            "RoasterAProd.BeanTempStart": round(random.uniform(180.0, 220.0), 2),
            "RoasterAProd.BeanTempEnd": round(random.uniform(210.0, 240.0), 2),
            "RoasterAProd.DropTemp": round(random.uniform(200.0, 230.0), 2),
            "RoasterAProd.ChargeTemp": round(random.uniform(160.0, 190.0), 2),
            "RoasterAProd.TurnaroundTemp": round(random.uniform(140.0, 170.0), 2),
            "RoasterAProd.TATemp": round(random.uniform(145.0, 175.0), 2),
            "RoasterAProd.FirstCrackTemp": round(random.uniform(190.0, 210.0), 2),
            "RoasterAProd.ExhaustTemp": round(random.uniform(350.0, 450.0), 2),
            "RoasterAProd.InletTemp": round(random.uniform(300.0, 400.0), 2),
            "RoasterAProd.DrumTemp": round(random.uniform(280.0, 380.0), 2),
            "RoasterAProd.RoastTime": round(random.uniform(600.0, 900.0), 2),
            "RoasterAProd.DevTime": round(random.uniform(120.0, 240.0), 2),
            "RoasterAProd.CoolTime": round(random.uniform(180.0, 300.0), 2),
            "RoasterAProd.DryingPhase": round(random.uniform(240.0, 360.0), 2),
            "RoasterAProd.MaillardPhase": round(random.uniform(180.0, 300.0), 2),
            "RoasterAProd.FC_Time": round(random.uniform(300.0, 480.0), 2),
            "RoasterAProd.MoistureLoss": round(random.uniform(10.0, 18.0), 2),
            "RoasterAProd.WeightLoss": round(random.uniform(12.0, 20.0), 2),
            "RoasterAProd.BurnerPower": round(random.uniform(40.0, 85.0), 2),
            "RoasterAProd.FanSpeed": round(random.uniform(30.0, 80.0), 2),
            "RoasterAProd.GasPressure": round(random.uniform(2.0, 5.0), 2),
            "RoasterAProd.AirFlow": round(random.uniform(1000.0, 3000.0), 2),
            "RoasterAProd.DrumSpeed": round(random.uniform(40.0, 70.0), 2),
        }

    async def _write_to_plc(self, values):
        """Try to write simulated values to PLC. PLC write is optional."""
        try:
            from app.services.plc_service import plc_service
            client = plc_service._get_client_for_plc(self._plc_id)
            connected = await plc_service._connect_with_retry(client)
            if not connected:
                logger.warning(f"[SIM] Cannot connect to PLC {self._plc_id} — values kept in memory only")
                return
            await client.write_tags(values)
            await client.disconnect()
            logger.info(f"[SIM] Wrote {len(values)} tags to {self._plc_id}")
        except Exception as e:
            logger.warning(f"[SIM] Failed to write to PLC (simulation continues): {e}")

    async def _poll_loop(self):
        logger.info("[SIM] Production data simulator polling started")
        while self._running:
            try:
                values = self._generate_values()
                # ALWAYS store values in memory regardless of PLC availability
                self._current_values = values
                self._last_update = datetime.now()
                # Try to write to PLC (optional)
                await self._write_to_plc(values)
                await asyncio.sleep(self._poll_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"[SIM] Polling error: {e}")
                await asyncio.sleep(self._poll_interval)
        logger.info("[SIM] Production data simulator polling stopped")

    def enable(self, plc_id="LINE_A_PLC", interval=1.0):
        if self._enabled:
            return False
        self._enabled = True
        self._running = True
        self._plc_id = plc_id
        self._poll_interval = interval
        # Generate initial values immediately so they're available right away
        self._current_values = self._generate_values()
        self._last_update = datetime.now()
        self._task = asyncio.create_task(self._poll_loop())
        logger.info(f"[SIM] Enabled for {plc_id} at {interval}s interval")
        return True

    def disable(self):
        if not self._enabled:
            return False
        self._enabled = False
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None
        logger.info("[SIM] Disabled")
        return True

simulator = ProductionDataSimulator()
