"""PLC service - download recipes, read/write tags with retry logic and detailed logging."""
import logging
import asyncio
import uuid
import time
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List

from app.core.config import settings
from app.core.database import (
    db, get_recipe_by_id, log_recipe_download, log_process_event,
    insert_tag_values_batch
)
from app.clients.plc_client import get_plc_client, AsyncPyLogixClient
from app.clients.opcua_client import get_opcua_client, OpcuaClient

logger = logging.getLogger(__name__)


class PlcService:
    """Service for PLC operations with retry, transaction safety, and detailed logging."""

    def __init__(self):
        self._download_queue: asyncio.Queue = asyncio.Queue(
            maxsize=settings.DOWNLOAD_QUEUE_MAX_SIZE
        )
        self._download_results: Dict[str, Dict[str, Any]] = {}
        self._running = False
        # Track active batch per PLC: plc_id -> {order_id, po_number, recipe_id, status}
        self._active_batches: Dict[str, Dict[str, Any]] = {}
        # Track previous PLC states to detect RUNNING->IDLE transitions (completed batches)
        self._previous_states: Dict[str, int] = {}

    async def start_worker(self):
        """Start background worker for processing download queue and batch polling."""
        self._running = True
        asyncio.create_task(self._process_download_queue())
        asyncio.create_task(self._poll_batch_status())
        logger.info("[PLC-SERVICE] Download worker and batch polling started")

    def get_active_batch(self, plc_id: str) -> Optional[Dict[str, Any]]:
        """Get the currently active batch on a PLC."""
        return self._active_batches.get(plc_id)

    def set_active_batch(self, plc_id: str, order_id: str, po_number: str, recipe_id: str, status: str = "running"):
        """Set active batch for a PLC."""
        self._active_batches[plc_id] = {
            "order_id": order_id,
            "po_number": po_number,
            "recipe_id": recipe_id,
            "status": status,
            "started_at": datetime.now(timezone.utc).isoformat()
        }
        logger.info(f"[PLC-SERVICE] Active batch set for {plc_id}: {po_number} ({order_id})")

    def clear_active_batch(self, plc_id: str):
        """Clear active batch when completed/reset."""
        if plc_id in self._active_batches:
            batch = self._active_batches.pop(plc_id)
            logger.info(f"[PLC-SERVICE] Active batch cleared for {plc_id}: {batch.get('po_number')}")

    def is_plc_available(self, plc_id: str) -> bool:
        """Check if PLC is available (no active batch or PLC is actually IDLE)."""
        active = self._active_batches.get(plc_id)
        if not active:
            return True
        # Available if active batch is completed/aborted/idle
        if active.get("status") in ("completed", "cancelled", "idle"):
            return True
        return False

    async def _poll_batch_status(self):
        """Background task: poll PLC batch status and sync to DB."""
        logger.info("[PLC-SERVICE|POLL] Batch status polling started")
        while self._running:
            try:
                # Collect PLC IDs from memory + DB orders that are running/initializing
                all_plc_ids = set(self._active_batches.keys())
                try:
                    async with db.acquire() as conn:
                        rows = await conn.fetch(
                            "SELECT DISTINCT plc_id FROM production_orders WHERE status IN ('running', 'initializing')"
                        )
                        for row in rows:
                            if row["plc_id"]:
                                all_plc_ids.add(row["plc_id"])
                except Exception as e:
                    logger.warning(f"[PLC-SERVICE|POLL] Failed to fetch running orders from DB: {e}")

                for plc_id in list(all_plc_ids):
                    try:
                        status = await get_batch_status(plc_id)
                        if not status.get("is_online"):
                            continue

                        batch_state = status.get("batch_status", 0)
                        batch_id = status.get("batch_id")
                        active = self._active_batches.get(plc_id)
                        prev_state = self._previous_states.get(plc_id, 0)

                        logger.info(
                            f"[PLC-SERVICE|POLL] {plc_id}: state={batch_state} prev={prev_state} "
                            f"batch_id='{batch_id}' active={active is not None} "
                            f"active_status={active.get('status') if active else None}"
                        )

                                                # ── CASE 0: PLC shows READY (state=2) or RUNNING (state=3) ──
                        # Create production_data record when batch is ready or running
                        if batch_state in (2, 3):
                            if active:
                                try:
                                    async with db.acquire() as conn:
                                        # Check if production_data already exists
                                        existing = await conn.fetchrow(
                                            "SELECT id FROM production_data WHERE order_id = $1",
                                            active["order_id"]
                                        )
                                        if not existing:
                                            # Get recipe_id from order
                                            order_row = await conn.fetchrow(
                                                "SELECT recipe_id FROM production_orders WHERE id = $1",
                                                active["order_id"]
                                            )
                                            recipe_id = str(order_row["recipe_id"]) if order_row and order_row["recipe_id"] else ""
                                            
                                            # Create production_data record
                                            from app.core.database import create_production_data
                                            pd_id = await create_production_data(
                                                order_id=active["order_id"],
                                                po_number=active["po_number"],
                                                recipe_id=recipe_id,
                                                plc_id=plc_id,
                                                operator="system"
                                            )
                                            logger.info(f"[PLC-SERVICE|POLL] Created production_data {pd_id} for {active['po_number']}")
                                        else:
                                            logger.debug(f"[PLC-SERVICE|POLL] production_data already exists for {active['po_number']}")
                                except Exception as e:
                                    logger.warning(f"[PLC-SERVICE|POLL] Failed to create production_data: {e}")
                            
                            # Update previous state and continue
                            self._previous_states[plc_id] = batch_state
                            continue

# ── CASE 1: PLC shows COMPLETED (state=9) ──
                        if batch_state == 9:
                            order_updated = False
                            completed_po_number = None
                            completed_order_id = None

                            # STEP 1: Read batch_id from PLC BEFORE clearing
                            batch_id_from_plc = None
                            try:
                                client = self._get_client_for_plc(plc_id)
                                if await self._connect_with_retry(client):
                                    id_results = await client.read_tags([BATCH_ID_TAG])
                                    id_result = next((r for r in id_results if r.tag_name == BATCH_ID_TAG), None)
                                    if id_result and id_result.status == "Success" and id_result.value:
                                        batch_id_from_plc = str(id_result.value).strip()
                                        logger.info(f"[PLC-SERVICE|POLL] Read BatchID from PLC before clear: '{batch_id_from_plc}'")
                                    await client.disconnect()
                            except Exception as e:
                                logger.warning(f"[PLC-SERVICE|POLL] Failed to read BatchID before clear: {e}")

                            # Fallback to memory
                            if not batch_id_from_plc and active:
                                batch_id_from_plc = active.get("po_number")
                                logger.info(f"[PLC-SERVICE|POLL] Using memory fallback BatchID: '{batch_id_from_plc}'")

                            # STEP 2 & 3: Find order and update to completed
                            try:
                                async with db.acquire() as conn:
                                    order_row = None

                                    if batch_id_from_plc:
                                        order_row = await conn.fetchrow(
                                            "SELECT id, po_number, status, recipe_id FROM production_orders WHERE po_number = $1 LIMIT 1",
                                            batch_id_from_plc
                                        )

                                    if not order_row and active:
                                        order_row = await conn.fetchrow(
                                            "SELECT id, po_number, status, recipe_id FROM production_orders WHERE po_number = $1 LIMIT 1",
                                            active["po_number"]
                                        )

                                    if not order_row:
                                        order_row = await conn.fetchrow(
                                            "SELECT id, po_number, status, recipe_id FROM production_orders WHERE plc_id = $1 AND status = 'running' ORDER BY created_at DESC LIMIT 1",
                                            plc_id
                                        )

                                    if order_row:
                                        completed_po_number = order_row["po_number"]
                                        completed_order_id = str(order_row["id"])
                                        if order_row["status"] != "completed":
                                            await conn.execute(
                                                """
                                                UPDATE production_orders
                                                SET status = 'completed', updated_at = NOW(), completed_at = NOW()
                                                WHERE id = $1
                                                """,
                                                completed_order_id
                                            )
                                            logger.info(f"[PLC-SERVICE|POLL] Order {completed_po_number} -> completed (PLC state=9)")
                                            order_updated = True
                                        else:
                                            logger.info(f"[PLC-SERVICE|POLL] Order {completed_po_number} already completed")
                                            order_updated = True
                                    else:
                                        logger.warning(f"[PLC-SERVICE|POLL] State=9 but no running order found for {plc_id}")
                            except Exception as e:
                                logger.error(f"[PLC-SERVICE|POLL] Failed to update completed order: {e}")

                            # STEP 4: Clear PLC tags
                            try:
                                client = self._get_client_for_plc(plc_id)
                                if await self._connect_with_retry(client):
                                    await client.write_tags({
                                        BATCH_STATUS_TAG: 0,
                                        BATCH_ID_TAG: "",
                                        RECIPE_ID_TAG: "",
                                    })
                                    logger.info(f"[PLC-SERVICE|POLL] Cleared PLC batch data for {plc_id}")
                                    await client.disconnect()
                            except Exception as e:
                                logger.warning(f"[PLC-SERVICE|POLL] Failed to clear PLC batch data: {e}")

                            # STEP 5: Update production_data with final metrics
                            if completed_order_id:
                                await self._finalize_production_data(
                                    completed_order_id, completed_po_number or "", plc_id, "completed"
                                )

                            # STEP 6: Clear memory
                            self.clear_active_batch(plc_id)

                            # STEP 7: Broadcast
                            try:
                                from app.core.websocket import ws_manager
                                await ws_manager.broadcast({
                                    "type": "batch_completed",
                                    "plc_id": plc_id,
                                    "po_number": completed_po_number,
                                    "order_id": completed_order_id,
                                    "timestamp": datetime.now(timezone.utc).isoformat(),
                                })
                                logger.info(f"[PLC-SERVICE|POLL] Broadcasted batch_completed for {completed_po_number}")
                            except Exception as e:
                                logger.warning(f"[PLC-SERVICE|POLL] Failed to broadcast batch completion: {e}")

                            # STEP 8: Log
                            if completed_order_id and order_updated:
                                try:
                                    from app.core.database import log_order_execution
                                    await log_order_execution(
                                        order_id=completed_order_id,
                                        po_number=completed_po_number or "",
                                        recipe_id=active.get("recipe_id", "") if active else "",
                                        plc_id=plc_id,
                                        event_type="batch_completed",
                                        message=f"Batch completed. PO: {completed_po_number}"
                                    )
                                except Exception as e:
                                    logger.warning(f"[PLC-SERVICE|POLL] Failed to log order execution: {e}")

                            self._previous_states[plc_id] = batch_state
                            continue

                        # ── CASE 2: PLC has BatchID but not in memory → sync back from DB ──
                        if batch_id and not active:
                            try:
                                async with db.acquire() as conn:
                                    row = await conn.fetchrow(
                                        "SELECT id, status FROM production_orders WHERE po_number = $1 LIMIT 1",
                                        batch_id
                                    )
                                    if row:
                                        self.set_active_batch(plc_id, str(row["id"]), batch_id, "", str(row["status"]))
                                        active = self._active_batches.get(plc_id)
                            except Exception as e:
                                logger.warning(f"[PLC-SERVICE|POLL] Failed to lookup order for {batch_id}: {e}")

                        if not active:
                            self._previous_states[plc_id] = batch_state
                            continue

                        # ── CASE 3: State changed to terminal (IDLE/COMPLETED/ABORTED) ──
                        if batch_state in (0, 9):  # IDLE or COMPLETED
                            if active and active.get("status") == "running":
                                logger.info(
                                    f"[PLC-SERVICE|POLL] {plc_id} active batch {active['po_number']} "
                                    f"with PLC state={batch_state} → marking COMPLETED"
                                )
                                try:
                                    async with db.acquire() as conn:
                                        result = await conn.execute(
                                            """
                                            UPDATE production_orders
                                            SET status = 'completed', updated_at = NOW(), completed_at = NOW()
                                            WHERE id = $1 AND status = 'running'
                                            """,
                                            active["order_id"]
                                        )
                                        logger.info(
                                            f"[PLC-SERVICE|POLL] Order {active['po_number']} -> completed "
                                            f"(terminal state {batch_state}) result={result}"
                                        )

                                    # Update production_data with final metrics
                                    await self._finalize_production_data(
                                        active["order_id"], active["po_number"], plc_id, "completed"
                                    )

                                    # Broadcast completion
                                    try:
                                        from app.core.websocket import ws_manager
                                        await ws_manager.broadcast({
                                            "type": "batch_completed",
                                            "plc_id": plc_id,
                                            "po_number": active["po_number"],
                                            "order_id": active["order_id"],
                                            "timestamp": datetime.now(timezone.utc).isoformat(),
                                        })
                                        logger.info(f"[PLC-SERVICE|POLL] Broadcasted batch_completed for {active['po_number']}")
                                    except Exception as be:
                                        logger.warning(f"[PLC-SERVICE|POLL] Failed to broadcast: {be}")
                                except Exception as e:
                                    logger.error(f"[PLC-SERVICE|POLL] Failed to update completed order: {e}")
                            else:
                                logger.info(
                                    f"[PLC-SERVICE|POLL] {plc_id} state={batch_state} "
                                    f"but no active running batch (active={active})"
                                )
                            self.clear_active_batch(plc_id)

                        elif batch_state == 7:  # ABORTED
                            logger.info(f"[PLC-SERVICE|POLL] {plc_id} batch {active['po_number']} -> aborted")
                            try:
                                async with db.acquire() as conn:
                                    await conn.execute(
                                        """
                                        UPDATE production_orders
                                        SET status = 'cancelled', updated_at = NOW()
                                        WHERE id = $1
                                        """,
                                        active["order_id"]
                                    )
                                # Update production_data with final metrics
                                await self._finalize_production_data(
                                    active["order_id"], active["po_number"], plc_id, "cancelled"
                                )
                            except Exception as e:
                                logger.error(f"[PLC-SERVICE|POLL] Failed to update cancelled order: {e}")
                            self.clear_active_batch(plc_id)

                        else:
                            # Update active batch status and prev_state for non-terminal states
                            self._active_batches[plc_id]["batch_status"] = batch_state
                            self._active_batches[plc_id]["status_name"] = status.get("status_name")
                            self._previous_states[plc_id] = batch_state

                    except Exception as e:
                        logger.warning(f"[PLC-SERVICE|POLL] Error polling {plc_id}: {e}")

                if not all_plc_ids:
                    logger.info("[PLC-SERVICE|POLL] No PLC IDs to poll (no active batches or running orders)")

                await asyncio.sleep(1.0)  # Poll every 1 second
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"[PLC-SERVICE|POLL] Polling error: {e}")
                await asyncio.sleep(1.0)
        logger.info("[PLC-SERVICE|POLL] Batch status polling stopped")

    async def _read_production_metrics(self, plc_id: str) -> Dict[str, Any]:
        """Read production metrics from PLC tags when batch completes/cancels."""
        metrics = {}
        client = self._get_client_for_plc(plc_id)
        try:
            connected = await self._connect_with_retry(client)
            if not connected:
                return metrics

            # Define PLC tags to read for production data (using RoasterAProd prefix)
            tags = [
                "RoasterAProd.BeanTempStart",
                "RoasterAProd.BeanTempEnd",
                "RoasterAProd.DropTemp",
                "RoasterAProd.ChargeTemp",
                "RoasterAProd.TurnaroundTemp",
                "RoasterAProd.TATemp",
                "RoasterAProd.FirstCrackTemp",
                "RoasterAProd.ExhaustTemp",
                "RoasterAProd.InletTemp",
                "RoasterAProd.DrumTemp",
                "RoasterAProd.RoastTime",
                "RoasterAProd.DevTime",
                "RoasterAProd.CoolTime",
                "RoasterAProd.DryingPhase",
                "RoasterAProd.MaillardPhase",
                "RoasterAProd.FC_Time",
                "RoasterAProd.MoistureLoss",
                "RoasterAProd.WeightLoss",
                "RoasterAProd.BurnerPower",
                "RoasterAProd.FanSpeed",
                "RoasterAProd.GasPressure",
                "RoasterAProd.AirFlow",
                "RoasterAProd.DrumSpeed",
            ]

            results = await client.read_tags(tags)
            for r in results:
                if r.status == "Success" and r.value is not None:
                    # Map PLC tag name to DB column name
                    tag_map = {
                        "RoasterAProd.BeanTempStart": "bean_temp_start",
                        "RoasterAProd.BeanTempEnd": "bean_temp_end",
                        "RoasterAProd.DropTemp": "drop_temp",
                        "RoasterAProd.ChargeTemp": "charge_temp",
                        "RoasterAProd.TurnaroundTemp": "turnaround_temp",
                        "RoasterAProd.TATemp": "ta_temp",
                        "RoasterAProd.FirstCrackTemp": "first_crack_temp",
                        "RoasterAProd.ExhaustTemp": "exhaust_temp_avg",
                        "RoasterAProd.InletTemp": "inlet_temp_avg",
                        "RoasterAProd.DrumTemp": "drum_temp_avg",
                        "RoasterAProd.RoastTime": "roast_time",
                        "RoasterAProd.DevTime": "dev_time",
                        "RoasterAProd.CoolTime": "cool_time",
                        "RoasterAProd.DryingPhase": "drying_phase",
                        "RoasterAProd.MaillardPhase": "maillard_phase",
                        "RoasterAProd.FC_Time": "first_crack_time",
                        "RoasterAProd.MoistureLoss": "moisture_loss",
                        "RoasterAProd.WeightLoss": "weight_loss",
                        "RoasterAProd.BurnerPower": "burner_power_avg",
                        "RoasterAProd.FanSpeed": "fan_speed_avg",
                        "RoasterAProd.GasPressure": "gas_pressure_avg",
                        "RoasterAProd.AirFlow": "air_flow_avg",
                        "RoasterAProd.DrumSpeed": "drum_speed",
                    }
                    col_name = tag_map.get(r.tag_name)
                    if col_name:
                        try:
                            metrics[col_name] = float(r.value)
                        except (ValueError, TypeError):
                            metrics[col_name] = r.value

            logger.info(f"[PLC-SERVICE] Read {len(metrics)} production metrics from {plc_id}")
            return metrics
        except Exception as e:
            logger.warning(f"[PLC-SERVICE] Failed to read production metrics: {e}")
            return metrics
        finally:
            await client.disconnect()

    async def _finalize_production_data(self, order_id: str, po_number: str, plc_id: str, status: str):
        """Read PLC metrics and update production_data when batch ends."""
        try:
            metrics = await self._read_production_metrics(plc_id)
            metrics["status"] = status
            metrics["completed_at"] = datetime.now(timezone.utc).isoformat()

            from app.core.database import update_production_data_completed
            result = await update_production_data_completed(
                order_id=order_id,
                status=status,
                bean_temp_start=metrics.get("bean_temp_start"),
                bean_temp_end=metrics.get("bean_temp_end"),
                drop_temp=metrics.get("drop_temp"),
                charge_temp=metrics.get("charge_temp"),
                turnaround_temp=metrics.get("turnaround_temp"),
                ta_temp=metrics.get("ta_temp"),
                first_crack_temp=metrics.get("first_crack_temp"),
                exhaust_temp_avg=metrics.get("exhaust_temp_avg"),
                inlet_temp_avg=metrics.get("inlet_temp_avg"),
                drum_temp_avg=metrics.get("drum_temp_avg"),
                roast_time=metrics.get("roast_time"),
                dev_time=metrics.get("dev_time"),
                cool_time=metrics.get("cool_time"),
                drying_phase=metrics.get("drying_phase"),
                maillard_phase=metrics.get("maillard_phase"),
                first_crack_time=metrics.get("first_crack_time"),
                moisture_loss=metrics.get("moisture_loss"),
                weight_loss=metrics.get("weight_loss"),
                burner_power_avg=metrics.get("burner_power_avg"),
                fan_speed_avg=metrics.get("fan_speed_avg"),
                gas_pressure_avg=metrics.get("gas_pressure_avg"),
                air_flow_avg=metrics.get("air_flow_avg"),
                drum_speed=metrics.get("drum_speed"),
            )
            logger.info(f"[PLC-SERVICE] Updated production_data for {po_number} -> {status}, result={result}")
        except Exception as e:
            logger.error(f"[PLC-SERVICE] Failed to finalize production_data for {po_number}: {e}")

    async def stop_worker(self):
        """Stop background worker."""
        self._running = False
        await self._download_queue.join()
        logger.info("[PLC-SERVICE] Download worker stopped")

    async def _process_download_queue(self):
        """Background worker to process download jobs."""
        logger.info("[PLC-SERVICE|WORKER] Queue processor started")
        while self._running:
            try:
                job = await asyncio.wait_for(
                    self._download_queue.get(), timeout=1.0
                )
                logger.info(f"[PLC-SERVICE|WORKER] Dequeued job: tx_id={job.get('transaction_id')}")
                await self._execute_download(job)
                self._download_queue.task_done()
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"[PLC-SERVICE|WORKER] Error in download worker: {e}", exc_info=True)

    async def _execute_download(self, job: Dict[str, Any]):
        """Execute single download job with full transaction logic and logging."""
        tx_id = job["transaction_id"]
        recipe_id = job["recipe_id"]
        plc_id = job["plc_id"]
        user = job["user"]
        validate = job.get("validate", True)
        backup = job.get("backup_current", True)
        po_number = job.get("po_number")

        start_time = datetime.now(timezone.utc)
        t0 = time.perf_counter()

        logger.info(
            f"[PLC-SERVICE|DOWNLOAD|{tx_id}] START "
            f"recipe_id={recipe_id}, plc_id={plc_id}, user={user}, "
            f"validate={validate}, backup={backup}, po_number={po_number}"
        )

        try:
            # 1. Get recipe from DB
            logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 1/9: Fetching recipe from DB...")
            recipe = await get_recipe_by_id(recipe_id)
            if not recipe:
                raise ValueError(f"Recipe {recipe_id} not found")
            logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 1/9: Recipe found: code={recipe.get('recipe_code')}, params={len(recipe.get('parameters', []))}")

            # 2. Validate parameters
            if validate:
                logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 2/9: Validating parameters...")
                validation = await self._validate_parameters(recipe)
                if not validation["valid"]:
                    raise ValueError(f"Validation failed: {validation['errors']}")
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 2/9: Validation passed")
            else:
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 2/9: Validation skipped")

            # 3. Get PLC client
            logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 3/9: Getting PLC client for {plc_id}...")
            plc_client = self._get_client_for_plc(plc_id)
            logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 3/9: PLC client ready")

            # 4. Connect to PLC
            logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 4/9: Connecting to PLC...")
            connected = await self._connect_with_retry(plc_client)
            if not connected:
                raise ConnectionError(f"Cannot connect to PLC {plc_id} after {settings.PLC_RETRY_ATTEMPTS} attempts")
            logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 4/9: PLC connected")

            try:
                # 5. Backup current recipe on PLC (if enabled)
                if backup:
                    logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 5/9: Backing up current PLC values...")
                    await self._backup_current_recipe(plc_client, plc_id, recipe)
                    logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 5/9: Backup complete")
                else:
                    logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 5/9: Backup skipped")

                # 6. Write parameters to PLC
                logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 6/9: Writing recipe parameters to PLC...")
                write_results = await self._write_recipe_to_plc(
                    plc_client, recipe, plc_id
                )
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 6/9: Wrote {len(write_results)} tags")

                # 7. Write PO Number to PLC if provided
                po_written = False
                if po_number:
                    logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 7/9: Writing PO Number '{po_number}' to PLC...")
                    po_result = await plc_client.write_tag("RoasterA.PONumber", po_number)
                    if po_result.status == "Success":
                        po_written = True
                        logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 7/9: PO Number written successfully")
                    else:
                        logger.warning(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 7/9: PO Number write FAILED - {po_result.error}")
                else:
                    logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 7/9: No PO Number to write")

                # 8. Verify write (read back)
                logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 8/9: Verifying written values...")
                verified = await self._verify_plc_write(plc_client, write_results)
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Step 8/9: Verification {'PASSED' if verified else 'FAILED'}")

                # 9. Log success
                duration_ms = int((time.perf_counter() - t0) * 1000)
                await log_recipe_download(
                    recipe_id=recipe_id,
                    plc_id=plc_id,
                    downloaded_by=user,
                    status="SUCCESS",
                    duration_ms=duration_ms,
                    plc_ack=verified
                )

                if job.get("order_id"):
                    from app.core.database import log_order_execution
                    await log_order_execution(
                        order_id=job["order_id"],
                        po_number=po_number or "",
                        recipe_id=recipe_id,
                        plc_id=plc_id,
                        event_type="download_success",
                        message=f"Recipe downloaded successfully. PO: {po_number or 'N/A'}"
                    )

                await log_process_event(
                    event_type="RECIPE_DOWNLOADED",
                    plc_id=plc_id,
                    recipe_id=recipe_id,
                    severity=1,
                    message=f"Recipe {recipe['recipe_code']} downloaded successfully"
                )

                self._download_results[tx_id] = {
                    "status": "SUCCESS",
                    "message": "Recipe downloaded to PLC successfully",
                    "duration_ms": duration_ms,
                    "verified": verified,
                    "tags_written": len(write_results)
                }

                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] SUCCESS in {duration_ms}ms, verified={verified}")

            finally:
                logger.debug(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] Disconnecting from PLC...")
                await plc_client.disconnect()
                logger.info(f"[PLC-SERVICE|DOWNLOAD|{tx_id}] PLC disconnected")

        except Exception as e:
            duration_ms = int((time.perf_counter() - t0) * 1000)
            error_msg = str(e)
            logger.error(
                f"[PLC-SERVICE|DOWNLOAD|{tx_id}] FAILED after {duration_ms}ms - {type(e).__name__}: {error_msg}",
                exc_info=True
            )

            await log_recipe_download(
                recipe_id=recipe_id,
                plc_id=plc_id,
                downloaded_by=user,
                status="FAILED",
                error_message=error_msg,
                duration_ms=duration_ms
            )

            await log_process_event(
                event_type="RECIPE_DOWNLOAD_FAILED",
                plc_id=plc_id,
                recipe_id=recipe_id,
                severity=3,
                message=f"Download failed: {error_msg}"
            )

            self._download_results[tx_id] = {
                "status": "FAILED",
                "message": error_msg,
                "duration_ms": duration_ms
            }

    def _get_client_for_plc(self, plc_id: str):
        """Get appropriate client for PLC (PyLogix or OPC UA)."""
        if settings.OPC_UA_ENDPOINT:
            logger.debug(f"[PLC-SERVICE] Using OPC UA client for {plc_id}")
            return get_opcua_client(
                plc_id=plc_id,
                endpoint=settings.OPC_UA_ENDPOINT,
                username=settings.OPC_UA_USERNAME,
                password=settings.OPC_UA_PASSWORD
            )
        else:
            logger.debug(f"[PLC-SERVICE] Using PyLogix client for {plc_id} (host={settings.PLC_HOST}, slot={settings.PLC_SLOT})")
            return get_plc_client(
                plc_id=plc_id,
                host=settings.PLC_HOST,
                slot=settings.PLC_SLOT,
                timeout=settings.PLC_TIMEOUT
            )

    async def _connect_with_retry(self, client) -> bool:
        """Connect to PLC with retry logic and detailed logging."""
        for attempt in range(settings.PLC_RETRY_ATTEMPTS):
            logger.info(f"[PLC-SERVICE] Connection attempt {attempt + 1}/{settings.PLC_RETRY_ATTEMPTS}...")
            try:
                connected = await client.connect()
                if connected:
                    logger.info(f"[PLC-SERVICE] Connection SUCCESS on attempt {attempt + 1}")
                    return True
                else:
                    logger.warning(f"[PLC-SERVICE] Connection returned False on attempt {attempt + 1}")
            except Exception as e:
                logger.warning(f"[PLC-SERVICE] Connection attempt {attempt + 1} EXCEPTION: {type(e).__name__}: {e}")

            if attempt < settings.PLC_RETRY_ATTEMPTS - 1:
                wait_sec = settings.PLC_RETRY_DELAY * (attempt + 1)
                logger.info(f"[PLC-SERVICE] Waiting {wait_sec}s before retry...")
                await asyncio.sleep(wait_sec)

        logger.error(f"[PLC-SERVICE] All {settings.PLC_RETRY_ATTEMPTS} connection attempts failed")
        return False

    async def _validate_parameters(self, recipe: Dict[str, Any]) -> Dict[str, Any]:
        """Validate recipe parameters before sending to PLC."""
        errors = []
        logger.debug(f"[PLC-SERVICE] Validating {len(recipe.get('parameters', []))} parameters")

        for param in recipe.get("parameters", []):
            val = param.get("value_default")
            min_val = param.get("value_min")
            max_val = param.get("value_max")
            plc_tag = param.get("plc_tag")

            if not plc_tag:
                errors.append(f"{param['param_name']}: Missing PLC tag")
                continue

            if val is None:
                errors.append(f"{param['param_name']}: No value to write")
                continue

            try:
                numeric_val = float(val)
                if min_val is not None and numeric_val < min_val:
                    errors.append(f"{param['param_name']}: {numeric_val} < min {min_val}")
                if max_val is not None and numeric_val > max_val:
                    errors.append(f"{param['param_name']}: {numeric_val} > max {max_val}")
            except (ValueError, TypeError):
                pass

        valid = len(errors) == 0
        if not valid:
            logger.warning(f"[PLC-SERVICE] Validation FAILED: {errors}")
        else:
            logger.debug("[PLC-SERVICE] Validation PASSED")
        return {"valid": valid, "errors": errors}

    async def _backup_current_recipe(self, client, plc_id: str, recipe: Dict[str, Any]):
        """Backup current PLC values before writing new recipe."""
        tag_names = [p["plc_tag"] for p in recipe.get("parameters", []) if p.get("plc_tag")]
        if not tag_names:
            logger.debug("[PLC-SERVICE] No tags to backup")
            return

        logger.info(f"[PLC-SERVICE] Backing up {len(tag_names)} tags from PLC {plc_id}...")
        results = await client.read_tags(tag_names)
        backup_data = []
        for result in results:
            if result.status == "Success":
                backup_data.append({
                    "time": datetime.now(timezone.utc),
                    "plc_id": plc_id,
                    "tag_name": result.tag_name,
                    "tag_value": result.value,
                    "tag_quality": 192,
                    "recipe_id": recipe.get("id")
                })

        if backup_data:
            await insert_tag_values_batch(backup_data)
            logger.info(f"[PLC-SERVICE] Backed up {len(backup_data)} tags")
        else:
            logger.warning("[PLC-SERVICE] Backup: no tags were read successfully")

    async def _write_recipe_to_plc(
        self, client, recipe: Dict[str, Any], plc_id: str
    ) -> List[Dict[str, Any]]:
        """Write recipe parameters to PLC tags."""
        tags_to_write = {}
        for param in recipe.get("parameters", []):
            tag = param.get("plc_tag")
            val = param.get("value_default")
            if tag and val is not None:
                casted_val = self._cast_value(val, param.get("param_type", "REAL"))
                tags_to_write[tag] = casted_val

        if not tags_to_write:
            raise ValueError("No valid tags to write")

        logger.info(f"[PLC-SERVICE] Writing {len(tags_to_write)} tags to PLC {plc_id}...")
        logger.debug(f"[PLC-SERVICE] Tags to write: {tags_to_write}")

        results = await client.write_tags(tags_to_write)

        failed = [r for r in results if r.status != "Success"]
        if failed:
            failed_tags = [f"{r.tag_name}: {r.error}" for r in failed]
            raise RuntimeError(f"Failed to write tags: {', '.join(failed_tags)}")

        return [{"tag": r.tag_name, "value": r.value} for r in results]

    def _cast_value(self, value: Any, param_type: str) -> Any:
        """Cast value to appropriate PLC type."""
        type_map = {
            "BOOL": bool,
            "INT": int,
            "DINT": int,
            "REAL": float,
            "STRING": str
        }
        caster = type_map.get(param_type, float)
        try:
            return caster(value)
        except (ValueError, TypeError):
            logger.warning(f"[PLC-SERVICE] Cast failed for {value!r} to {param_type}, returning as-is")
            return value

    async def _verify_plc_write(self, client, write_results: List[Dict[str, Any]]) -> bool:
        """Verify written values by reading them back."""
        tag_names = [w["tag"] for w in write_results]
        logger.debug(f"[PLC-SERVICE] Verifying {len(tag_names)} tags by read-back...")
        read_results = await client.read_tags(tag_names)

        all_match = True
        mismatches = []
        for write, read in zip(write_results, read_results):
            if read.status != "Success":
                all_match = False
                mismatches.append(f"{read.tag_name}: read failed ({read.error})")
                continue

            try:
                if abs(float(write["value"]) - float(read.value)) > 0.001:
                    all_match = False
                    mismatches.append(f"{read.tag_name}: wrote={write['value']}, read={read.value}")
            except (ValueError, TypeError):
                if str(write["value"]) != str(read.value):
                    all_match = False
                    mismatches.append(f"{read.tag_name}: wrote={write['value']!r}, read={read.value!r}")

        if mismatches:
            logger.warning(f"[PLC-SERVICE] Verification FAILED: {mismatches}")
        else:
            logger.debug("[PLC-SERVICE] Verification PASSED")
        return all_match

    # ─── Public API Methods ───

    async def queue_download(
        self, recipe_id: str, plc_id: str, user: str = "system",
        validate: bool = True, backup_current: bool = True,
        po_number: str = None, order_id: str = None
    ) -> str:
        """Queue a recipe download job."""
        tx_id = str(uuid.uuid4())
        job = {
            "transaction_id": tx_id,
            "recipe_id": recipe_id,
            "plc_id": plc_id,
            "user": user,
            "validate": validate,
            "backup_current": backup_current,
            "po_number": po_number,
            "order_id": order_id,
            "queued_at": datetime.now(timezone.utc).isoformat()
        }

        await self._download_queue.put(job)
        self._download_results[tx_id] = {"status": "PENDING"}

        logger.info(f"[PLC-SERVICE] Download queued: tx_id={tx_id}, recipe_id={recipe_id}, plc_id={plc_id}")
        return tx_id

    async def get_download_status(self, transaction_id: str) -> Dict[str, Any]:
        """Get download job status."""
        result = self._download_results.get(transaction_id, {"status": "NOT_FOUND"})
        logger.debug(f"[PLC-SERVICE] Download status for {transaction_id}: {result['status']}")
        return result

    async def read_plc_tags(self, plc_id: str, tag_names: List[str]) -> Dict[str, Any]:
        """Read tags from PLC directly."""
        logger.info(f"[PLC-SERVICE] read_plc_tags: plc_id={plc_id}, tags={tag_names}")
        client = self._get_client_for_plc(plc_id)

        try:
            connected = await self._connect_with_retry(client)
            if not connected:
                raise ConnectionError(f"Cannot connect to PLC {plc_id}")

            results = await client.read_tags(tag_names)

            # Log to TimescaleDB
            tag_values = []
            for r in results:
                if r.status == "Success":
                    tag_values.append({
                        "time": datetime.now(timezone.utc),
                        "plc_id": plc_id,
                        "tag_name": r.tag_name,
                        "tag_value": r.value,
                        "tag_quality": 192
                    })

            if tag_values:
                await insert_tag_values_batch(tag_values)
                logger.info(f"[PLC-SERVICE] read_plc_tags: Logged {len(tag_values)} tag values to DB")

            success_tags = [r.tag_name for r in results if r.status == "Success"]
            failed_tags = [(r.tag_name, r.error) for r in results if r.status != "Success"]
            logger.info(f"[PLC-SERVICE] read_plc_tags: success={len(success_tags)}, failed={len(failed_tags)}")
            if failed_tags:
                logger.warning(f"[PLC-SERVICE] read_plc_tags failed: {failed_tags}")

            return {
                "plc_id": plc_id,
                "results": [
                    {"tag": r.tag_name, "value": r.value, "status": r.status, "error": r.error}
                    for r in results
                ]
            }
        finally:
            await client.disconnect()

    async def write_plc_tags(
        self, plc_id: str, tags: Dict[str, Any], user: str = "system"
    ) -> Dict[str, Any]:
        """Write tags to PLC directly."""
        logger.info(f"[PLC-SERVICE] write_plc_tags: plc_id={plc_id}, tags={list(tags.keys())}")
        client = self._get_client_for_plc(plc_id)

        try:
            connected = await self._connect_with_retry(client)
            if not connected:
                raise ConnectionError(f"Cannot connect to PLC {plc_id}")

            results = await client.write_tags(tags)

            # Log to TimescaleDB
            tag_values = []
            for r in results:
                if r.status == "Success":
                    tag_values.append({
                        "time": datetime.now(timezone.utc),
                        "plc_id": plc_id,
                        "tag_name": r.tag_name,
                        "tag_value": r.value,
                        "tag_quality": 192
                    })

            if tag_values:
                await insert_tag_values_batch(tag_values)

            success = {r.tag_name: r.value for r in results if r.status == "Success"}
            failed = {r.tag_name: r.error for r in results if r.status != "Success"}

            await log_process_event(
                event_type="PLC_TAGS_WRITTEN" if not failed else "PLC_TAGS_PARTIAL",
                plc_id=plc_id,
                severity=1 if not failed else 2,
                message=f"Wrote {len(success)} tags, failed {len(failed)}"
            )

            logger.info(f"[PLC-SERVICE] write_plc_tags: success={len(success)}, failed={len(failed)}")
            if failed:
                logger.warning(f"[PLC-SERVICE] write_plc_tags failed details: {failed}")

            return {"plc_id": plc_id, "success": success, "failed": failed}
        finally:
            await client.disconnect()


# Global service instance
plc_service = PlcService()


# ─── Batch State Machine ───
from enum import Enum

class BatchStatus(Enum):
    """Roaster batch state machine states."""
    IDLE = 0
    INITIALIZING = 1
    READY = 2
    RUNNING = 3
    HOLDING = 4
    HELD = 5
    ABORTING = 6
    ABORTED = 7
    COMPLETING = 8
    COMPLETED = 9


class BatchControlCommand(Enum):
    """Commands to control batch state."""
    INITIALIZE = "initialize"
    START = "start"
    HOLD = "hold"
    ABORT = "abort"
    RESET = "reset"


# State Transition Rules: {current_status: {command: new_status}}
STATE_TRANSITIONS = {
    BatchStatus.IDLE: {BatchControlCommand.INITIALIZE: BatchStatus.INITIALIZING, BatchControlCommand.RESET: BatchStatus.IDLE},
    BatchStatus.INITIALIZING: {BatchControlCommand.ABORT: BatchStatus.ABORTING, BatchControlCommand.RESET: BatchStatus.IDLE},
    BatchStatus.READY: {BatchControlCommand.START: BatchStatus.RUNNING, BatchControlCommand.ABORT: BatchStatus.ABORTING, BatchControlCommand.RESET: BatchStatus.IDLE},
    BatchStatus.RUNNING: {BatchControlCommand.HOLD: BatchStatus.HOLDING, BatchControlCommand.ABORT: BatchStatus.ABORTING, BatchControlCommand.RESET: BatchStatus.IDLE},
    BatchStatus.HOLDING: {BatchControlCommand.ABORT: BatchStatus.ABORTING, BatchControlCommand.RESET: BatchStatus.IDLE},
    BatchStatus.HELD: {BatchControlCommand.START: BatchStatus.RUNNING, BatchControlCommand.ABORT: BatchStatus.ABORTING, BatchControlCommand.RESET: BatchStatus.IDLE},
    BatchStatus.ABORTING: {BatchControlCommand.RESET: BatchStatus.IDLE},
    BatchStatus.ABORTED: {BatchControlCommand.INITIALIZE: BatchStatus.INITIALIZING, BatchControlCommand.RESET: BatchStatus.IDLE},
    BatchStatus.COMPLETING: {BatchControlCommand.RESET: BatchStatus.IDLE},
    BatchStatus.COMPLETED: {BatchControlCommand.INITIALIZE: BatchStatus.INITIALIZING, BatchControlCommand.RESET: BatchStatus.IDLE},
}

# Allowed commands per state
ALLOWED_COMMANDS = {
    BatchStatus.IDLE: [BatchControlCommand.INITIALIZE, BatchControlCommand.RESET],
    BatchStatus.INITIALIZING: [BatchControlCommand.ABORT, BatchControlCommand.RESET],
    BatchStatus.READY: [BatchControlCommand.START, BatchControlCommand.ABORT, BatchControlCommand.RESET],
    BatchStatus.RUNNING: [BatchControlCommand.HOLD, BatchControlCommand.ABORT, BatchControlCommand.RESET],
    BatchStatus.HOLDING: [BatchControlCommand.ABORT, BatchControlCommand.RESET],
    BatchStatus.HELD: [BatchControlCommand.START, BatchControlCommand.ABORT, BatchControlCommand.RESET],
    BatchStatus.ABORTING: [BatchControlCommand.RESET],
    BatchStatus.ABORTED: [BatchControlCommand.INITIALIZE, BatchControlCommand.RESET],
    BatchStatus.COMPLETING: [BatchControlCommand.RESET],
    BatchStatus.COMPLETED: [BatchControlCommand.INITIALIZE, BatchControlCommand.RESET],
}

# PLC Tag names for batch control
BATCH_STATUS_TAG = "RoasterA.BatchStatus"
CMD_INIT_TAG = "RoasterA.CmdInitialize"
CMD_START_TAG = "RoasterA.CmdStart"
CMD_HOLD_TAG = "RoasterA.CmdHold"
CMD_ABORT_TAG = "RoasterA.CmdAbort"
CMD_RESET_TAG = "RoasterA.CmdReset"
BATCH_ID_TAG = "RoasterA.BatchID"
RECIPE_ID_TAG = "RoasterA.RecipeID"


async def get_batch_status(plc_id: str) -> Dict[str, Any]:
    """Get detailed batch status with allowed actions."""
    logger.info(f"[BATCH-STATUS] Getting batch status for {plc_id}...")
    client = plc_service._get_client_for_plc(plc_id)
    try:
        connected = await plc_service._connect_with_retry(client)
        if not connected:
            logger.error(f"[BATCH-STATUS] PLC {plc_id} is OFFLINE")
            return {
                "plc_id": plc_id,
                "batch_status": 0,
                "status_name": "OFFLINE",
                "is_online": False,
                "can_initialize": False,
                "can_start": False,
                "can_hold": False,
                "can_abort": False,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        logger.debug(f"[BATCH-STATUS] Reading tags: {[BATCH_STATUS_TAG, BATCH_ID_TAG, RECIPE_ID_TAG]}")
        results = await client.read_tags([BATCH_STATUS_TAG, BATCH_ID_TAG, RECIPE_ID_TAG])
        status_result = next((r for r in results if r.tag_name == BATCH_STATUS_TAG), None)
        batch_id_result = next((r for r in results if r.tag_name == BATCH_ID_TAG), None)
        recipe_id_result = next((r for r in results if r.tag_name == RECIPE_ID_TAG), None)

        raw_status = status_result.value if status_result and status_result.status == "Success" else 0
        logger.debug(f"[BATCH-STATUS] Raw status value: {raw_status!r}")
        try:
            current_status = BatchStatus(int(raw_status))
        except (ValueError, TypeError):
            logger.warning(f"[BATCH-STATUS] Invalid status value: {raw_status!r}, defaulting to IDLE")
            current_status = BatchStatus.IDLE

        allowed = ALLOWED_COMMANDS.get(current_status, [])
        
        # Read BatchID from PLC - this is the SOURCE OF TRUTH for active batch
        batch_id_from_plc = None
        if batch_id_result and batch_id_result.status == "Success":
            val = batch_id_result.value
            if val is not None and str(val).strip():
                batch_id_from_plc = str(val).strip()
        
        # If BatchID is set in PLC, there IS an active batch regardless of BatchStatus
        # This prevents the "INITIALIZING -> IDLE" bounce problem
        active_batch = None
        if batch_id_from_plc:
            # Try to find matching order in DB
            try:
                async with db.acquire() as conn:
                    row = await conn.fetchrow(
                        "SELECT id, po_number, recipe_id, status FROM production_orders WHERE po_number = $1 LIMIT 1",
                        batch_id_from_plc
                    )
                    if row:
                        active_batch = {
                            "order_id": str(row["id"]),
                            "po_number": str(row["po_number"]),
                            "recipe_id": str(row["recipe_id"]) if row["recipe_id"] else None,
                            "status": str(row["status"]),
                        }
                    else:
                        active_batch = {
                            "order_id": None,
                            "po_number": batch_id_from_plc,
                            "recipe_id": None,
                            "status": "unknown",
                        }
            except Exception as e:
                logger.warning(f"[BATCH-STATUS] Failed to lookup order for BatchID {batch_id_from_plc}: {e}")
                active_batch = {
                    "order_id": None,
                    "po_number": batch_id_from_plc,
                    "recipe_id": None,
                    "status": "unknown",
                }
            
            # Sync backend memory with PLC reality
            existing_mem = plc_service.get_active_batch(plc_id)
            if not existing_mem or existing_mem.get("po_number") != batch_id_from_plc:
                plc_service._active_batches[plc_id] = {
                    **active_batch,
                    "started_at": datetime.now(timezone.utc).isoformat()
                }
        else:
            # No BatchID in PLC - but if PLC state is NOT IDLE/COMPLETED/ABORTED, keep memory active batch
            # This handles the "INITIALIZING -> IDLE" bounce where PLC resets BatchID quickly
            if current_status not in (BatchStatus.IDLE, BatchStatus.COMPLETED, BatchStatus.ABORTED):
                mem_batch = plc_service.get_active_batch(plc_id)
                if mem_batch and mem_batch.get("po_number"):
                    batch_id_from_plc = mem_batch["po_number"]
                    active_batch = mem_batch
                    logger.info(f"[BATCH-STATUS] PLC state={current_status.name} but BatchID empty, using memory fallback: {batch_id_from_plc}")
            else:
                # PLC is IDLE/COMPLETED/ABORTED and BatchID is empty - clear stale memory
                if plc_service.get_active_batch(plc_id):
                    logger.info(f"[BATCH-STATUS] PLC {current_status.name} and BatchID empty, clearing stale active batch for {plc_id}")
                    plc_service.clear_active_batch(plc_id)
        
        # PLC is available for init when state is IDLE, COMPLETED, or ABORTED
        plc_available = current_status in (BatchStatus.IDLE, BatchStatus.COMPLETED, BatchStatus.ABORTED)
        
        result = {
            "plc_id": plc_id,
            "batch_status": current_status.value,
            "status_name": current_status.name,
            "batch_id": batch_id_from_plc,  # Always return batch_id so polling can read it before clear
            "recipe_id": recipe_id_result.value if recipe_id_result and recipe_id_result.status == "Success" else None,
            "is_online": True,
            "can_initialize": BatchControlCommand.INITIALIZE in allowed and plc_available,
            "can_start": BatchControlCommand.START in allowed,
            "can_hold": BatchControlCommand.HOLD in allowed,
            "can_abort": BatchControlCommand.ABORT in allowed,
            "can_reset": BatchControlCommand.RESET in allowed,
            "active_batch": active_batch,  # Always return active_batch for polling reference
            "plc_available": plc_available,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        logger.info(
            f"[BATCH-STATUS] {plc_id}: status={current_status.name}({current_status.value}), "
            f"batch_id='{batch_id_from_plc}', allowed={[c.value for c in allowed]}"
        )
        return result
    except Exception as e:
        logger.error(f"[BATCH-STATUS] Error reading batch status for {plc_id}: {type(e).__name__}: {e}", exc_info=True)
        return {
            "plc_id": plc_id,
            "batch_status": 0,
            "status_name": "ERROR",
            "is_online": False,
            "can_initialize": False,
            "can_start": False,
            "can_hold": False,
            "can_abort": False,
            "can_reset": False,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    finally:
        await client.disconnect()
        logger.debug(f"[BATCH-STATUS] Disconnected from {plc_id}")


async def control_batch(
    plc_id: str,
    command: str,
    recipe_id: str = None,
    po_number: str = None,
    order_id: str = None
) -> Dict[str, Any]:
    """Execute batch control command with state machine validation."""
    logger.info(f"[BATCH-CONTROL] Request: plc_id={plc_id}, command={command}, recipe_id={recipe_id}, po_number={po_number}")
    client = plc_service._get_client_for_plc(plc_id)
    start_time = datetime.now(timezone.utc)
    t0 = time.perf_counter()

    try:
        # Connect
        logger.debug(f"[BATCH-CONTROL] Connecting to {plc_id}...")
        connected = await plc_service._connect_with_retry(client)
        if not connected:
            raise ConnectionError(f"Cannot connect to PLC {plc_id}")
        logger.info(f"[BATCH-CONTROL] Connected to {plc_id}")

        # Read current status
        logger.debug(f"[BATCH-CONTROL] Reading current batch status from {plc_id}...")
        results = await client.read_tags([BATCH_STATUS_TAG])
        status_result = next((r for r in results if r.tag_name == BATCH_STATUS_TAG), None)
        raw_status = status_result.value if status_result and status_result.status == "Success" else 0
        logger.info(f"[BATCH-CONTROL] Current raw status: {raw_status!r}")
        try:
            previous_status = BatchStatus(int(raw_status))
        except (ValueError, TypeError):
            logger.warning(f"[BATCH-CONTROL] Invalid status {raw_status!r}, assuming IDLE")
            previous_status = BatchStatus.IDLE

        # Parse command
        try:
            cmd = BatchControlCommand(command)
        except ValueError:
            logger.error(f"[BATCH-CONTROL] Unknown command: {command}")
            return {
                "plc_id": plc_id,
                "command": command,
                "previous_status": previous_status.value,
                "current_status": previous_status.value,
                "status_name": previous_status.name,
                "success": False,
                "message": f"Unknown command: {command}",
                "timestamp": start_time.isoformat(),
            }

        # Validate state transition
        allowed = STATE_TRANSITIONS.get(previous_status, {})
        new_status = allowed.get(cmd)
        logger.debug(f"[BATCH-CONTROL] Transition check: {previous_status.name} + {cmd.value} -> {new_status.name if new_status else 'BLOCKED'}")

        if new_status is None:
            allowed_names = [c.value for c in ALLOWED_COMMANDS.get(previous_status, [])]
            logger.warning(f"[BATCH-CONTROL] BLOCKED: Cannot {command} from {previous_status.name}. Allowed: {allowed_names}")
            return {
                "plc_id": plc_id,
                "command": command,
                "previous_status": previous_status.value,
                "current_status": previous_status.value,
                "status_name": previous_status.name,
                "success": False,
                "message": f"Cannot {command} from {previous_status.name}. Allowed: {allowed_names}",
                "timestamp": start_time.isoformat(),
            }

        # ─── Execute command ───
        if cmd == BatchControlCommand.INITIALIZE:
            # Read BatchID from PLC first - source of truth for interlock
            logger.debug(f"[BATCH-CONTROL] Reading BatchID from PLC for interlock check...")
            id_results = await client.read_tags([BATCH_ID_TAG])
            id_result = next((r for r in id_results if r.tag_name == BATCH_ID_TAG), None)
            current_batch_id = str(id_result.value).strip() if id_result and id_result.status == "Success" and id_result.value else ""
            
            # Block if PLC is busy (not IDLE/COMPLETED/ABORTED) AND has a batch loaded
            if previous_status not in (BatchStatus.IDLE, BatchStatus.COMPLETED, BatchStatus.ABORTED) and current_batch_id:
                logger.warning(f"[BATCH-CONTROL] BLOCKED: PLC {plc_id} busy with batch '{current_batch_id}', state={previous_status.name}")
                return {
                    "plc_id": plc_id,
                    "command": command,
                    "previous_status": previous_status.value,
                    "current_status": previous_status.value,
                    "status_name": previous_status.name,
                    "success": False,
                    "message": f"PLC is busy with batch: {current_batch_id}. Please reset or wait for completion.",
                    "timestamp": start_time.isoformat(),
                }

            # Block if currently running (PLC state check)
            if previous_status in (BatchStatus.RUNNING, BatchStatus.HOLDING, BatchStatus.HELD):
                logger.warning(f"[BATCH-CONTROL] BLOCKED: Cannot initialize while {previous_status.name}")
                return {
                    "plc_id": plc_id,
                    "command": command,
                    "previous_status": previous_status.value,
                    "current_status": previous_status.value,
                    "status_name": previous_status.name,
                    "success": False,
                    "message": f"Cannot initialize while batch is {previous_status.name}. Please abort first.",
                    "timestamp": start_time.isoformat(),
                }

            # Fetch recipe and write parameters
            if not recipe_id:
                logger.error("[BATCH-CONTROL] BLOCKED: recipe_id is required for initialize")
                return {
                    "plc_id": plc_id,
                    "command": command,
                    "previous_status": previous_status.value,
                    "current_status": previous_status.value,
                    "status_name": previous_status.name,
                    "success": False,
                    "message": "Recipe ID is required for initialize command.",
                    "timestamp": start_time.isoformat(),
                }

            logger.info(f"[BATCH-CONTROL] Fetching recipe {recipe_id} from DB...")
            recipe = await get_recipe_by_id(recipe_id)
            if not recipe:
                raise ValueError(f"Recipe {recipe_id} not found")
            logger.info(f"[BATCH-CONTROL] Recipe found: {recipe.get('recipe_code')}, {len(recipe.get('parameters', []))} params")

            tags_to_write = {}
            for param in recipe.get("parameters", []):
                tag = param.get("plc_tag")
                val = param.get("value_default")
                if tag and val is not None:
                    casted_val = plc_service._cast_value(val, param.get("param_type", "REAL"))
                    tags_to_write[tag] = casted_val

            if tags_to_write:
                logger.info(f"[BATCH-CONTROL] Writing {len(tags_to_write)} recipe tags to PLC...")
                write_results = await client.write_tags(tags_to_write)
                failed = [r for r in write_results if r.status != "Success"]
                if failed:
                    failed_tags = [f"{r.tag_name}: {r.error}" for r in failed]
                    raise RuntimeError(f"Failed to write recipe tags: {', '.join(failed_tags)}")
                logger.info(f"[BATCH-CONTROL] Recipe tags written successfully")
            else:
                logger.warning("[BATCH-CONTROL] No recipe tags to write")

            # Set batch info and trigger initialize
            # BatchID = PO Number (persists in PLC as active batch identifier)
            init_tags = {
                BATCH_STATUS_TAG: new_status.value,
                BATCH_ID_TAG: po_number or "",
                RECIPE_ID_TAG: recipe_id or "",
                CMD_INIT_TAG: True,
            }
            logger.info(f"[BATCH-CONTROL] Writing init tags: BatchStatus={new_status.value}, BatchID='{po_number}', RecipeID='{recipe_id}'")
            await client.write_tags(init_tags)
            logger.debug("[BATCH-CONTROL] Waiting 200ms before clearing pulse...")
            await asyncio.sleep(0.2)
            await client.write_tags({CMD_INIT_TAG: False})
            logger.info("[BATCH-CONTROL] Initialize pulse cleared")

            # Track active batch + create production_data record
            if order_id and po_number:
                plc_service.set_active_batch(plc_id, order_id, po_number, recipe_id or "", "initializing")
                # Create production_data record for tracking
                try:
                    from app.core.database import create_production_data
                    pd_id = await create_production_data(
                        order_id=order_id,
                        po_number=po_number,
                        recipe_id=recipe_id or "",
                        plc_id=plc_id,
                        operator="system"
                    )
                    logger.info(f"[BATCH-CONTROL] Created production_data record {pd_id} for {po_number}")
                except Exception as e:
                    logger.warning(f"[BATCH-CONTROL] Failed to create production_data: {e}")

        elif cmd == BatchControlCommand.START:
            start_tags = {
                BATCH_STATUS_TAG: new_status.value,
                CMD_START_TAG: True,
            }
            logger.info(f"[BATCH-CONTROL] Writing start tags: {start_tags}")
            await client.write_tags(start_tags)
            await asyncio.sleep(0.2)
            await client.write_tags({CMD_START_TAG: False})
            logger.info("[BATCH-CONTROL] Start pulse cleared")

            # Update active batch status to running
            active = plc_service.get_active_batch(plc_id)
            if active:
                active["status"] = "running"
                logger.info(f"[BATCH-CONTROL] Active batch {active.get('po_number')} status -> running")

        elif cmd == BatchControlCommand.HOLD:
            hold_tags = {
                BATCH_STATUS_TAG: new_status.value,
                CMD_HOLD_TAG: True,
            }
            logger.info(f"[BATCH-CONTROL] Writing hold tags: {hold_tags}")
            await client.write_tags(hold_tags)
            await asyncio.sleep(0.2)
            await client.write_tags({CMD_HOLD_TAG: False})
            logger.info("[BATCH-CONTROL] Hold pulse cleared")

        elif cmd == BatchControlCommand.ABORT:
            abort_tags = {
                BATCH_STATUS_TAG: new_status.value,
                CMD_ABORT_TAG: True,
            }
            logger.info(f"[BATCH-CONTROL] Writing abort tags: {abort_tags}")
            await client.write_tags(abort_tags)
            await asyncio.sleep(0.2)
            await client.write_tags({CMD_ABORT_TAG: False})
            logger.info("[BATCH-CONTROL] Abort pulse cleared")

            # Clear active batch and update DB
            active = plc_service.get_active_batch(plc_id)
            if active and active.get("order_id"):
                from app.core.database import update_order_status
                await update_order_status(active["order_id"], "cancelled")
                logger.info(f"[BATCH-CONTROL] Order {active['order_id']} status -> cancelled")
            plc_service.clear_active_batch(plc_id)

        elif cmd == BatchControlCommand.RESET:
            reset_tags = {
                BATCH_STATUS_TAG: 0,
                BATCH_ID_TAG: "",  # Clear batch ID from PLC
                RECIPE_ID_TAG: "",  # Clear recipe ID from PLC
                CMD_RESET_TAG: True,
            }
            logger.info(f"[BATCH-CONTROL] Writing reset tags: BatchStatus=0, BatchID='', RecipeID=''")
            await client.write_tags(reset_tags)
            await asyncio.sleep(0.2)
            await client.write_tags({CMD_RESET_TAG: False})
            logger.info("[BATCH-CONTROL] Reset pulse cleared, BatchStatus=0, BatchID cleared")

            # Clear active batch
            plc_service.clear_active_batch(plc_id)

        # Log event
        duration_ms = int((time.perf_counter() - t0) * 1000)
        await log_process_event(
            event_type=f"BATCH_{cmd.name}",
            plc_id=plc_id,
            recipe_id=recipe_id,
            severity=1,
            message=f"Batch command {cmd.value} executed. {previous_status.name} -> {new_status.name} ({duration_ms}ms)"
        )

        logger.info(
            f"[BATCH-CONTROL] SUCCESS: {plc_id} {previous_status.name} -> {new_status.name} "
            f"in {duration_ms}ms"
        )
        return {
            "plc_id": plc_id,
            "command": command,
            "previous_status": previous_status.value,
            "current_status": new_status.value,
            "status_name": new_status.name,
            "success": True,
            "message": f"Command '{command}' executed. Status changed from {previous_status.name} to {new_status.name}.",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except Exception as e:
        duration_ms = int((time.perf_counter() - t0) * 1000)
        logger.error(
            f"[BATCH-CONTROL] FAILED after {duration_ms}ms: {type(e).__name__}: {e}",
            exc_info=True
        )
        return {
            "plc_id": plc_id,
            "command": command,
            "previous_status": previous_status.value if 'previous_status' in dir() else 0,
            "current_status": previous_status.value if 'previous_status' in dir() else 0,
            "status_name": previous_status.name if 'previous_status' in dir() else "UNKNOWN",
            "success": False,
            "message": f"Failed to execute {command}: {str(e)}",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    finally:
        logger.debug(f"[BATCH-CONTROL] Disconnecting from {plc_id}...")
        await client.disconnect()
        logger.info(f"[BATCH-CONTROL] Disconnected from {plc_id}")
