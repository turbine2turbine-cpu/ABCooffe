"""OPC UA client for Rockwell PLC (via Kepware/FactoryTalk)."""
import logging
import asyncio
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass

try:
    from asyncua import Client, Node, ua
    from asyncua.common.subscription import DataChangeNotif
    OPCUA_AVAILABLE = True
except ImportError:
    OPCUA_AVAILABLE = False

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class OpcuaTagResult:
    tag_name: str
    value: Any
    status: str
    error: Optional[str] = None
    source_timestamp: Optional[Any] = None


class OpcuaClient:
    """Async OPC UA client wrapper."""

    def __init__(self, endpoint: str, username: Optional[str] = None, password: Optional[str] = None):
        if not OPCUA_AVAILABLE:
            raise ImportError("opcua-asyncio not installed. Run: pip install opcua-asyncio")

        self.endpoint = endpoint
        self.username = username
        self.password = password
        self._client: Optional[Client] = None
        self._connected = False
        self._subscription = None
        self._tag_cache: Dict[str, Any] = {}

    async def connect(self) -> bool:
        """Connect to OPC UA server."""
        try:
            self._client = Client(url=self.endpoint)
            if self.username and self.password:
                self._client.set_user(self.username)
                self._client.set_password(self.password)

            await self._client.connect()
            self._connected = True
            logger.info(f"Connected to OPC UA server: {self.endpoint}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to OPC UA {self.endpoint}: {e}")
            self._connected = False
            return False

    async def disconnect(self):
        """Disconnect from OPC UA server."""
        if self._client:
            try:
                if self._subscription:
                    await self._subscription.delete()
                await self._client.disconnect()
            except Exception as e:
                logger.warning(f"Error disconnecting OPC UA: {e}")
            finally:
                self._connected = False
                self._client = None

    async def read_tag(self, node_id: str) -> OpcuaTagResult:
        """Read single node."""
        if not self._client or not self._connected:
            return OpcuaTagResult(node_id, None, "Error", "Not connected")

        try:
            node = self._client.get_node(node_id)
            value = await node.read_value()
            return OpcuaTagResult(node_id, value, "Success")
        except Exception as e:
            logger.error(f"Error reading OPC UA node {node_id}: {e}")
            return OpcuaTagResult(node_id, None, "Error", str(e))

    async def read_tags(self, node_ids: List[str]) -> List[OpcuaTagResult]:
        """Read multiple nodes."""
        results = []
        for node_id in node_ids:
            result = await self.read_tag(node_id)
            results.append(result)
        return results

    async def write_tag(self, node_id: str, value: Union[int, float, bool, str]) -> OpcuaTagResult:
        """Write single node."""
        if not self._client or not self._connected:
            return OpcuaTagResult(node_id, None, "Error", "Not connected")

        try:
            node = self._client.get_node(node_id)
            # Get data type and cast appropriately
            data_value = ua.DataValue(ua.Variant(value))
            await node.write_value(data_value)
            return OpcuaTagResult(node_id, value, "Success")
        except Exception as e:
            logger.error(f"Error writing OPC UA node {node_id}: {e}")
            return OpcuaTagResult(node_id, None, "Error", str(e))

    async def write_tags(self, tags: Dict[str, Union[int, float, bool, str]]) -> List[OpcuaTagResult]:
        """Write multiple nodes."""
        results = []
        for node_id, value in tags.items():
            result = await self.write_tag(node_id, value)
            results.append(result)
        return results

    async def browse_tags(self, base_node_id: str = "i=85") -> List[Dict[str, str]]:
        """Browse available tags/nodes."""
        if not self._client:
            return []

        try:
            node = self._client.get_node(base_node_id)
            children = await node.get_children()
            tags = []
            for child in children:
                try:
                    browse_name = await child.read_browse_name()
                    node_id = child.nodeid.to_string()
                    tags.append({"name": browse_name.Name, "node_id": node_id})
                except:
                    continue
            return tags
        except Exception as e:
            logger.error(f"Error browsing OPC UA nodes: {e}")
            return []

    async def subscribe_to_tags(self, node_ids: List[str], callback):
        """Subscribe to data changes."""
        if not self._client:
            return False

        try:
            handler = SubHandler(callback)
            self._subscription = await self._client.create_subscription(500, handler)
            nodes = [self._client.get_node(nid) for nid in node_ids]
            await self._subscription.subscribe_data_change(nodes)
            return True
        except Exception as e:
            logger.error(f"Error subscribing to OPC UA tags: {e}")
            return False


class SubHandler:
    """OPC UA subscription handler."""

    def __init__(self, callback):
        self.callback = callback

    async def datachange_notification(self, node: Node, val, data: DataChangeNotif):
        """Called when tag value changes."""
        node_id = node.nodeid.to_string()
        await self.callback(node_id, val, data)

    async def event_notification(self, event):
        pass

    async def status_change_notification(self, status):
        pass


# ─── OPC UA Client Registry ───

_opcua_clients: Dict[str, OpcuaClient] = {}


def get_opcua_client(
    plc_id: str, 
    endpoint: str, 
    username: Optional[str] = None, 
    password: Optional[str] = None
) -> OpcuaClient:
    """Get or create OPC UA client."""
    if plc_id not in _opcua_clients:
        _opcua_clients[plc_id] = OpcuaClient(endpoint, username, password)
    return _opcua_clients[plc_id]


async def disconnect_all_opcua():
    """Disconnect all OPC UA clients."""
    for plc_id, client in _opcua_clients.items():
        try:
            await client.disconnect()
            logger.info(f"Disconnected OPC UA {plc_id}")
        except Exception as e:
            logger.error(f"Error disconnecting OPC UA {plc_id}: {e}")
    _opcua_clients.clear()
