"""Rockwell PLC client using PyLogix (EtherNet/IP CIP)."""
import logging
import asyncio
import time
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass, asdict
from pylogix import PLC as PylogixPLC
from pylogix.eip import Response

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class PlcTagResult:
    tag_name: str
    value: Any
    status: str  # 'Success', 'Error'
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tag_name": self.tag_name,
            "value": self.value,
            "status": self.status,
            "error": self.error,
        }


class PyLogixClient:
    """Thread-safe wrapper for PyLogix PLC communication.

    PyLogix is synchronous, so we run it in asyncio thread pool.
    All operations are logged at DEBUG level for detailed tracing.
    """

    def __init__(self, host: str, slot: int = 0, timeout: int = 5):
        self.host = host
        self.slot = slot
        self.timeout = timeout
        self._plc: Optional[PylogixPLC] = None
        self._connected = False
        self._session_id = f"{host}:{slot}"
        logger.info(f"[PLC|{self._session_id}] Client created (timeout={timeout}s)")

    def connect(self) -> bool:
        """Connect to PLC and verify by reading device properties."""
        logger.info(f"[PLC|{self._session_id}] >>> CONNECT: host={self.host}, slot={self.slot}")
        try:
            self._plc = PylogixPLC()
            self._plc.IPAddress = self.host
            self._plc.ProcessorSlot = self.slot
            self._plc.Timeout = self.timeout * 1000  # ms

            # Verify connection by attempting to read device properties
            props = self._plc.GetDeviceProperties()
            if hasattr(props, 'Status') and props.Status == "Success":
                self._connected = True
                logger.info(f"[PLC|{self._session_id}] <<< CONNECT: SUCCESS (timeout={self.timeout}s)")
                return True
            elif hasattr(props, 'Status'):
                logger.error(f"[PLC|{self._session_id}] <<< CONNECT: FAILED - PLC returned status='{props.Status}'")
                self._connected = False
                return False
            else:
                # Fallback: try reading a known system tag
                test_resp = self._plc.Read("@cpu")
                if hasattr(test_resp, 'Status') and test_resp.Status == "Success":
                    self._connected = True
                    logger.info(f"[PLC|{self._session_id}] <<< CONNECT: SUCCESS (via tag read)")
                    return True
                logger.error(f"[PLC|{self._session_id}] <<< CONNECT: FAILED - No valid response from PLC")
                self._connected = False
                return False
        except Exception as e:
            logger.error(f"[PLC|{self._session_id}] <<< CONNECT: FAILED - {type(e).__name__}: {e}")
            self._connected = False
            return False

    def disconnect(self):
        """Disconnect from PLC."""
        logger.info(f"[PLC|{self._session_id}] >>> DISCONNECT")
        if self._plc:
            try:
                self._plc.Close()
                logger.info(f"[PLC|{self._session_id}] <<< DISCONNECT: SUCCESS")
            except Exception as e:
                logger.warning(f"[PLC|{self._session_id}] <<< DISCONNECT: WARNING - {e}")
            finally:
                self._connected = False
                self._plc = None
        else:
            logger.debug(f"[PLC|{self._session_id}] <<< DISCONNECT: No active connection")

    def is_connected(self) -> bool:
        """Check connection status by reading device properties."""
        if not self._plc or not self._connected:
            return False
        try:
            props = self._plc.GetDeviceProperties()
            if hasattr(props, 'Status') and props.Status == "Success":
                return True
            # Fallback: try a quick tag read
            test = self._plc.Read("@cpu")
            if hasattr(test, 'Status') and test.Status == "Success":
                return True
            self._connected = False
            return False
        except Exception as e:
            logger.warning(f"[PLC|{self._session_id}] is_connected() check failed: {e}")
            self._connected = False
            return False

    def read_tag(self, tag_name: str) -> PlcTagResult:
        """Read single tag from PLC."""
        logger.debug(f"[PLC|{self._session_id}] >>> READ_TAG: '{tag_name}'")
        if not self._plc:
            logger.error(f"[PLC|{self._session_id}] <<< READ_TAG '{tag_name}': FAILED - Not connected")
            return PlcTagResult(tag_name, None, "Error", "Not connected")

        try:
            t0 = time.perf_counter()
            response: Response = self._plc.Read(tag_name)
            elapsed_ms = (time.perf_counter() - t0) * 1000

            if response.Status == "Success":
                logger.debug(
                    f"[PLC|{self._session_id}] <<< READ_TAG '{tag_name}': SUCCESS "
                    f"value={response.Value!r} ({elapsed_ms:.1f}ms)"
                )
                return PlcTagResult(tag_name, response.Value, "Success")
            else:
                logger.warning(
                    f"[PLC|{self._session_id}] <<< READ_TAG '{tag_name}': ERROR "
                    f"status='{response.Status}' ({elapsed_ms:.1f}ms)"
                )
                return PlcTagResult(tag_name, None, "Error", response.Status)
        except Exception as e:
            logger.error(f"[PLC|{self._session_id}] <<< READ_TAG '{tag_name}': EXCEPTION - {type(e).__name__}: {e}")
            return PlcTagResult(tag_name, None, "Error", str(e))

    def read_tags(self, tag_names: List[str]) -> List[PlcTagResult]:
        """Read multiple tags efficiently."""
        logger.info(f"[PLC|{self._session_id}] >>> READ_TAGS: count={len(tag_names)} tags={tag_names}")
        if not self._plc:
            logger.error(f"[PLC|{self._session_id}] <<< READ_TAGS: FAILED - Not connected")
            return [PlcTagResult(t, None, "Error", "Not connected") for t in tag_names]

        try:
            t0 = time.perf_counter()
            responses = self._plc.Read(tag_names)
            elapsed_ms = (time.perf_counter() - t0) * 1000

            results = []
            success_count = 0
            error_count = 0
            for resp in responses:
                if resp.Status == "Success":
                    results.append(PlcTagResult(resp.TagName, resp.Value, "Success"))
                    success_count += 1
                else:
                    results.append(PlcTagResult(resp.TagName, None, "Error", resp.Status))
                    error_count += 1

            logger.info(
                f"[PLC|{self._session_id}] <<< READ_TAGS: "
                f"success={success_count}, error={error_count}, "
                f"total_time={elapsed_ms:.1f}ms"
            )
            # Log each failed tag at warning level
            for r in results:
                if r.status != "Success":
                    logger.warning(f"[PLC|{self._session_id}]   - FAILED: '{r.tag_name}' -> {r.error}")
            return results
        except Exception as e:
            logger.error(f"[PLC|{self._session_id}] <<< READ_TAGS: EXCEPTION - {type(e).__name__}: {e}")
            return [PlcTagResult(t, None, "Error", str(e)) for t in tag_names]

    def write_tag(self, tag_name: str, value: Union[int, float, bool, str]) -> PlcTagResult:
        """Write single tag to PLC."""
        logger.debug(f"[PLC|{self._session_id}] >>> WRITE_TAG: '{tag_name}' = {value!r} (type={type(value).__name__})")
        if not self._plc:
            logger.error(f"[PLC|{self._session_id}] <<< WRITE_TAG '{tag_name}': FAILED - Not connected")
            return PlcTagResult(tag_name, None, "Error", "Not connected")

        try:
            t0 = time.perf_counter()
            response = self._plc.Write(tag_name, value)
            elapsed_ms = (time.perf_counter() - t0) * 1000

            if response.Status == "Success":
                logger.info(
                    f"[PLC|{self._session_id}] <<< WRITE_TAG '{tag_name}': SUCCESS "
                    f"wrote={value!r} ({elapsed_ms:.1f}ms)"
                )
                return PlcTagResult(tag_name, value, "Success")
            else:
                logger.warning(
                    f"[PLC|{self._session_id}] <<< WRITE_TAG '{tag_name}': ERROR "
                    f"status='{response.Status}' ({elapsed_ms:.1f}ms)"
                )
                return PlcTagResult(tag_name, None, "Error", response.Status)
        except Exception as e:
            logger.error(f"[PLC|{self._session_id}] <<< WRITE_TAG '{tag_name}': EXCEPTION - {type(e).__name__}: {e}")
            return PlcTagResult(tag_name, None, "Error", str(e))

    def write_tags(self, tags: Dict[str, Union[int, float, bool, str]]) -> List[PlcTagResult]:
        """Write multiple tags sequentially with per-tag error handling."""
        logger.info(f"[PLC|{self._session_id}] >>> WRITE_TAGS: count={len(tags)}")
        logger.debug(f"[PLC|{self._session_id}]   tags_to_write={tags}")

        results = []
        success_count = 0
        failed_count = 0
        t0 = time.perf_counter()

        for tag_name, value in tags.items():
            result = self.write_tag(tag_name, value)
            results.append(result)
            if result.status == "Success":
                success_count += 1
            else:
                failed_count += 1
                logger.warning(f"[PLC|{self._session_id}]   - FAILED: '{tag_name}' -> {result.error}")

        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.info(
            f"[PLC|{self._session_id}] <<< WRITE_TAGS: "
            f"success={success_count}, failed={failed_count}, "
            f"total_time={elapsed_ms:.1f}ms"
        )
        return results

    def get_plc_info(self) -> Dict[str, Any]:
        """Get PLC information."""
        logger.info(f"[PLC|{self._session_id}] >>> GET_PLC_INFO")
        if not self._plc:
            logger.error(f"[PLC|{self._session_id}] <<< GET_PLC_INFO: FAILED - Not connected")
            return {"error": "Not connected"}
        try:
            props = self._plc.GetDeviceProperties()
            if hasattr(props, 'Status') and props.Status != "Success":
                return {"error": f"PLC returned status: {props.Status}"}

            val = getattr(props, 'Value', None)
            if val is None:
                return {"status": "connected", "info": "No properties available"}

            # Handle different response formats from pylogix
            # Case 1: Value is a list of objects
            if isinstance(val, list) and len(val) > 0:
                p = val[0]
            # Case 2: Value is a single object (not subscriptable)
            else:
                p = val

            # Extract properties safely using getattr
            info = {"status": "connected"}

            if hasattr(p, 'ProductName'):
                info["product_name"] = p.ProductName
            elif isinstance(p, dict) and "ProductName" in p:
                info["product_name"] = p["ProductName"]

            if hasattr(p, 'ProductCode'):
                info["product_code"] = p.ProductCode
            elif isinstance(p, dict) and "ProductCode" in p:
                info["product_code"] = p["ProductCode"]

            if hasattr(p, 'Revision'):
                rev = p.Revision
                if hasattr(rev, 'Major') and hasattr(rev, 'Minor'):
                    info["revision"] = f"{rev.Major}.{rev.Minor}"
                else:
                    info["revision"] = str(rev)
            elif isinstance(p, dict) and "Revision" in p:
                info["revision"] = str(p["Revision"])

            if hasattr(p, 'SerialNumber'):
                info["serial_number"] = p.SerialNumber
            elif isinstance(p, dict) and "SerialNumber" in p:
                info["serial_number"] = p["SerialNumber"]

            if hasattr(p, 'Vendor'):
                info["vendor"] = p.Vendor
            elif isinstance(p, dict) and "Vendor" in p:
                info["vendor"] = p["Vendor"]

            logger.info(f"[PLC|{self._session_id}] <<< GET_PLC_INFO: SUCCESS {info}")
            return info

        except Exception as e:
            logger.error(f"[PLC|{self._session_id}] <<< GET_PLC_INFO: EXCEPTION - {e}")
            return {"error": str(e)}


class AsyncPyLogixClient:
    """Async wrapper that runs PyLogix in thread pool with detailed logging."""

    def __init__(self, host: str, slot: int = 0, timeout: int = 5):
        self._client = PyLogixClient(host, slot, timeout)
        self._lock = asyncio.Lock()
        self._session_id = f"{host}:{slot}"

    async def connect(self) -> bool:
        logger.info(f"[ASYNC|{self._session_id}] >>> connect()")
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, self._client.connect)
        logger.info(f"[ASYNC|{self._session_id}] <<< connect() -> {result}")
        return result

    async def disconnect(self):
        logger.info(f"[ASYNC|{self._session_id}] >>> disconnect()")
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._client.disconnect)
        logger.info(f"[ASYNC|{self._session_id}] <<< disconnect() done")

    async def read_tag(self, tag_name: str) -> PlcTagResult:
        async with self._lock:
            logger.debug(f"[ASYNC|{self._session_id}] >>> read_tag('{tag_name}')")
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, self._client.read_tag, tag_name)
            logger.debug(f"[ASYNC|{self._session_id}] <<< read_tag('{tag_name}') -> status={result.status}")
            return result

    async def read_tags(self, tag_names: List[str]) -> List[PlcTagResult]:
        async with self._lock:
            logger.info(f"[ASYNC|{self._session_id}] >>> read_tags({tag_names})")
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, self._client.read_tags, tag_names)
            logger.info(f"[ASYNC|{self._session_id}] <<< read_tags() -> {len(result)} results")
            return result

    async def write_tag(self, tag_name: str, value: Any) -> PlcTagResult:
        async with self._lock:
            logger.debug(f"[ASYNC|{self._session_id}] >>> write_tag('{tag_name}', {value!r})")
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, self._client.write_tag, tag_name, value)
            logger.debug(f"[ASYNC|{self._session_id}] <<< write_tag('{tag_name}') -> status={result.status}")
            return result

    async def write_tags(self, tags: Dict[str, Any]) -> List[PlcTagResult]:
        async with self._lock:
            logger.info(f"[ASYNC|{self._session_id}] >>> write_tags({list(tags.keys())})")
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, self._client.write_tags, tags)
            logger.info(f"[ASYNC|{self._session_id}] <<< write_tags() -> {len(result)} results")
            return result

    async def get_plc_info(self) -> Dict[str, Any]:
        async with self._lock:
            logger.info(f"[ASYNC|{self._session_id}] >>> get_plc_info()")
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, self._client.get_plc_info)
            logger.info(f"[ASYNC|{self._session_id}] <<< get_plc_info() -> {result}")
            return result


# ─── PLC Client Registry ───

_plc_clients: Dict[str, AsyncPyLogixClient] = {}


def get_plc_client(plc_id: str, host: str, slot: int = 0, timeout: int = 5) -> AsyncPyLogixClient:
    """Get or create PLC client."""
    if plc_id not in _plc_clients:
        logger.info(f"[REGISTRY] Creating new PLC client: plc_id={plc_id}, host={host}, slot={slot}")
        _plc_clients[plc_id] = AsyncPyLogixClient(host, slot, timeout)
    else:
        logger.debug(f"[REGISTRY] Reusing existing PLC client: plc_id={plc_id}")
    return _plc_clients[plc_id]


async def disconnect_all_plcs():
    """Disconnect all PLC clients."""
    logger.info(f"[REGISTRY] Disconnecting all PLCs ({len(_plc_clients)} clients)")
    for plc_id, client in _plc_clients.items():
        try:
            await client.disconnect()
            logger.info(f"[REGISTRY] Disconnected PLC {plc_id}")
        except Exception as e:
            logger.error(f"[REGISTRY] Error disconnecting PLC {plc_id}: {e}")
    _plc_clients.clear()
    logger.info("[REGISTRY] All PLC clients cleared")
