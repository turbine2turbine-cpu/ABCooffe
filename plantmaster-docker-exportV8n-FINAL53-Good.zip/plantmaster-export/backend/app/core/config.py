"""Application configuration using Pydantic Settings."""
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Application
    APP_NAME: str = "Recipe PLC Manager"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    LOG_LEVEL: str = "INFO"

    # Database (TimescaleDB) - default host is 'timescaledb' for Docker networking
    DATABASE_URL: str = "postgresql://recipe_admin:recipe_secret_2024@timescaledb:5432/recipe_manager"
    DB_POOL_MIN_SIZE: int = 5
    DB_POOL_MAX_SIZE: int = 20
    DB_COMMAND_TIMEOUT: int = 60

    # PLC Rockwell (PyLogix - EtherNet/IP)
    PLC_HOST: str = "192.168.20.10"
    PLC_SLOT: int = 0
    PLC_TIMEOUT: int = 5
    PLC_RETRY_ATTEMPTS: int = 3
    PLC_RETRY_DELAY: float = 1.0

    # OPC UA (Alternative/Primary)
    OPC_UA_ENDPOINT: Optional[str] = None  # e.g., "opc.tcp://192.168.20.10:4840"
    OPC_UA_USERNAME: Optional[str] = None
    OPC_UA_PASSWORD: Optional[str] = None

    # Recipe Download Settings
    DOWNLOAD_QUEUE_MAX_SIZE: int = 100
    DOWNLOAD_TIMEOUT_SECONDS: int = 30
    DOWNLOAD_VALIDATE_BEFORE_SEND: bool = True
    DOWNLOAD_BACKUP_CURRENT: bool = True

    # Time-series Settings
    TAG_SAMPLING_INTERVAL_MS: int = 1000  # 1 second default
    TAG_BATCH_INSERT_SIZE: int = 1000
    TAG_BUFFER_FLUSH_INTERVAL_S: int = 5

    # Security
    API_KEY_HEADER: str = "X-API-Key"
    API_KEY: Optional[str] = None  # Set in production

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
