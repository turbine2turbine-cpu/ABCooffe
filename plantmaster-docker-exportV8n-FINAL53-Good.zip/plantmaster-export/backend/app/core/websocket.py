"""WebSocket connection manager for real-time monitoring."""
import logging
import asyncio
import json
from typing import Dict, List, Set, Any
from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger(__name__)


class ConnectionManager:
    """Manages WebSocket connections with room-based subscriptions."""

    def __init__(self):
        # plc_id -> set of websockets
        self._rooms: Dict[str, Set[WebSocket]] = {}
        # websocket -> set of subscribed plc_ids
        self._subscriptions: Dict[WebSocket, Set[str]] = {}
        self._lock = asyncio.Lock()

    async def connect(self, websocket: WebSocket):
        """Accept new WebSocket connection."""
        await websocket.accept()
        async with self._lock:
            self._subscriptions[websocket] = set()
        logger.info(f"WebSocket connected: {websocket.client}")

    async def disconnect(self, websocket: WebSocket):
        """Clean up disconnected WebSocket."""
        async with self._lock:
            subscribed_plcs = self._subscriptions.pop(websocket, set())
            for plc_id in subscribed_plcs:
                if plc_id in self._rooms:
                    self._rooms[plc_id].discard(websocket)
                    if not self._rooms[plc_id]:
                        del self._rooms[plc_id]
        logger.info(f"WebSocket disconnected: {websocket.client}")

    async def subscribe(self, websocket: WebSocket, plc_id: str):
        """Subscribe websocket to a PLC room."""
        async with self._lock:
            if plc_id not in self._rooms:
                self._rooms[plc_id] = set()
            self._rooms[plc_id].add(websocket)
            self._subscriptions[websocket].add(plc_id)
        logger.debug(f"WebSocket subscribed to {plc_id}")
        await websocket.send_json({
            "type": "subscribed",
            "plc_id": plc_id,
            "message": f"Subscribed to {plc_id}"
        })

    async def unsubscribe(self, websocket: WebSocket, plc_id: str):
        """Unsubscribe websocket from a PLC room."""
        async with self._lock:
            if plc_id in self._rooms:
                self._rooms[plc_id].discard(websocket)
                if not self._rooms[plc_id]:
                    del self._rooms[plc_id]
            self._subscriptions[websocket].discard(plc_id)
        logger.debug(f"WebSocket unsubscribed from {plc_id}")
        await websocket.send_json({
            "type": "unsubscribed",
            "plc_id": plc_id
        })

    async def broadcast_to_plc(self, plc_id: str, message: Dict[str, Any]):
        """Broadcast message to all websockets subscribed to a PLC."""
        if plc_id not in self._rooms:
            return

        disconnected = []
        for ws in list(self._rooms[plc_id]):
            try:
                await ws.send_json(message)
            except Exception as e:
                logger.warning(f"Failed to send to websocket: {e}")
                disconnected.append(ws)

        # Clean up dead connections
        for ws in disconnected:
            await self.disconnect(ws)

    async def broadcast(self, message: Dict[str, Any]):
        """Broadcast message to all connected websockets."""
        all_ws = set()
        async with self._lock:
            for ws_set in self._rooms.values():
                all_ws.update(ws_set)

        disconnected = []
        for ws in all_ws:
            try:
                await ws.send_json(message)
            except Exception as e:
                logger.warning(f"Failed to broadcast: {e}")
                disconnected.append(ws)

        for ws in disconnected:
            await self.disconnect(ws)

    def get_stats(self) -> Dict[str, Any]:
        """Get connection statistics."""
        return {
            "total_connections": len(self._subscriptions),
            "active_rooms": {
                plc_id: len(ws_set)
                for plc_id, ws_set in self._rooms.items()
            }
        }


# Global manager instance
ws_manager = ConnectionManager()
