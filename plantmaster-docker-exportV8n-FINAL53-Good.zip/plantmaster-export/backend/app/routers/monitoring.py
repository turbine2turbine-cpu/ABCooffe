"""Monitoring and time-series query endpoints."""
import logging
import asyncio
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

from app.services.timeseries_service import timeseries_service
from app.core.database import get_tag_history, get_download_history, get_unacknowledged_alarms
from app.core.websocket import ws_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/monitoring", tags=["Monitoring"])


@router.get("/tags/{plc_id}/trend")
async def get_tag_trend(
    plc_id: str,
    tag_name: str = Query(...),
    hours: int = Query(24, ge=1, le=720),
    bucket: str = Query("1 minute", regex="^(1 minute|5 minutes|1 hour)$")
):
    """Get tag trend with time-bucket aggregation."""
    return await timeseries_service.get_tag_trend(plc_id, tag_name, hours, bucket)


@router.get("/tags/{plc_id}/current")
async def get_current_tags(plc_id: str):
    """Get current snapshot of all PLC tags."""
    return await timeseries_service.get_plc_snapshot(plc_id)


@router.get("/downloads")
async def get_downloads(
    recipe_id: str = Query(None),
    plc_id: str = Query(None),
    hours: int = Query(24, ge=1, le=720)
):
    """Get recipe download history."""
    return await get_download_history(recipe_id, plc_id, hours)


@router.get("/alarms")
async def get_alarms(
    plc_id: str = Query(None),
    unacknowledged_only: bool = Query(True)
):
    """Get process events/alarms."""
    if unacknowledged_only:
        return await get_unacknowledged_alarms(plc_id)
    return []


@router.get("/recipe/{recipe_id}/execution")
async def get_recipe_execution(recipe_id: str, hours: int = Query(168)):
    """Get recipe execution history with success rate."""
    return await timeseries_service.get_recipe_execution_history(recipe_id, hours)


# ─── WebSocket Real-time Monitoring ───

@router.websocket("/ws")
async def monitoring_websocket(websocket: WebSocket):
    """
    WebSocket endpoint for real-time monitoring.
    
    Protocol:
    - Client sends: {"action": "subscribe", "plc_id": "LINE_A_PLC"}
    - Client sends: {"action": "unsubscribe", "plc_id": "LINE_A_PLC"}
    - Server pushes: {"type": "tag_values", "plc_id": "...", "data": [...]}
    - Server pushes: {"type": "alarm", "plc_id": "...", "data": {...}}
    - Server pushes: {"type": "batch_status", "plc_id": "...", "data": {...}}
    - Server pushes: {"type": "heartbeat"} every 30s
    """
    await ws_manager.connect(websocket)
    try:
        # Send welcome message
        await websocket.send_json({
            "type": "connected",
            "message": "WebSocket connected. Send {'action': 'subscribe', 'plc_id': '...'} to start receiving data."
        })

        while True:
            try:
                # Wait for client messages with timeout to allow heartbeat checks
                data = await asyncio.wait_for(
                    websocket.receive_json(),
                    timeout=30.0
                )

                action = data.get("action")
                plc_id = data.get("plc_id")

                if action == "subscribe" and plc_id:
                    await ws_manager.subscribe(websocket, plc_id)
                    # Send initial snapshot
                    snapshot = await timeseries_service.get_plc_snapshot(plc_id)
                    await websocket.send_json({
                        "type": "snapshot",
                        "plc_id": plc_id,
                        "data": snapshot
                    })

                elif action == "unsubscribe" and plc_id:
                    await ws_manager.unsubscribe(websocket, plc_id)

                elif action == "ping":
                    await websocket.send_json({"type": "pong", "timestamp": datetime.now(timezone.utc).isoformat()})

                else:
                    await websocket.send_json({
                        "type": "error",
                        "message": "Unknown action. Use: subscribe, unsubscribe, ping"
                    })

            except asyncio.TimeoutError:
                # Send heartbeat
                await websocket.send_json({
                    "type": "heartbeat",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })

    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected: {websocket.client}")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        await ws_manager.disconnect(websocket)
