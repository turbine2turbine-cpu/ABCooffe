from fastapi import APIRouter
from typing import Optional
from datetime import datetime
from app.services.simulator_service import simulator
from app.services.plc_service import plc_service, get_batch_status
from app.core.config import settings

router = APIRouter(prefix="/simulator", tags=["simulator"])

@router.get("/status")
async def get_simulator_status():
    return simulator.status

@router.post("/enable")
async def enable_simulator(plc_id: Optional[str] = "LINE_A_PLC", interval: float = 1.0):
    result = simulator.enable(plc_id=plc_id, interval=interval)
    return {"success": result, "status": simulator.status}

@router.post("/disable")
async def disable_simulator():
    result = simulator.disable()
    return {"success": result, "status": simulator.status}

@router.get("/values")
async def get_simulator_values():
    return {
        "values": simulator.current_values,
        "last_update": simulator.status.get("last_update"),
    }

@router.get("/plc-values")
async def get_plc_production_values(plc_id: Optional[str] = "LINE_A_PLC"):
    """Read actual production data values from PLC tags."""
    try:
        from app.services.plc_service import plc_service
        metrics = await plc_service._read_production_metrics(plc_id)
        return {
            "plc_id": plc_id,
            "values": metrics,
            "timestamp": datetime.now().isoformat(),
        }
    except Exception as e:
        return {"plc_id": plc_id, "values": {}, "error": str(e)}

@router.get("/plc-state")
async def get_plc_state(plc_id: Optional[str] = "LINE_A_PLC"):
    """Get current batch state from PLC (state machine status)."""
    try:
        state = await get_batch_status(plc_id)
        return state
    except Exception as e:
        return {
            "plc_id": plc_id,
            "error": str(e),
            "batch_status": 0,
            "status_name": "ERROR",
            "is_online": False,
            "timestamp": datetime.now().isoformat(),
        }

@router.get("/plc-connection")
async def get_plc_connection_info():
    """Get PLC connection configuration (IP, slot, etc.)."""
    return {
        "plc_host": settings.PLC_HOST,
        "plc_slot": settings.PLC_SLOT,
        "plc_timeout": settings.PLC_TIMEOUT,
        "opc_ua_endpoint": settings.OPC_UA_ENDPOINT,
        "timestamp": datetime.now().isoformat(),
    }

@router.get("/plc-tags")
async def read_plc_tags_direct(plc_id: Optional[str] = "LINE_A_PLC"):
    """Read raw PLC tags (RoasterA.*) for monitoring."""
    try:
        tags = [
            "RoasterA.DrumTemp", "RoasterA.BeanTemp", "RoasterA.InletTemp",
            "RoasterA.ExhaustTemp", "RoasterA.BatchStatus", "RoasterA.AirFlow",
            "RoasterA.BatchSize", "RoasterA.BeanTempEnd", "RoasterA.BeanTempStart",
            "RoasterA.BurnerPower", "RoasterA.ChargeTemp", "RoasterA.CoolTime",
            "RoasterA.CoolingTime", "RoasterA.DevTime", "RoasterA.DevelopmentRatio",
            "RoasterA.DevelopmentTime", "RoasterA.DropTemp", "RoasterA.DrumSpeed",
            "RoasterA.DryingPhase", "RoasterA.FC_Temp", "RoasterA.FC_Time",
            "RoasterA.FanSpeed", "RoasterA.FirstCrackTemp", "RoasterA.GasPressure",
            "RoasterA.Humidity", "RoasterA.MaillardPhase", "RoasterA.MoistureLoss",
            "RoasterA.RateOfRise", "RoasterA.RoR", "RoasterA.RoastTime",
            "RoasterA.SC_Time", "RoasterA.TATemp", "RoasterA.TurnaroundTemp",
            "RoasterA.WeightLoss"
        ]
        result = await plc_service.read_plc_tags(plc_id, tags)
        return {
            "plc_id": plc_id,
            "tags": result.get("results", []),
            "timestamp": datetime.now().isoformat(),
        }
    except Exception as e:
        return {"plc_id": plc_id, "tags": [], "error": str(e)}
