"""PLC operations API endpoints."""
import logging
from datetime import datetime, timezone
from typing import List, Dict, Any
from fastapi import APIRouter, HTTPException, BackgroundTasks

from app.models import DownloadRequest, TagReadRequest, TagWriteRequest
from app.services.plc_service import plc_service, get_batch_status, control_batch
from app.services.timeseries_service import timeseries_service
from app.core.database import get_current_tag_values, get_unacknowledged_alarms, db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/plc", tags=["PLC"])


@router.post("/download")
async def download_recipe(request: DownloadRequest, background_tasks: BackgroundTasks):
    """Queue recipe download to PLC."""
    tx_id = await plc_service.queue_download(
        recipe_id=request.recipe_id,
        plc_id=request.plc_id,
        user=request.user,
        validate=request.validate,
        backup_current=request.backup_current
    )
    return {
        "transaction_id": tx_id,
        "status": "PENDING",
        "message": "Download queued for processing"
    }


@router.get("/download/{transaction_id}")
async def get_download_status(transaction_id: str):
    """Get download job status."""
    status = await plc_service.get_download_status(transaction_id)
    if status.get("status") == "NOT_FOUND":
        raise HTTPException(status_code=404, detail="Transaction not found")
    return status


@router.post("/read-tags")
async def read_tags(request: TagReadRequest):
    """Read tags from PLC and log to TimescaleDB."""
    try:
        return await plc_service.read_plc_tags(request.plc_id, request.tag_names)
    except Exception as e:
        logger.error(f"Error reading tags: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/write-tags")
async def write_tags(request: TagWriteRequest):
    """Write tags to PLC and log to TimescaleDB."""
    try:
        return await plc_service.write_plc_tags(
            request.plc_id, request.tags, user="api"
        )
    except Exception as e:
        logger.error(f"Error writing tags: {e}")
        raise HTTPException(status_code=500, detail=str(e))


async def _get_plc_client_from_config(plc_id: str):
    """Get PLC client using configuration from database."""
    from app.clients.plc_client import get_plc_client

    async with db.acquire() as conn:
        config = await conn.fetchrow(
            "SELECT host, slot, timeout FROM plc_configs WHERE plc_id = $1 AND is_active = true",
            plc_id
        )

    if not config:
        # Fallback to environment defaults for backward compatibility
        from app.core.config import settings
        return get_plc_client(plc_id, settings.PLC_HOST, settings.PLC_SLOT, settings.PLC_TIMEOUT)

    return get_plc_client(plc_id, config["host"], config["slot"], config["timeout"])


@router.get("/status/{plc_id}")
async def get_plc_status(plc_id: str):
    """Get PLC connection status and current tag values (live from PLC + DB fallback)."""
    client = await _get_plc_client_from_config(plc_id)

    try:
        connected = await client.connect()
        info = await client.get_plc_info() if connected else {"status": "offline"}
        await client.disconnect()

        # 1. Get tags from DB as baseline
        db_tags = await get_current_tag_values(plc_id)
        alarms = await get_unacknowledged_alarms(plc_id)

        # 2. Try to read live values from PLC for tags we know about
        live_tags = []
        if connected and db_tags:
            tag_names = [t["tag_name"] for t in db_tags]
            try:
                read_results = await client.read_tags(tag_names)
                live_tags = [
                    {
                        "tag_name": r.tag_name,
                        "tag_value": r.value,
                        "tag_quality": 192 if r.status == "Success" else 0,
                    }
                    for r in read_results if r.status == "Success"
                ]
                # Also log live readings to DB for history
                if live_tags:
                    from app.core.database import insert_tag_values_batch
                    await insert_tag_values_batch([
                        {
                            "time": datetime.now(timezone.utc),
                            "plc_id": plc_id,
                            "tag_name": t["tag_name"],
                            "tag_value": t["tag_value"],
                            "tag_quality": t["tag_quality"],
                        }
                        for t in live_tags
                    ])
            except Exception as e:
                logger.warning(f"[PLC-STATUS] Live read failed for {plc_id}: {e}")

        # 3. Merge: live tags take priority, fallback to DB tags
        live_tag_map = {t["tag_name"]: t for t in live_tags}
        merged_tags = []
        for db_tag in db_tags:
            tag_name = db_tag["tag_name"]
            if tag_name in live_tag_map:
                merged_tags.append(live_tag_map[tag_name])
            else:
                merged_tags.append(db_tag)
        # Add any live tags not in DB
        db_tag_names = {t["tag_name"] for t in db_tags}
        for live_tag in live_tags:
            if live_tag["tag_name"] not in db_tag_names:
                merged_tags.append(live_tag)

        # Fetch running batch and completed count for this roaster
        async with db.acquire() as conn:
            running = await conn.fetchrow(
                """SELECT po_number, recipe_code, quantity, status, started_at
                   FROM production_orders
                   WHERE plc_id = $1 AND status = 'running'
                   ORDER BY started_at DESC LIMIT 1""",
                plc_id
            )
            completed_count = await conn.fetchval(
                "SELECT COUNT(*) FROM production_orders WHERE plc_id = $1 AND status = 'completed'",
                plc_id
            )

        running_batch = None
        if running:
            running_batch = {
                "po_number": str(running["po_number"]),
                "recipe_code": str(running["recipe_code"]),
                "quantity": int(running["quantity"]) if running["quantity"] is not None else 0,
                "status": str(running["status"]),
                "started_at": str(running["started_at"]) if running["started_at"] else None,
            }

        # Map tag fields to match frontend PlcTagResult type
        mapped_tags = [
            {
                "tag": t["tag_name"],
                "value": t["tag_value"],
                "status": "Good" if t.get("tag_quality", 0) >= 192 else "Uncertain" if t.get("tag_quality", 0) >= 128 else "Bad",
            }
            for t in merged_tags[:50]  # increased limit from 10 to 50
        ]

        return {
            "plc_id": plc_id,
            "is_online": connected,
            "plc_info": info,
            "active_tags": len(merged_tags),
            "unack_alarms": len(alarms),
            "last_tags": mapped_tags,
            "running_batch": running_batch,
            "completed_batches": completed_count or 0
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/batch-status/{plc_id}")
async def batch_status(plc_id: str):
    """Get detailed batch status with allowed actions."""
    return await get_batch_status(plc_id)


@router.post("/batch-control/{plc_id}/{command}")
async def batch_control_endpoint(
    plc_id: str,
    command: str,
    recipe_id: str = None,
    po_number: str = None,
    order_id: str = None,
):
    """
    Control batch state machine.
    Commands: initialize, start, hold, abort
    - initialize: Copy recipe to PLC (blocked if RUNNING/HOLDING/HELD)
    - start: Start roasting
    - hold: Pause roasting
    - abort: Stop and reset batch
    """
    valid = ["initialize", "start", "hold", "abort", "reset"]
    if command not in valid:
        raise HTTPException(status_code=400, detail=f"Invalid command. Use: {valid}")

    result = await control_batch(
        plc_id=plc_id, command=command,
        recipe_id=recipe_id, po_number=po_number, order_id=order_id
    )
    if not result.get("success"):
        raise HTTPException(status_code=409, detail=result.get("message"))
    return result