"""PLC Configuration Management API endpoints."""
import logging
from typing import List, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.core.database import db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/plc-configs", tags=["PLC Configs"])


class PlcConfigCreate(BaseModel):
    plc_id: str = Field(..., min_length=1, max_length=50, description="Unique PLC identifier")
    host: str = Field(..., min_length=1, max_length=100, description="PLC IP address or hostname")
    slot: int = Field(default=0, ge=0, le=255, description="Processor slot number")
    timeout: int = Field(default=5, ge=1, le=60, description="Connection timeout in seconds")
    protocol: str = Field(default="pylogix", description="Protocol: pylogix or opcua")
    opcua_endpoint: Optional[str] = Field(default=None, description="OPC UA endpoint URL")
    description: Optional[str] = Field(default=None, description="Human-readable description")
    is_active: bool = Field(default=True)


class PlcConfigUpdate(BaseModel):
    host: Optional[str] = None
    slot: Optional[int] = None
    timeout: Optional[int] = None
    protocol: Optional[str] = None
    opcua_endpoint: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None


class PlcConfigResponse(BaseModel):
    id: str
    plc_id: str
    host: str
    slot: int
    timeout: int
    protocol: str
    opcua_endpoint: Optional[str]
    description: Optional[str]
    is_active: bool
    created_at: str


@router.get("")
async def list_plc_configs(active_only: bool = False):
    """List all PLC configurations."""
    async with db.acquire() as conn:
        query = """
            SELECT id, plc_id, host, slot, timeout, protocol, 
                   opcua_endpoint, description, is_active, created_at
            FROM plc_configs
            WHERE 1=1
        """
        params = []
        if active_only:
            query += " AND is_active = true"
        query += " ORDER BY plc_id"
        rows = await conn.fetch(query, *params)
        return [dict(r) for r in rows]


@router.get("/{plc_id}")
async def get_plc_config(plc_id: str):
    """Get PLC configuration by plc_id."""
    async with db.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT id, plc_id, host, slot, timeout, protocol,
                   opcua_endpoint, description, is_active, created_at
            FROM plc_configs WHERE plc_id = $1
            """,
            plc_id
        )
        if not row:
            raise HTTPException(status_code=404, detail=f"PLC config '{plc_id}' not found")
        return dict(row)


@router.post("", status_code=201)
async def create_plc_config(data: PlcConfigCreate):
    """Create new PLC configuration."""
    async with db.transaction() as conn:
        # Check duplicate plc_id
        existing = await conn.fetchrow(
            "SELECT id FROM plc_configs WHERE plc_id = $1",
            data.plc_id
        )
        if existing:
            raise HTTPException(status_code=400, detail=f"PLC ID '{data.plc_id}' already exists")

        row = await conn.fetchrow(
            """
            INSERT INTO plc_configs (plc_id, host, slot, timeout, protocol, opcua_endpoint, description, is_active)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id, plc_id, host, slot, timeout, protocol, opcua_endpoint, description, is_active, created_at
            """,
            data.plc_id, data.host, data.slot, data.timeout,
            data.protocol, data.opcua_endpoint, data.description, data.is_active
        )
        logger.info(f"Created PLC config: {data.plc_id} ({data.host})")
        return dict(row)


@router.put("/{plc_id}")
async def update_plc_config(plc_id: str, data: PlcConfigUpdate):
    """Update PLC configuration."""
    async with db.transaction() as conn:
        # Check exists
        existing = await conn.fetchrow(
            "SELECT id FROM plc_configs WHERE plc_id = $1",
            plc_id
        )
        if not existing:
            raise HTTPException(status_code=404, detail=f"PLC config '{plc_id}' not found")

        updates = []
        params = []
        if data.host is not None:
            updates.append(f"host = ${len(params)+1}")
            params.append(data.host)
        if data.slot is not None:
            updates.append(f"slot = ${len(params)+1}")
            params.append(data.slot)
        if data.timeout is not None:
            updates.append(f"timeout = ${len(params)+1}")
            params.append(data.timeout)
        if data.protocol is not None:
            updates.append(f"protocol = ${len(params)+1}")
            params.append(data.protocol)
        if data.opcua_endpoint is not None:
            updates.append(f"opcua_endpoint = ${len(params)+1}")
            params.append(data.opcua_endpoint)
        if data.description is not None:
            updates.append(f"description = ${len(params)+1}")
            params.append(data.description)
        if data.is_active is not None:
            updates.append(f"is_active = ${len(params)+1}")
            params.append(data.is_active)

        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")

        updates.append("created_at = created_at")  # placeholder to avoid trailing comma issues
        query = f"""
            UPDATE plc_configs 
            SET {', '.join(updates)} 
            WHERE plc_id = ${len(params)+1}
            RETURNING id, plc_id, host, slot, timeout, protocol, opcua_endpoint, description, is_active, created_at
        """
        params.append(plc_id)

        row = await conn.fetchrow(query, *params)
        logger.info(f"Updated PLC config: {plc_id}")
        return dict(row)


@router.delete("/{plc_id}")
async def delete_plc_config(plc_id: str):
    """Delete PLC configuration (soft delete by deactivating)."""
    async with db.acquire() as conn:
        result = await conn.execute(
            "UPDATE plc_configs SET is_active = false WHERE plc_id = $1",
            plc_id
        )
        if result != "UPDATE 1":
            raise HTTPException(status_code=404, detail=f"PLC config '{plc_id}' not found")
        logger.info(f"Deactivated PLC config: {plc_id}")
        return {"message": f"PLC config '{plc_id}' deactivated"}


@router.post("/{plc_id}/test")
async def test_plc_connection(plc_id: str):
    """Test connection to a PLC using its stored configuration."""
    from app.clients.plc_client import get_plc_client

    async with db.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT plc_id, host, slot, timeout, protocol, opcua_endpoint FROM plc_configs WHERE plc_id = $1 AND is_active = true",
            plc_id
        )
        if not row:
            raise HTTPException(status_code=404, detail=f"PLC config '{plc_id}' not found or inactive")

    config = dict(row)
    client = get_plc_client(
        plc_id=config["plc_id"],
        host=config["host"],
        slot=config["slot"],
        timeout=config["timeout"]
    )

    try:
        connected = await client.connect()
        info = await client.get_plc_info() if connected else {"status": "offline"}
        await client.disconnect()

        return {
            "plc_id": plc_id,
            "connected": connected,
            "plc_info": info,
            "config": {
                "host": config["host"],
                "slot": config["slot"],
                "timeout": config["timeout"],
                "protocol": config["protocol"]
            }
        }
    except Exception as e:
        logger.error(f"Connection test failed for {plc_id}: {e}")
        return {
            "plc_id": plc_id,
            "connected": False,
            "error": str(e),
            "config": {
                "host": config["host"],
                "slot": config["slot"],
                "timeout": config["timeout"],
                "protocol": config["protocol"]
            }
        }
