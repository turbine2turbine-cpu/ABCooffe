from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List, Any, Dict
from app.core.database import get_production_data, list_production_data

router = APIRouter(prefix="/production-data", tags=["production-data"])

@router.get("/")
async def list_production_data_endpoint(
    status: Optional[str] = None,
    plc_id: Optional[str] = None,
    limit: int = Query(100, ge=1, le=1000)
):
    """List production data records with optional filters."""
    rows = await list_production_data(status=status, plc_id=plc_id, limit=limit)
    return [dict(r) for r in rows]


@router.get("/{order_id}")
async def get_production_data_endpoint(order_id: str):
    """Get production data for a specific order."""
    row = await get_production_data(order_id=order_id)
    if not row:
        raise HTTPException(status_code=404, detail="Production data not found")
    return dict(row)