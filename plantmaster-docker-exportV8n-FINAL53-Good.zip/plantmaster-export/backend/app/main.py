"""FastAPI application entry point."""
import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.database import db
from app.clients.plc_client import disconnect_all_plcs
from app.clients.opcua_client import disconnect_all_opcua
from app.services.plc_service import plc_service
from app.services.timeseries_service import tag_collector
from app.routers import recipes, plc, monitoring, orders, plc_configs, production_data, simulator

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan - startup and shutdown."""
    logger.info("Starting up Recipe PLC Manager...")
    
    # Background startup: connect DB (non-blocking)
    async def _connect_db():
        try:
            await db.connect()
            logger.info("Connected to TimescaleDB")
        except Exception as e:
            logger.error(f"DB connection failed: {e}")
    
    # Background startup: PLC worker (non-blocking)
    async def _start_plc():
        try:
            await plc_service.start_worker()
            logger.info("PLC worker started")
        except Exception as e:
            logger.warning(f"PLC worker start failed: {e}")
    
    # Background startup: tag collector (non-blocking)
    async def _start_collector():
        try:
            async with db.acquire() as conn:
                rows = await conn.fetch("SELECT plc_id FROM plc_configs WHERE is_active = true")
                for row in rows:
                    tag_collector.register_tags(row["plc_id"], [
                        "RoasterA.DrumTemp", "RoasterA.BeanTemp", "RoasterA.InletTemp",
                        "RoasterA.ExhaustTemp", "RoasterA.BatchStatus", "RoasterA.AirFlow",
                        "RoasterA.BatchSize", "RoasterA.BeanTempEnd", "RoasterA.BeanTempStart",
                        "RoasterA.BurnerPower", "RoasterA.ChargeTemp", "RoasterA.CoolTime",
                        "RoasterA.CoolingTime", "RoasterA.DevTime", "RoasterA.DevelopmentRatio",
                        "RoasterA.DevelopmentTime", "RoasterA.DropTemp", "RoasterA.DrumSpeed",
                        "RoasterA.DryingPhase", "RoasterA.FC_Temp", "RoasterA.FC_Time",
                        "RoasterA.FanSpeed", "RoasterA.FirstCrackTemp", "RoasterA.GasPressure",
                        "RoasterA.Humidity", "RoasterA.MaillardPhase", "RoasterA.MoistureLoss",
                        "RoasterA.RateOfRise", "RoasterA.RoR", "RoasterA.RoastTime",
                        "RoasterA.SC_Time", "RoasterA.TATemp", "RoasterA.TurnaroundTemp",
                        "RoasterA.WeightLoss"
                    ])
            await tag_collector.start()
            logger.info("Tag collector started")
        except Exception as e:
            logger.warning(f"Tag collector start failed: {e}")
    
    # Schedule all startup tasks in background (don't await - don't block)
    asyncio.create_task(_connect_db())
    asyncio.create_task(_start_plc())
    asyncio.create_task(_start_collector())
    
    logger.info("Application startup complete - ready to accept requests")
    yield
    
    # ─── SHUTDOWN ───
    logger.info("Shutting down...")
    try:
        await tag_collector.stop()
    except Exception as e:
        logger.warning(f"Tag collector stop error: {e}")
    try:
        await plc_service.stop_worker()
    except Exception as e:
        logger.warning(f"PLC worker stop error: {e}")
    try:
        await disconnect_all_plcs()
    except Exception as e:
        logger.warning(f"PLC disconnect error: {e}")
    try:
        await disconnect_all_opcua()
    except Exception as e:
        logger.warning(f"OPC UA disconnect error: {e}")
    try:
        await db.disconnect()
    except Exception as e:
        logger.warning(f"DB disconnect error: {e}")
    logger.info("Cleanup complete")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(recipes.router)
app.include_router(plc.router)
app.include_router(monitoring.router)
app.include_router(orders.router)
app.include_router(plc_configs.router)
app.include_router(production_data.router)
app.include_router(simulator.router, prefix="/api")


@app.get("/health")
async def health_check():
    return {"status": "ok", "version": settings.APP_VERSION}
