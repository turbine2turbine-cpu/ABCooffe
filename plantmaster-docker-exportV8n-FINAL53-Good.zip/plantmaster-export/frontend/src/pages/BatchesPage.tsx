import { useNavigate } from 'react-router-dom';
import { usePlcStatus, useBatchStatus } from '@/hooks/usePlc';
import { useOrders } from '@/hooks/useOrders';
import { useBatchEvents } from '@/hooks/useBatchEvents';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import {
  Thermometer, Wifi, WifiOff, Flame, ArrowRight,
  Loader2, AlertCircle, Coffee
} from 'lucide-react';

const ROASTER_IDS = ['LINE_A_PLC', 'LINE_B_PLC', 'LINE_C_PLC'];

const ROASTER_INFO: Record<string, { name: string; description: string }> = {
  LINE_A_PLC: { name: 'Roaster A', description: 'Main production line' },
  LINE_B_PLC: { name: 'Roaster B', description: 'Secondary line' },
  LINE_C_PLC: { name: 'Roaster C', description: 'Specialty batch line' },
};

const STATUS_COLORS: Record<string, string> = {
  IDLE: 'bg-stone-100 text-stone-600',
  INITIALIZING: 'bg-blue-100 text-blue-700',
  READY: 'bg-cyan-100 text-cyan-700',
  RUNNING: 'bg-orange-100 text-orange-700',
  HOLDING: 'bg-yellow-100 text-yellow-700',
  HELD: 'bg-amber-100 text-amber-700',
  ABORTING: 'bg-red-100 text-red-700',
  ABORTED: 'bg-red-50 text-red-500',
  COMPLETING: 'bg-green-100 text-green-700',
  COMPLETED: 'bg-green-50 text-green-600',
  UNKNOWN: 'bg-stone-100 text-stone-400',
  OFFLINE: 'bg-stone-100 text-stone-400',
};

function RoasterCard({ plcId }: { plcId: string }) {
  const navigate = useNavigate();
  const { data: plcData, isLoading: plcLoading } = usePlcStatus(plcId);
  const { data: batchData, isLoading: batchLoading } = useBatchStatus(plcId);
  const { data: orders } = useOrders(undefined, plcId);
  useBatchEvents(plcId); // Auto-refresh on batch completion

  const isLoading = plcLoading || batchLoading;
  const info = ROASTER_INFO[plcId] || { name: plcId, description: '' };
  const status = batchData;
  const runningBatch = plcData?.running_batch;
  const pendingCount = orders?.filter((o: any) => o.status === 'pending').length ?? 0;
  const completedCount = plcData?.completed_batches ?? 0;

  if (isLoading) {
    return (
      <Card className="h-64 animate-pulse bg-stone-100">
        <div />
      </Card>
    );
  }

  return (
    <div className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => navigate(`/batches/${plcId}`)}>
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center">
              <Coffee className="w-4 h-4 text-amber-700" />
            </div>
            <div>
              <div className="text-sm font-bold text-stone-800">{info.name}</div>
              <div className="text-xs text-stone-400 font-normal">{info.description}</div>
            </div>
          </CardTitle>
          <div className="flex items-center gap-1.5">
            {runningBatch && (
              <Badge variant="error">Busy: {String(runningBatch.po_number || '')}</Badge>
            )}
            {plcData?.is_online ? (
              <Badge variant="success"><Wifi className="w-3 h-3 mr-1" /> Online</Badge>
            ) : (
              <Badge variant="error"><WifiOff className="w-3 h-3 mr-1" /> Offline</Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 text-sm">
          {/* Batch Status */}
          <div className="flex items-center justify-between">
            <span className="text-stone-500">Batch State</span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${STATUS_COLORS[status?.status_name || 'UNKNOWN']}`}>
              {status?.status_name || 'UNKNOWN'}
            </span>
          </div>

          {/* Running Batch Info */}
          {runningBatch ? (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-2">
              <div className="flex items-center gap-2 text-orange-800 font-medium">
                <Flame className="w-4 h-4" />
                <span>{String(runningBatch.po_number || '')}</span>
              </div>
              <div className="text-xs text-orange-600 mt-0.5 ml-6">
                {String(runningBatch.recipe_code || '')} — {String(runningBatch.quantity || '0')} kg
              </div>
            </div>
          ) : (
            <div className="bg-green-50 border border-green-200 rounded-lg p-2">
              <div className="flex items-center gap-2 text-green-800 font-medium">
                <Wifi className="w-4 h-4" />
                <span>Idle — Ready for next batch</span>
              </div>
            </div>
          )}

          {/* Stats */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="bg-stone-50 rounded-lg p-2 text-center">
              <div className="text-lg font-bold text-stone-700">{pendingCount}</div>
              <div className="text-xs text-stone-500">Pending</div>
            </div>
            <div className="bg-stone-50 rounded-lg p-2 text-center">
              <div className="text-lg font-bold text-stone-700">{completedCount}</div>
              <div className="text-xs text-stone-500">Completed</div>
            </div>
          </div>

          <Button
            size="sm"
            className="w-full mt-2"
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/batches/${plcId}`);
            }}
          >
            View Details <ArrowRight className="w-3 h-3 ml-1" />
          </Button>
        </div>
      </CardContent>
    </Card>
    </div>
  );
}

export default function BatchesPage() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-stone-800">Batch Details by Roaster</h2>
          <p className="text-sm text-stone-500 mt-1">Select a roaster to view batch details and control operations</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {ROASTER_IDS.map(plcId => (
          <RoasterCard key={plcId} plcId={plcId} />
        ))}
      </div>
    </div>
  );
}
