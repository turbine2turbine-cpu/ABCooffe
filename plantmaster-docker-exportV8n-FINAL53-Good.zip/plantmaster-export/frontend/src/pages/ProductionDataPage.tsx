import { useParams, useNavigate } from 'react-router-dom';
import { useProductionData } from '@/hooks/useProductionData';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import { ArrowLeft, FileText } from 'lucide-react';

export default function ProductionDataPage() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { data, isLoading } = useProductionData(orderId);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-700" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-20">
        <FileText className="w-12 h-12 text-stone-300 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-stone-700">No Production Data</h2>
        <p className="text-stone-500 mt-2">Production data not found for this batch.</p>
        <Button variant="outline" className="mt-4" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Go Back
        </Button>
      </div>
    );
  }

  const statusColor = data.status === 'completed'
    ? 'bg-green-100 text-green-700'
    : data.status === 'cancelled'
    ? 'bg-red-100 text-red-700'
    : 'bg-stone-100 text-stone-600';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4 mr-1" /> Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-stone-800">Production Data</h1>
            <p className="text-sm text-stone-500">Batch {data.po_number}</p>
          </div>
        </div>
        <Badge className={statusColor}>{data.status.toUpperCase()}</Badge>
      </div>

      <Card>
        <CardHeader><CardTitle>Batch Information</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <InfoItem label="PO Number" value={data.po_number} />
            <InfoItem label="PLC" value={data.plc_id || '-'} />
            <InfoItem label="Recipe" value={data.recipe_code || '-'} />
            <InfoItem label="Recipe Name" value={data.recipe_name || '-'} />
            <InfoItem label="Init Time" value={data.init_at ? new Date(data.init_at).toLocaleString() : '-'} />
            <InfoItem label="Completed" value={data.completed_at ? new Date(data.completed_at).toLocaleString() : '-'} />
            <InfoItem label="Operator" value={data.operator || 'system'} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Temperatures (°C)</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Metric label="Bean Temp Start" value={data.bean_temp_start} />
            <Metric label="Bean Temp End" value={data.bean_temp_end} />
            <Metric label="Drop Temp" value={data.drop_temp} />
            <Metric label="Charge Temp" value={data.charge_temp} />
            <Metric label="Turnaround" value={data.turnaround_temp} />
            <Metric label="TA Temp" value={data.ta_temp} />
            <Metric label="First Crack" value={data.first_crack_temp} />
            <Metric label="Exhaust Avg" value={data.exhaust_temp_avg} />
            <Metric label="Inlet Avg" value={data.inlet_temp_avg} />
            <Metric label="Drum Avg" value={data.drum_temp_avg} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Times (seconds)</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Metric label="Roast Time" value={data.roast_time} />
            <Metric label="Dev Time" value={data.dev_time} />
            <Metric label="Cool Time" value={data.cool_time} />
            <Metric label="Drying Phase" value={data.drying_phase} />
            <Metric label="Maillard Phase" value={data.maillard_phase} />
            <Metric label="First Crack Time" value={data.first_crack_time} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Loss & Equipment</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Metric label="Moisture Loss %" value={data.moisture_loss} />
            <Metric label="Weight Loss %" value={data.weight_loss} />
            <Metric label="Burner Power %" value={data.burner_power_avg} />
            <Metric label="Fan Speed %" value={data.fan_speed_avg} />
            <Metric label="Gas Pressure" value={data.gas_pressure_avg} />
            <Metric label="Air Flow" value={data.air_flow_avg} />
            <Metric label="Drum Speed RPM" value={data.drum_speed} />
          </div>
        </CardContent>
      </Card>

      {data.notes && (
        <Card>
          <CardHeader><CardTitle>Notes</CardTitle></CardHeader>
          <CardContent><p className="text-stone-700">{data.notes}</p></CardContent>
        </Card>
      )}
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-stone-500 uppercase tracking-wider">{label}</p>
      <p className="text-sm font-medium text-stone-800">{value}</p>
    </div>
  );
}

function Metric({ label, value }: { label: string; value?: number | null }) {
  return (
    <div className="bg-stone-50 rounded-lg p-3">
      <p className="text-xs text-stone-500 mb-1">{label}</p>
      <p className="text-lg font-semibold text-stone-800">
        {value !== null && value !== undefined ? value.toFixed(2) : '-'}
      </p>
    </div>
  );
}