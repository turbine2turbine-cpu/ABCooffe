import { useState, useEffect } from 'react';
import { plcConfigApi } from '@/services/api';
import type { PlcConfig } from '@/types';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Badge from '@/components/ui/Badge';
import { Settings, Plus, Wifi, WifiOff, Trash2, Server } from 'lucide-react';

export default function PlcConfigPage() {
  const [configs, setConfigs] = useState<PlcConfig[]>([]);
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    plc_id: '',
    host: '',
    slot: 0,
    timeout: 5,
    protocol: 'pylogix',
    opcua_endpoint: '',
    description: ''
  });

  const load = async () => {
    setLoading(true);
    try {
      const data = await plcConfigApi.list();
      setConfigs(data);
    } catch (e) {
      console.error('Failed to load PLC configs:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    try {
      await plcConfigApi.create(form);
      setForm({ plc_id: '', host: '', slot: 0, timeout: 5, protocol: 'pylogix', opcua_endpoint: '', description: '' });
      setShowForm(false);
      load();
    } catch (e: any) {
      alert('Failed to create: ' + (e.response?.data?.detail || e.message));
    }
  };

  const handleTest = async (plcId: string) => {
    try {
      const result = await plcConfigApi.test(plcId);
      if (result.connected) {
        alert(`Connected to ${plcId}\nProduct: ${result.plc_info?.product_name || 'N/A'}\nRevision: ${result.plc_info?.revision || 'N/A'}`);
      } else {
        alert(`Connection failed: ${result.error || 'Unknown error'}`);
      }
    } catch (e: any) {
      alert('Test failed: ' + (e.response?.data?.detail || e.message));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-stone-800 flex items-center gap-2">
          <Settings className="w-6 h-6" /> PLC Configuration
        </h2>
        <Button onClick={() => setShowForm(!showForm)}>
          <Plus className="w-4 h-4 mr-1" /> Add PLC
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader><CardTitle>Add New PLC</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <Input
                placeholder="PLC ID (e.g. LINE_D_PLC)"
                value={form.plc_id}
                onChange={e => setForm({ ...form, plc_id: e.target.value })}
              />
              <Input
                placeholder="IP Address (e.g. 192.168.20.10)"
                value={form.host}
                onChange={e => setForm({ ...form, host: e.target.value })}
              />
              <Input
                placeholder="Description"
                value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })}
              />
              <Input
                type="number"
                placeholder="Slot"
                value={form.slot}
                onChange={e => setForm({ ...form, slot: Number(e.target.value) })}
              />
              <Input
                type="number"
                placeholder="Timeout (sec)"
                value={form.timeout}
                onChange={e => setForm({ ...form, timeout: Number(e.target.value) })}
              />
              <select
                className="px-3 py-2 border border-stone-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                value={form.protocol}
                onChange={e => setForm({ ...form, protocol: e.target.value })}
              >
                <option value="pylogix">PyLogix (EtherNet/IP)</option>
                <option value="opcua">OPC UA</option>
              </select>
            </div>
            <div className="mt-3 flex gap-2">
              <Button onClick={handleCreate}><Plus className="w-4 h-4 mr-1" /> Save</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {loading ? (
        <div className="text-center text-stone-400 py-12">Loading...</div>
      ) : configs.length === 0 ? (
        <div className="text-center text-stone-400 py-12">
          <Server className="w-12 h-12 mx-auto mb-3 text-stone-300" />
          <p>No PLC configurations found.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {configs.map(cfg => (
            <Card key={cfg.plc_id}>
              <CardContent className="flex items-center justify-between py-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-stone-800">{cfg.plc_id}</h3>
                    {cfg.is_active ? (
                      <Badge variant="success">Active</Badge>
                    ) : (
                      <Badge>Inactive</Badge>
                    )}
                  </div>
                  <p className="text-sm text-stone-500 mt-1">
                    {cfg.host} (slot {cfg.slot}) &bull; {cfg.protocol}
                    {cfg.description && ` &bull; ${cfg.description}`}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleTest(cfg.plc_id)}>
                    <Wifi className="w-4 h-4 mr-1" /> Test
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={async () => {
                      if (confirm(`Deactivate PLC config '${cfg.plc_id}'?`)) {
                        await plcConfigApi.delete(cfg.plc_id);
                        load();
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
