import { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Alert from '@/components/ui/Alert';
import { Power, PowerOff, RefreshCw, Server, Activity, Globe, Tag } from 'lucide-react';
import api from '@/services/api';

interface SimStatus {
  enabled: boolean;
  running: boolean;
  plc_id: string;
  poll_interval: number;
  last_update: string | null;
  tag_count: number;
}

interface PlcConnection {
  plc_host: string;
  plc_slot: number;
  plc_timeout: number;
  opc_ua_endpoint: string | null;
}

interface PlcState {
  plc_id: string;
  batch_status: number;
  status_name: string;
  batch_id: string | null;
  recipe_id: string | null;
  is_online: boolean;
  can_initialize: boolean;
  can_start: boolean;
  can_hold: boolean;
  can_abort: boolean;
  can_reset: boolean;
  plc_available: boolean;
  timestamp: string;
}

interface PlcTagResult {
  tag: string;
  value: any;
  status: string;
  error?: string;
}

const BATCH_STATUS_NAMES: Record<number, string> = {
  0: 'IDLE',
  1: 'INITIALIZING',
  2: 'READY',
  3: 'RUNNING',
  4: 'HOLDING',
  5: 'HELD',
  6: 'ABORTING',
  7: 'ABORTED',
  8: 'COMPLETING',
  9: 'COMPLETED',
};

const BATCH_STATUS_COLORS: Record<number, string> = {
  0: 'bg-stone-100 text-stone-600',
  1: 'bg-yellow-100 text-yellow-700',
  2: 'bg-blue-100 text-blue-700',
  3: 'bg-green-100 text-green-700',
  4: 'bg-orange-100 text-orange-700',
  5: 'bg-orange-100 text-orange-700',
  6: 'bg-red-100 text-red-700',
  7: 'bg-red-100 text-red-700',
  8: 'bg-purple-100 text-purple-700',
  9: 'bg-green-100 text-green-700',
};

export default function SimulatorPage() {
  const [status, setStatus] = useState<SimStatus | null>(null);
  const [simValues, setSimValues] = useState<Record<string, number>>({});
  const [plcValues, setPlcValues] = useState<Record<string, number>>({});
  const [plcTags, setPlcTags] = useState<PlcTagResult[]>([]);
  const [plcState, setPlcState] = useState<PlcState | null>(null);
  const [plcConn, setPlcConn] = useState<PlcConnection | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<string>('');
  const statusRef = useRef<SimStatus | null>(null);

  // Keep statusRef in sync with status state
  useEffect(() => {
    statusRef.current = status;
  }, [status]);

  const fetchStatus = useCallback(async () => {
    try {
      const { data } = await api.get('/simulator/status');
      console.log('[Simulator] Status:', data);
      setStatus(data);
      setError(null);
    } catch (e: any) {
      console.error('Failed to fetch status:', e);
      setError(`Status API error: ${e?.response?.status || e?.message || 'Unknown'}`);
    }
  }, []);

  const fetchSimValues = useCallback(async () => {
    try {
      const { data } = await api.get('/simulator/values');
      console.log('[Simulator] Values:', data);
      setSimValues(data.values || {});
    } catch (e: any) {
      console.error('Failed to fetch sim values:', e);
    }
  }, []);

  const fetchPlcValues = useCallback(async () => {
    try {
      const { data } = await api.get('/simulator/plc-values');
      setPlcValues(data.values || {});
    } catch (e: any) {
      console.error('Failed to fetch PLC values:', e);
    }
  }, []);

  const fetchPlcTags = useCallback(async () => {
    try {
      const { data } = await api.get('/simulator/plc-tags');
      setPlcTags(data.tags || []);
    } catch (e: any) {
      console.error('Failed to fetch PLC tags:', e);
    }
  }, []);

  const fetchPlcState = useCallback(async () => {
    try {
      const { data } = await api.get('/simulator/plc-state');
      setPlcState(data);
    } catch (e: any) {
      console.error('Failed to fetch PLC state:', e);
    }
  }, []);

  const fetchPlcConnection = useCallback(async () => {
    try {
      const { data } = await api.get('/simulator/plc-connection');
      setPlcConn(data);
    } catch (e: any) {
      console.error('Failed to fetch PLC connection:', e);
    }
  }, []);

  const fetchAll = useCallback(async () => {
    setLastRefresh(new Date().toLocaleTimeString());
    await fetchStatus();
    await Promise.all([
      fetchSimValues(),
      fetchPlcValues(),
      fetchPlcTags(),
      fetchPlcState(),
      fetchPlcConnection(),
    ]);
  }, [fetchStatus, fetchSimValues, fetchPlcValues, fetchPlcTags, fetchPlcState, fetchPlcConnection]);

  const enable = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log('[Simulator] Enabling...');
      const res = await api.post('/simulator/enable?plc_id=LINE_A_PLC&interval=1.0');
      console.log('[Simulator] Enable response:', res.data);
      await new Promise(r => setTimeout(r, 300));
      await fetchAll();
    } catch (e: any) {
      console.error('Failed to enable:', e);
      setError(`Enable failed: ${e?.response?.data?.detail || e?.message || 'Unknown error'}`);
    }
    setLoading(false);
  }, [fetchAll]);

  const disable = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log('[Simulator] Disabling...');
      const res = await api.post('/simulator/disable');
      console.log('[Simulator] Disable response:', res.data);
      await fetchAll();
    } catch (e: any) {
      console.error('Failed to disable:', e);
      setError(`Disable failed: ${e?.response?.data?.detail || e?.message || 'Unknown error'}`);
    }
    setLoading(false);
  }, [fetchAll]);

  // Polling: fetch status + sim values every 2 seconds
  useEffect(() => {
    console.log('[Simulator] Component mounted, starting polling...');
    fetchAll();

    const interval = setInterval(() => {
      fetchStatus();
      fetchPlcState();
      fetchPlcConnection();
      // Always fetch sim values if simulator is enabled (read from ref to avoid stale closure)
      if (statusRef.current?.enabled) {
        fetchSimValues();
        fetchPlcValues();
        fetchPlcTags();
      }
    }, 2000);

    return () => {
      console.log('[Simulator] Component unmounted, clearing polling...');
      clearInterval(interval);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-stone-800">Production Data Simulator</h1>
        <div className="flex items-center gap-3">
          <span className="text-xs text-stone-400">Last refresh: {lastRefresh || '-'}</span>
          <Badge className={status?.enabled ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-500'}>
            {status?.enabled ? 'RUNNING' : 'STOPPED'}
          </Badge>
        </div>
      </div>

      {error && (
        <Alert variant="error">
          {error}
        </Alert>
      )}

      <Card>
        <CardHeader><CardTitle>Control</CardTitle></CardHeader>
        <CardContent className="flex gap-4 flex-wrap">
          {status?.enabled ? (
            <Button variant="outline" onClick={disable} disabled={loading} className="text-red-600 border-red-200 hover:bg-red-50">
              <PowerOff className="w-4 h-4 mr-2" /> Disable Simulator
            </Button>
          ) : (
            <Button onClick={enable} disabled={loading} className="bg-green-600 hover:bg-green-700 text-white">
              <Power className="w-4 h-4 mr-2" /> Enable Simulator
            </Button>
          )}
          <Button variant="outline" onClick={fetchAll} disabled={loading}>
            <RefreshCw className="w-4 h-4 mr-2" /> Refresh All
          </Button>
        </CardContent>
      </Card>

      {status && (
        <Card>
          <CardHeader><CardTitle>Simulator Status</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <div>
              <p className="text-xs text-stone-500">Enabled</p>
              <p className="font-medium">{status.enabled ? 'Yes' : 'No'}</p>
            </div>
            <div>
              <p className="text-xs text-stone-500">Running</p>
              <p className="font-medium">{status.running ? 'Yes' : 'No'}</p>
            </div>
            <div>
              <p className="text-xs text-stone-500">PLC ID</p>
              <p className="font-medium">{status.plc_id}</p>
            </div>
            <div>
              <p className="text-xs text-stone-500">Interval</p>
              <p className="font-medium">{status.poll_interval}s</p>
            </div>
            <div>
              <p className="text-xs text-stone-500">Last Update</p>
              <p className="font-medium">{status.last_update ? new Date(status.last_update).toLocaleTimeString() : '-'}</p>
            </div>
            <div>
              <p className="text-xs text-stone-500">Tag Count</p>
              <p className="font-medium">{status.tag_count}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {plcConn && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-500" />
              PLC Connection (RoasterA)
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-xs text-stone-500">PLC Host (IP)</p>
              <p className="font-mono font-medium text-stone-800">{plcConn.plc_host}</p>
            </div>
            <div>
              <p className="text-xs text-stone-500">Slot</p>
              <p className="font-mono font-medium text-stone-800">{plcConn.plc_slot}</p>
            </div>
            <div>
              <p className="text-xs text-stone-500">Timeout</p>
              <p className="font-mono font-medium text-stone-800">{plcConn.plc_timeout}s</p>
            </div>
            <div>
              <p className="text-xs text-stone-500">OPC UA</p>
              <p className="font-mono font-medium text-stone-800">{plcConn.opc_ua_endpoint || 'Disabled'}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {plcState && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-amber-500" />
              Batch State Machine
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 flex-wrap">
              <Badge className={plcState.is_online ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}>
                {plcState.is_online ? 'ONLINE' : 'OFFLINE'}
              </Badge>
              <Badge className={BATCH_STATUS_COLORS[plcState.batch_status] || 'bg-stone-100 text-stone-600'}>
                {plcState.status_name || BATCH_STATUS_NAMES[plcState.batch_status] || 'UNKNOWN'}
              </Badge>
              <span className="text-sm text-stone-500">State Value: <span className="font-mono font-medium">{plcState.batch_status}</span></span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div className="bg-stone-50 rounded-lg p-3">
                <p className="text-xs text-stone-500">Batch ID (PO)</p>
                <p className="font-mono font-medium text-stone-800 truncate">{plcState.batch_id || '-'}</p>
              </div>
              <div className="bg-stone-50 rounded-lg p-3">
                <p className="text-xs text-stone-500">Recipe ID</p>
                <p className="font-mono font-medium text-stone-800 truncate">{plcState.recipe_id || '-'}</p>
              </div>
              <div className="bg-stone-50 rounded-lg p-3">
                <p className="text-xs text-stone-500">PLC Available</p>
                <p className="font-medium text-stone-800">{plcState.plc_available ? 'Yes' : 'No'}</p>
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Badge className={plcState.can_initialize ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-400'}>Can Initialize</Badge>
              <Badge className={plcState.can_start ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-400'}>Can Start</Badge>
              <Badge className={plcState.can_hold ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-400'}>Can Hold</Badge>
              <Badge className={plcState.can_abort ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-400'}>Can Abort</Badge>
              <Badge className={plcState.can_reset ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-400'}>Can Reset</Badge>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-blue-500" />
            PLC Raw Tags (RoasterA.*) — {plcTags.length} tags
          </CardTitle>
        </CardHeader>
        <CardContent>
          {plcTags.length === 0 ? (
            <p className="text-stone-500 text-center py-4">No PLC tag data. Check PLC connection or enable simulator.</p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {plcTags.map((tag) => (
                <div key={tag.tag} className={`rounded-lg p-3 border ${tag.status === 'Success' ? 'bg-blue-50 border-blue-100' : 'bg-red-50 border-red-100'}`}>
                  <p className="text-xs text-stone-500 truncate" title={tag.tag}>{tag.tag.replace('RoasterA.', '')}</p>
                  <p className="text-lg font-semibold text-stone-800">
                    {tag.status === 'Success' ? (tag.value !== undefined && tag.value !== null ? Number(tag.value).toFixed(2) : '-') : 'ERR'}
                  </p>
                  {tag.error && <p className="text-xs text-red-500 truncate">{tag.error}</p>}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="w-5 h-5 text-indigo-500" />
            PLC Production Data (RoasterAProd.*) — {Object.keys(plcValues).length} tags
          </CardTitle>
        </CardHeader>
        <CardContent>
          {Object.keys(plcValues).length === 0 ? (
            <p className="text-stone-500 text-center py-4">No PLC production data available. Enable simulator or check PLC connection.</p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {Object.entries(plcValues).map(([tag, value]) => (
                <div key={tag} className="bg-indigo-50 rounded-lg p-3 border border-indigo-100">
                  <p className="text-xs text-indigo-600 truncate" title={tag}>{tag}</p>
                  <p className="text-lg font-semibold text-stone-800">{value !== undefined && value !== null ? Number(value).toFixed(2) : '-'}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500"></span>
            Simulated Values (Generated) — {Object.keys(simValues).length} tags
          </CardTitle>
        </CardHeader>
        <CardContent>
          {Object.keys(simValues).length === 0 ? (
            <p className="text-stone-500 text-center py-4">No simulated data. Click <strong>Enable Simulator</strong> to generate values.</p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {Object.entries(simValues).map(([tag, value]) => (
                <div key={tag} className="bg-green-50 rounded-lg p-3 border border-green-100">
                  <p className="text-xs text-green-600 truncate" title={tag}>{tag.replace('RoasterAProd.', '')}</p>
                  <p className="text-lg font-semibold text-stone-800">{value !== undefined && value !== null ? Number(value).toFixed(2) : '-'}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
