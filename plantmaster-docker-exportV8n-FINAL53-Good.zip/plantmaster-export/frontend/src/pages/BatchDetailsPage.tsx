import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { usePlcStatus, useBatchStatus, usePlcTagValues } from '@/hooks/usePlc';
import { useBatchEvents } from '@/hooks/useBatchEvents';
import { Card } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import {
  ArrowLeft, AlertCircle, Coffee, CheckCircle,
  Thermometer, Wind, Zap, Gauge, TrendingUp
} from 'lucide-react';

const ROASTER_INFO: Record<string, { name: string; description: string }> = {
  LINE_A_PLC: { name: 'Roaster A', description: 'Main production line' },
  LINE_B_PLC: { name: 'Roaster B', description: 'Secondary line' },
  LINE_C_PLC: { name: 'Roaster C', description: 'Specialty batch line' },
};

export default function BatchDetailsPage() {
  const { plcId } = useParams<{ plcId: string }>();
  const navigate = useNavigate();

  if (!plcId) {
    return (
      <div className="text-center py-20">
        <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-red-700">No Roaster Selected</h2>
        <Button className="mt-4" onClick={() => navigate('/batches')}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Batches
        </Button>
      </div>
    );
  }

  const info = ROASTER_INFO[plcId] || { name: plcId, description: '' };
  useBatchEvents(plcId); // Auto-refresh on batch completion

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="outline" size="sm" onClick={() => navigate('/batches')}>
          <ArrowLeft className="w-4 h-4 mr-1" /> Back
        </Button>
        <div>
          <h2 className="text-xl font-bold text-stone-800 flex items-center gap-2">
            <Coffee className="w-5 h-5 text-amber-600" />
            {info.name} — Batch Details
          </h2>
          <p className="text-sm text-stone-500">{info.description}</p>
        </div>
      </div>

      <KpiRow plcId={plcId} />
      <DashboardMiddle plcId={plcId} />
    </div>
  );
}

/* ─── helpers ─── */
function fmt3(val: unknown): string {
  if (val === null || val === undefined) return '--';
  const n = Number(val);
  if (Number.isNaN(n)) return String(val);
  return n.toFixed(3);
}

function tagVal(tags: any[], tagName: string): number | null {
  const t = tags.find((x: any) => x.tag === tagName);
  return t && t.value !== null ? Number(t.value) : null;
}

function Sparkline({ data, color = '#0ea5e9', width = 120, height = 40 }: { data: number[]; color?: string; width?: number; height?: number }) {
  if (!data.length) return <div className="h-10" />;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1 || 1)) * width;
    const y = height - ((v - min) / range) * height;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={width} height={height} className="overflow-visible">
      <polyline points={pts} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ─── KPI Row ─── */
function KpiRow({ plcId }: { plcId: string }) {
  const tagNames = [
    'RoasterA.BeanTemp', 'RoasterA.BurnerPower', 'RoasterA.AirFlow',
    'RoasterA.DrumSpeed', 'RoasterA.ChargeTemp', 'RoasterA.DevelopmentRatio',
  ];
  const { data: tagData } = usePlcTagValues(plcId, tagNames);

  /* keep tag values in memory — merge new readings, never clear */
  const [tagMemory, setTagMemory] = useState<Record<string, number>>({});
  const [history, setHistory] = useState<Record<string, number[]>>({});

  useEffect(() => {
    if (!tagData?.results) return;
    setTagMemory(prev => {
      const next = { ...prev };
      tagData.results.forEach((r: any) => {
        if (r.value !== null && r.value !== undefined) {
          const v = Number(r.value);
          if (!Number.isNaN(v)) next[r.tag] = v;
        }
      });
      return next;
    });
    setHistory(prev => {
      const next = { ...prev };
      tagData.results.forEach((r: any) => {
        const v = Number(r.value);
        if (!Number.isNaN(v)) {
          const arr = next[r.tag] ? [...next[r.tag], v] : [v];
          next[r.tag] = arr.slice(-20);
        }
      });
      return next;
    });
  }, [tagData]);

  const kpi = [
    { label: 'Bean Temp', tag: 'RoasterA.BeanTemp', unit: '°C', icon: Thermometer, color: '#0ea5e9' },
    { label: 'Burner Power', tag: 'RoasterA.BurnerPower', unit: '%', icon: Zap, color: '#f59e0b' },
    { label: 'Air Flow', tag: 'RoasterA.AirFlow', unit: 'm³/h', icon: Wind, color: '#10b981' },
    { label: 'Drum Speed', tag: 'RoasterA.DrumSpeed', unit: 'rpm', icon: Gauge, color: '#8b5cf6' },
    { label: 'Charge Temp', tag: 'RoasterA.ChargeTemp', unit: '°C', icon: Thermometer, color: '#ef4444' },
    { label: 'Dev Ratio', tag: 'RoasterA.DevelopmentRatio', unit: '%', icon: TrendingUp, color: '#06b6d4' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {kpi.map(({ label, tag, unit, icon: Icon, color }) => {
        const val = tagMemory[tag] ?? null;
        return (
          <Card key={tag} className="p-4 flex flex-col justify-between min-h-[140px]">
            <div className="flex items-start justify-between">
              <span className="text-xs font-medium text-stone-500 uppercase tracking-wide">{label}</span>
              <Icon className="w-4 h-4" style={{ color }} />
            </div>
            <div className="mt-2">
              <span className="text-3xl font-bold" style={{ color }}>{fmt3(val)}</span>
              <span className="text-sm text-stone-400 ml-1">{unit}</span>
            </div>
            <div className="mt-auto pt-2">
              <Sparkline data={history[tag] || []} color={color} />
            </div>
          </Card>
        );
      })}
    </div>
  );
}

/* ─── Circular Gauge ─── */
function CircularGauge({ value, label, subLabel }: { value: number; label: string; subLabel?: string }) {
  const data = [
    { name: 'done', value: Math.min(value, 100) },
    { name: 'remaining', value: Math.max(100 - value, 0) },
  ];
  const COLORS = ['#0ea5e9', '#e5e7eb'];

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-40 h-40">
        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
          <circle cx="50" cy="50" r="40" fill="none" stroke={COLORS[1]} strokeWidth="12" />
          <circle cx="50" cy="50" r="40" fill="none" stroke={COLORS[0]} strokeWidth="12"
            strokeDasharray={`${2 * Math.PI * 40}`}
            strokeDashoffset={`${2 * Math.PI * 40 * (1 - Math.min(value, 100) / 100)}`}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-stone-800">{value.toFixed(1)}%</span>
          {subLabel && <span className="text-xs text-stone-400">{subLabel}</span>}
        </div>
      </div>
      <span className="text-sm font-medium text-stone-600 mt-1">{label}</span>
    </div>
  );
}

/* ─── Dashboard Middle Section ─── */
function DashboardMiddle({ plcId }: { plcId: string }) {
  const { data: plcData } = usePlcStatus(plcId);
  const { data: batchData } = useBatchStatus(plcId);

  /* Read tags directly from PLC every 3s */
  const tagNames = [
    'RoasterA.BeanTemp', 'RoasterA.BurnerPower', 'RoasterA.AirFlow',
    'RoasterA.DrumSpeed', 'RoasterA.ChargeTemp', 'RoasterA.DevelopmentRatio',
    'RoasterA.BeanTempStart', 'RoasterA.BeanTempEnd', 'RoasterA.CoolTime',
    'RoasterA.DevTime', 'RoasterA.BatchSize',
  ];
  const { data: tagData } = usePlcTagValues(plcId, tagNames);

  /* Keep tag values in memory — merge new readings, never clear */
  const [tagMemory, setTagMemory] = useState<Record<string, number>>({});

  useEffect(() => {
    if (!tagData?.results) return;
    setTagMemory(prev => {
      const next = { ...prev };
      tagData.results.forEach((r: any) => {
        if (r.value !== null && r.value !== undefined) {
          const v = Number(r.value);
          if (!Number.isNaN(v)) next[r.tag] = v;
        }
      });
      return next;
    });
  }, [tagData]);

  const runningBatch = plcData?.running_batch;
  const status = batchData;
  const isOnline = status?.is_online ?? false;
  const progress = status?.batch_status === 3 ? 72.8 : status?.batch_status === 9 ? 100 : 0;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* LEFT: Production Status */}
      <Card className="p-6">
        <h3 className="text-sm font-bold text-stone-700 mb-4 flex items-center gap-2">
          <Coffee className="w-4 h-4" />
          Production Status
        </h3>

        {runningBatch ? (
          <>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-lg font-bold text-sky-700">{runningBatch.po_number}</span>
              <Badge variant="success">RUNNING</Badge>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm mb-4">
              <div>
                <p className="text-stone-400 text-xs">Recipe</p>
                <p className="font-medium text-stone-700">{runningBatch.recipe_code || '--'}</p>
              </div>
              <div>
                <p className="text-stone-400 text-xs">Quantity</p>
                <p className="font-medium text-stone-700">{runningBatch.quantity} kg</p>
              </div>
            </div>
          </>
        ) : (
          <div className="flex items-center gap-3 text-green-800 mb-4">
            <CheckCircle className="w-6 h-6" />
            <div>
              <div className="font-bold">No Active Batch</div>
              <div className="text-sm text-green-600">Roaster is idle and ready</div>
            </div>
          </div>
        )}

        {/* Status indicators */}
        <div className="space-y-2">
          <div className="flex items-center justify-between bg-green-50 rounded-lg px-3 py-2">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm font-medium text-green-700">Running</span>
            </div>
            <Badge variant="success" className="text-xs">GOOD</Badge>
          </div>
          <div className="flex items-center justify-between bg-red-50 rounded-lg px-3 py-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600" />
              <span className="text-sm font-medium text-red-700">Alarms</span>
            </div>
            <Badge variant="error" className="text-xs">{plcData?.unack_alarms ?? 0}</Badge>
          </div>
        </div>
      </Card>

      {/* CENTER: Gauge */}
      <Card className="p-6 flex flex-col items-center justify-center">
        <h3 className="text-sm font-bold text-stone-700 mb-6 self-start flex items-center gap-2">
          <Gauge className="w-4 h-4" />
          Roasting Progress
        </h3>
        <CircularGauge value={progress} label="Batch Progress" subLabel={status?.status_name || 'IDLE'} />
        <div className="mt-6 grid grid-cols-2 gap-4 w-full">
          <div className="text-center">
            <p className="text-2xl font-bold text-stone-800">{fmt3(tagMemory['RoasterA.BeanTempStart'] ?? null)}</p>
            <p className="text-xs text-stone-400">Start Temp (°C)</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-stone-800">{fmt3(tagMemory['RoasterA.BeanTempEnd'] ?? null)}</p>
            <p className="text-xs text-stone-400">End Temp (°C)</p>
          </div>
        </div>
      </Card>

      {/* RIGHT: Other Parameters */}
      <Card className="p-6">
        <h3 className="text-sm font-bold text-stone-700 mb-4">Other Parameters</h3>
        <div className="grid grid-cols-2 gap-4">
          <ParamBox label="Bean Temp Start" value={fmt3(tagMemory['RoasterA.BeanTempStart'] ?? null)} unit="°C" />
          <ParamBox label="Bean Temp End" value={fmt3(tagMemory['RoasterA.BeanTempEnd'] ?? null)} unit="°C" />
          <ParamBox label="Cool Time" value={fmt3(tagMemory['RoasterA.CoolTime'] ?? null)} unit="sec" />
          <ParamBox label="Dev Time" value={fmt3(tagMemory['RoasterA.DevTime'] ?? null)} unit="sec" />
          <ParamBox label="Batch Size" value={fmt3(tagMemory['RoasterA.BatchSize'] ?? null)} unit="kg" />
          <ParamBox label="Air Flow" value={fmt3(tagMemory['RoasterA.AirFlow'] ?? null)} unit="m³/h" />
        </div>

        <div className="mt-4 pt-4 border-t border-stone-100">
          <h4 className="text-xs font-medium text-stone-500 mb-2">PLC Batch State</h4>
          <div className="flex items-center gap-2">
            <Badge variant={isOnline ? 'success' : 'error'}>
              {isOnline ? 'Online' : 'Offline'}
            </Badge>
            <span className="text-sm font-mono font-semibold text-amber-700">
              {status?.status_name || 'UNKNOWN'}
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1 font-mono">{status?.batch_id || '--'}</p>
        </div>
      </Card>
    </div>
  );
}

function ParamBox({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="bg-stone-50 rounded-lg p-3">
      <p className="text-xs text-stone-400 mb-1">{label}</p>
      <p className="text-lg font-bold text-stone-800">{value}<span className="text-xs font-normal text-stone-400 ml-1">{unit}</span></p>
    </div>
  );
}

