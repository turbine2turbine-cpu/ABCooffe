import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { plcApi } from '@/services/api';
import type { DownloadRequest, DownloadStatus, BatchStatusResponse, BatchControlResponse } from '@/types';

export function usePlcStatus(plcId: string) {
  return useQuery({
    queryKey: ['plc-status', plcId],
    queryFn: () => plcApi.status(plcId),
    refetchInterval: 5000,
    enabled: !!plcId,
  });
}

export function useBatchStatus(plcId: string) {
  return useQuery<BatchStatusResponse>({
    queryKey: ['batch-status', plcId],
    queryFn: () => plcApi.batchStatus(plcId),
    refetchInterval: 2000,
    enabled: !!plcId,
  });
}

export function useBatchControl() {
  const queryClient = useQueryClient();
  return useMutation<BatchControlResponse, Error, { plcId: string; command: string; data?: { recipe_id?: string; po_number?: string; order_id?: string } }>({
    mutationFn: ({ plcId, command, data }) => plcApi.batchControl(plcId, command, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['batch-status', variables.plcId] });
      queryClient.invalidateQueries({ queryKey: ['plc-status', variables.plcId] });
    },
  });
}

export function useDownloadRecipe() {
  return useMutation({
    mutationFn: plcApi.download,
  });
}

export function useDownloadStatus(txId: string) {
  return useQuery<DownloadStatus>({
    queryKey: ['download-status', txId],
    queryFn: () => plcApi.downloadStatus(txId),
    refetchInterval: (query) => {
      const data = query.state.data as DownloadStatus | undefined;
      return data?.status === 'PENDING' ? 1000 : false;
    },
    enabled: !!txId,
  });
}

export function useReadTags() {
  return useMutation({
    mutationFn: ({ plcId, tagNames }: { plcId: string; tagNames: string[] }) =>
      plcApi.readTags(plcId, tagNames),
  });
}

export function usePlcTagValues(plcId: string, tagNames: string[]) {
  return useQuery({
    queryKey: ['plc-tag-values', plcId, tagNames.join(',')],
    queryFn: () => plcApi.readTags(plcId, tagNames),
    refetchInterval: 3000,
    enabled: !!plcId && tagNames.length > 0,
  });
}
