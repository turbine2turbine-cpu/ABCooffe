import { useQuery } from '@tanstack/react-query';
import api from '@/services/api';
import type { ProductionData } from '@/types';

export function useProductionData(orderId?: string) {
  return useQuery<ProductionData | null>({
    queryKey: ['production-data', orderId],
    queryFn: async () => {
      if (!orderId) return null;
      const { data } = await api.get(`/production-data/${orderId}`);
      return data;
    },
    enabled: !!orderId,
  });
}

export function useProductionDataList(status?: string, plc_id?: string) {
  return useQuery<ProductionData[]>({
    queryKey: ['production-data-list', status, plc_id],
    queryFn: async () => {
      const { data } = await api.get('/production-data', {
        params: { status, plc_id }
      });
      return data;
    },
  });
}