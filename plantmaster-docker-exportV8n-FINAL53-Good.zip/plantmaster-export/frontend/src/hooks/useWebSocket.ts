import { useEffect, useRef, useState, useCallback } from 'react';
import type { WebSocketMessage } from '@/types';

const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}/api/monitoring/ws`;

export function useWebSocket(plcId?: string, onMessage?: (msg: WebSocketMessage) => void) {
  const ws = useRef<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const [tagValues, setTagValues] = useState<Record<string, number>>({});
  const onMessageRef = useRef(onMessage);
  onMessageRef.current = onMessage;

  const connect = useCallback(() => {
    if (ws.current?.readyState === WebSocket.OPEN) return;

    const socket = new WebSocket(WS_URL);

    socket.onopen = () => {
      setConnected(true);
      if (plcId) {
        socket.send(JSON.stringify({ action: 'subscribe', plc_id: plcId }));
      }
    };

    socket.onmessage = (event) => {
      try {
        const msg: WebSocketMessage = JSON.parse(event.data);
        setLastMessage(msg);

        if (msg.type === 'tag_values' && msg.data) {
          setTagValues(prev => {
            const updated = { ...prev };
            msg.data.forEach((t: any) => {
              updated[t.tag_name] = t.tag_value;
            });
            return updated;
          });
        }

        if (onMessageRef.current) {
          onMessageRef.current(msg);
        }
      } catch (e) {
        console.error('WebSocket parse error:', e);
      }
    };

    socket.onclose = () => {
      setConnected(false);
    };

    socket.onerror = (err) => {
      console.error('WebSocket error:', err);
      setConnected(false);
    };

    ws.current = socket;
  }, [plcId]);

  const disconnect = useCallback(() => {
    if (ws.current) {
      if (plcId && ws.current.readyState === WebSocket.OPEN) {
        ws.current.send(JSON.stringify({ action: 'unsubscribe', plc_id: plcId }));
      }
      ws.current.close();
      ws.current = null;
      setConnected(false);
    }
  }, [plcId]);

  const subscribe = useCallback((id: string) => {
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({ action: 'subscribe', plc_id: id }));
    }
  }, []);

  const unsubscribe = useCallback((id: string) => {
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({ action: 'unsubscribe', plc_id: id }));
    }
  }, []);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  return { connected, lastMessage, tagValues, subscribe, unsubscribe, connect, disconnect };
}
