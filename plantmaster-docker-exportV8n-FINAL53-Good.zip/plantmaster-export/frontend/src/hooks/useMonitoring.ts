import { useQuery } from '@tanstack/react-query';
import { monitoringApi } from '@/services/api';

export function useTagTrend(plcId: string, tagName: string, hours = 24, bucket = '1 minute') {
  return useQuery({
    queryKey: ['tag-trend', plcId, tagName, hours, bucket],
    queryFn: () => monitoringApi.tagTrend(plcId, tagName, hours, bucket),
    enabled: !!plcId && !!tagName,
  });
}

export function useCurrentTags(plcId: string) {
  return useQuery({
    queryKey: ['current-tags', plcId],
    queryFn: () => monitoringApi.currentTags(plcId),
    refetchInterval: 5000,
    enabled: !!plcId,
  });
}

export function useAlarms(plcId?: string) {
  return useQuery({
    queryKey: ['alarms', plcId],
    queryFn: () => monitoringApi.alarms(plcId),
    refetchInterval: 10000,
  });
}

export function useDownloadHistory(recipeId?: string, plcId?: string) {
  return useQuery({
    queryKey: ['download-history', recipeId, plcId],
    queryFn: () => monitoringApi.downloads(recipeId, plcId, 24),
  });
}
