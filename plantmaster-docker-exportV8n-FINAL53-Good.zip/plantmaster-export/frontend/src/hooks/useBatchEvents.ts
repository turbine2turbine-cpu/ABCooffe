import { useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useWebSocket } from './useWebSocket';
import type { WebSocketMessage } from '@/types';

/**
 * Hook to listen for batch completion events via WebSocket
 * and automatically invalidate related queries for instant UI refresh.
 */
export function useBatchEvents(plcId?: string) {
  const queryClient = useQueryClient();

  const handleMessage = useCallback((msg: WebSocketMessage) => {
    if (msg.type === 'batch_completed') {
      console.log('[BatchEvents] Batch completed:', msg.po_number, 'on', msg.plc_id);

      // Invalidate all order-related queries
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['order-po', msg.po_number] });
      queryClient.invalidateQueries({ queryKey: ['order', msg.order_id] });

      // Invalidate PLC status queries for the specific PLC
      if (msg.plc_id) {
        queryClient.invalidateQueries({ queryKey: ['plc-status', msg.plc_id] });
        queryClient.invalidateQueries({ queryKey: ['batch-status', msg.plc_id] });
      }

      // Also invalidate all batch-status and plc-status queries (global refresh)
      queryClient.invalidateQueries({ queryKey: ['batch-status'] });
      queryClient.invalidateQueries({ queryKey: ['plc-status'] });

      // Invalidate download status
      queryClient.invalidateQueries({ queryKey: ['download-status'] });

      // Force immediate refetch for the most critical queries
      queryClient.refetchQueries({ queryKey: ['orders'], exact: false });
      if (msg.plc_id) {
        queryClient.refetchQueries({ queryKey: ['batch-status', msg.plc_id] });
        queryClient.refetchQueries({ queryKey: ['plc-status', msg.plc_id] });
      }
    }
  }, [queryClient]);

  const { connected, lastMessage } = useWebSocket(plcId, handleMessage);

  return { connected, lastMessage };
}
