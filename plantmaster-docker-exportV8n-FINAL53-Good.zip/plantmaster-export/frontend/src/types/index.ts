export interface Recipe {
  id: string;
  recipe_code: string;
  recipe_name: string;
  product_id: string | null;
  version: number;
  is_active: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  parameters?: RecipeParameter[];
}

export interface RecipeParameter {
  id?: string;
  param_name: string;
  param_type: 'INT' | 'REAL' | 'DINT' | 'BOOL' | 'STRING';
  value_default: number | string | boolean | null;
  value_min?: number | null;
  value_max?: number | null;
  plc_tag: string;
  unit?: string | null;
  sort_order: number;
}

export interface DownloadRequest {
  recipe_id: string;
  plc_id: string;
  validate: boolean;
  backup_current: boolean;
  user: string;
}

export interface DownloadStatus {
  transaction_id: string;
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'NOT_FOUND';
  message?: string;
  duration_ms?: number;
  verified?: boolean;
  tags_written?: number;
  po_number?: string;
  order_id?: string;
}

export interface RecipeCreate {
  recipe_code: string;
  recipe_name: string;
  product_id?: string;
  parameters?: RecipeParameter[];
  created_by?: string;
}

export interface RecipeUpdate {
  recipe_name?: string;
  parameters?: RecipeParameter[];
  is_active?: boolean;
}

export interface PlcTagResult {
  tag: string;
  value: number | string | boolean | null;
  status: string;
  error?: string;
}

export interface PlcStatus {
  plc_id: string;
  is_online: boolean;
  plc_info: Record<string, unknown>;
  active_tags: number;
  unack_alarms: number;
  last_tags: PlcTagResult[];
  running_batch?: {
    po_number: string;
    recipe_code: string;
    quantity: number;
  } | null;
  completed_batches?: number;
}

export interface TagTrendPoint {
  bucket: string;
  avg_value: number;
  min_value: number;
  max_value: number;
  sample_count: number;
}

export interface ProcessEvent {
  time: string;
  event_type: string;
  plc_id: string | null;
  recipe_id: string | null;
  severity: number;
  message: string;
  ack_by: string | null;
}

export interface ValidationResult {
  recipe_id: string;
  recipe_code: string;
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export interface RecipeComparison {
  recipe_id: string;
  plc_id: string;
  matches: number;
  total: number;
  comparisons: Array<{
    param_name: string;
    plc_tag: string;
    recipe_value: unknown;
    plc_value: unknown;
    unit: string | null;
    match: boolean;
    deviation?: number;
  }>;
}


export interface ProductionOrder {
  id: string;
  po_number: string;
  recipe_id: string;
  plc_id: string;
  quantity: number;
  status: 'pending' | 'running' | 'completed' | 'cancelled';
  operator: string | null;
  notes: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
  recipe_name?: string;
  recipe_code?: string;
}

export interface OrderCreate {
  po_number: string;
  recipe_id: string;
  plc_id: string;
  quantity: number;
  operator?: string;
  notes?: string;
}

export interface BatchStatusResponse {
  plc_id: string;
  batch_status: number;
  status_name: string;
  batch_id?: string | null;
  recipe_id?: string | null;
  is_online: boolean;
  can_initialize: boolean;
  can_start: boolean;
  can_hold: boolean;
  can_abort: boolean;
  can_reset: boolean;
  active_batch?: {
    order_id: string;
    po_number: string;
    recipe_id: string;
    status: string;
    started_at?: string;
  } | null;
  plc_available?: boolean;
  timestamp: string;
}

export interface BatchControlResponse {
  plc_id: string;
  command: string;
  previous_status: number;
  current_status: number;
  status_name: string;
  success: boolean;
  message: string;
  timestamp: string;
}

export interface OrderExecution {
  time: string;
  order_id: string;
  po_number: string;
  event_type: string;
  tag_name: string | null;
  tag_value: number | null;
  message: string | null;
}

export interface PlcConfig {
  id: string;
  plc_id: string;
  host: string;
  slot: number;
  timeout: number;
  protocol: string;
  opcua_endpoint: string | null;
  description: string | null;
  is_active: boolean;
  created_at: string;
}

export interface PlcConfigCreate {
  plc_id: string;
  host: string;
  slot?: number;
  timeout?: number;
  protocol?: string;
  opcua_endpoint?: string;
  description?: string;
  is_active?: boolean;
}

export interface WebSocketMessage {
  type: 'connected' | 'subscribed' | 'unsubscribed' | 'tag_values' | 'alarm' | 'batch_status' | 'batch_completed' | 'snapshot' | 'heartbeat' | 'pong' | 'error';
  plc_id?: string;
  data?: any;
  message?: string;
  timestamp?: string;
  po_number?: string;
  order_id?: string;
}

export interface ProductionData {
  id: string;
  order_id: string;
  po_number: string;
  recipe_id?: string;
  plc_id?: string;
  status: string;
  init_at?: string;
  completed_at?: string;
  bean_temp_start?: number;
  bean_temp_end?: number;
  drop_temp?: number;
  charge_temp?: number;
  turnaround_temp?: number;
  ta_temp?: number;
  first_crack_temp?: number;
  exhaust_temp_avg?: number;
  inlet_temp_avg?: number;
  drum_temp_avg?: number;
  roast_time?: number;
  dev_time?: number;
  cool_time?: number;
  drying_phase?: number;
  maillard_phase?: number;
  first_crack_time?: number;
  moisture_loss?: number;
  weight_loss?: number;
  burner_power_avg?: number;
  fan_speed_avg?: number;
  gas_pressure_avg?: number;
  air_flow_avg?: number;
  drum_speed?: number;
  operator?: string;
  notes?: string;
  created_at?: string;
  updated_at?: string;
  recipe_name?: string;
  recipe_code?: string;
}
