import { Link, useLocation } from 'react-router-dom';
import { Coffee, Flame, BookOpen, Thermometer, Activity, Settings, Menu, PanelLeftClose, PanelLeftOpen, User, LogOut, LayoutList, Cpu } from 'lucide-react';
import { useState } from 'react';
import LiveClock from './LiveClock';
import { useAuth } from '@/context/AuthContext';

const navItems = [
  { path: '/orders', label: 'Batches', icon: Flame },
  { path: '/batches', label: 'Batch Details', icon: LayoutList },
  { path: '/recipes', label: 'Profiles', icon: BookOpen },
  { path: '/plc', label: 'Roaster', icon: Thermometer },
  { path: '/monitoring', label: 'Monitoring', icon: Activity },
  { path: '/simulator', label: 'Simulator', icon: Cpu },
  { path: '/plc-configs', label: 'PLC Config', icon: Settings },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();

  const sidebarBase = "fixed inset-y-0 left-0 z-50 bg-amber-950 text-white transition-all duration-300 flex flex-col ";
  const sidebarMobile = sidebarOpen ? "translate-x-0 " : "-translate-x-full ";
  const sidebarDesktop = "md:translate-x-0 md:static ";
  const sidebarWidth = collapsed ? "md:w-16 " : "md:w-60 ";
  const sidebarClass = sidebarBase + sidebarMobile + sidebarDesktop + sidebarWidth + "w-60";

  return (
    <div className="min-h-screen bg-stone-50 flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={sidebarClass}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-4 border-b border-amber-900 h-16 overflow-hidden">
          <Coffee className="w-6 h-6 text-amber-400 shrink-0" />
          <span className={"font-bold text-lg whitespace-nowrap transition-opacity duration-300 " + (collapsed ? "opacity-0 w-0 hidden" : "opacity-100")}>
            CoffeeMaster
          </span>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = location.pathname.startsWith(item.path);
            const navBase = "flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition-all ";
            const navActive = active ? "bg-amber-700 text-white " : "text-amber-200 hover:bg-amber-900 hover:text-white ";
            const navCollapsed = collapsed ? "justify-center" : "";
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={navBase + navActive + navCollapsed}
                title={collapsed ? item.label : undefined}
              >
                <Icon className="w-5 h-5 shrink-0" />
                <span className={"whitespace-nowrap transition-all duration-300 " + (collapsed ? "opacity-0 w-0 hidden" : "opacity-100")}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </nav>

        {/* User info at bottom */}
        <div className="border-t border-amber-900 p-3">
          <div className={"flex items-center gap-3 " + (collapsed ? "justify-center" : "")}>
            <div className="w-8 h-8 rounded-full bg-amber-600 flex items-center justify-center shrink-0">
              <User className="w-4 h-4 text-white" />
            </div>
            <div className={"overflow-hidden transition-all duration-300 " + (collapsed ? "opacity-0 w-0 hidden" : "opacity-100")}>
              <p className="text-sm font-medium truncate">{user?.displayName || "Guest"}</p>
              <p className="text-xs text-amber-300 truncate">{user?.role}</p>
            </div>
            {!collapsed && (
              <button
                onClick={logout}
                className="ml-auto p-1.5 rounded hover:bg-amber-900 text-amber-300 hover:text-white transition-colors"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Header */}
        <header className="bg-white border-b border-stone-200 px-4 py-3 flex items-center justify-between sticky top-0 z-30 h-16">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="md:hidden p-2 hover:bg-stone-100 rounded-lg"
            >
              <Menu className="w-5 h-5" />
            </button>
            {/* Sidebar toggle - moved to header */}
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="hidden md:flex p-2 hover:bg-stone-100 rounded-lg text-stone-600 transition-colors"
              title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {collapsed ? (
                <PanelLeftOpen className="w-5 h-5" />
              ) : (
                <PanelLeftClose className="w-5 h-5" />
              )}
            </button>
            <h1 className="text-lg font-semibold text-stone-800 hidden sm:block">
              Coffee Bean Roasting Manager
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <LiveClock />
            <div className="hidden md:flex items-center gap-2 pl-3 border-l border-stone-200">
              <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">
                <User className="w-4 h-4 text-amber-700" />
              </div>
              <div className="text-sm">
                <p className="font-medium text-stone-800">{user?.displayName || "Guest"}</p>
                <p className="text-xs text-stone-500">{user?.role}</p>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-6 overflow-auto">{children}</main>
      </div>
    </div>
  );
}
