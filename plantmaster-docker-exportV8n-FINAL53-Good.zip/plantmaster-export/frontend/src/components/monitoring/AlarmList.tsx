import { useAlarms } from '@/hooks/useMonitoring';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import Badge from '@/components/ui/Badge';
import { AlertTriangle, Bell } from 'lucide-react';
import { formatDate, severityColor } from '@/lib/utils';

export default function AlarmList() {
  const { data: alarms, isLoading } = useAlarms();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Bell className="w-4 h-4 text-orange-500" />
          Active Alerts
          {alarms && alarms.length > 0 && (
            <Badge variant="error">{alarms.length}</Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center text-stone-400 py-8">Loading...</div>
        ) : !alarms?.length ? (
          <div className="text-center text-stone-400 py-8 flex flex-col items-center gap-2">
            <AlertTriangle className="w-8 h-8 text-green-400" />
            <p>No active alerts</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-80 overflow-auto">
            {alarms.map((alarm: any, i: number) => (
              <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-stone-50 border border-stone-200">
                <span className={"px-2 py-0.5 rounded text-xs font-bold " + severityColor(alarm.severity)}>
                  S{alarm.severity}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{alarm.message}</p>
                  <div className="flex gap-2 text-xs text-stone-500 mt-1">
                    <span>{alarm.plc_id}</span>
                    <span>•</span>
                    <span>{formatDate(alarm.time)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
