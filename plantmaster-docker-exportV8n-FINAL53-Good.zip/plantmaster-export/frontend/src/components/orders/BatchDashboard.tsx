import { useState, useEffect } from 'react';
import { useBatchStatus, usePlcTagValues } from '@/hooks/usePlc';
import { Card } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import {
  Play, Pause, Square, RotateCcw, Activity, Thermometer, Wind, Zap,
  Gauge, Timer, Coffee, CheckCircle, AlertTriangle, TrendingUp,
  ChevronRight, Package, Hash, FileText
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { ConfirmDialog } from '@/components/ui/Dialog';

const BATCH_STATE_NAMES: Record<number, string> = {
  0: 'IDLE', 1: 'INITIALIZING', 2: 'READY', 3: 'RUNNING',
  4: 'HOLDING', 5: 'HELD', 6: 'ABORTING', 7: 'ABORTED',
  8: 'COMPLETING', 9: 'COMPLETED',
};

interface BatchDashboardProps {
  order: any;
  recipe: any;
  plcId: string;
  onStart: () => void;
  onHold: () => void;
  onAbort: () => void;
  onReset: () => void;
  onInit: () => void;
  isBusy: boolean;
}

/* ─── helpers ─── */
function fmt3(val: unknown): string {
  if (val === null || val === undefined) return '--';
  const n = Number(val);
  if (Number.isNaN(n)) return String(val);
  return n.toFixed(3);
}

function tagVal(results: any[], tag: string): number | null {
  const r = results.find((x: any) => x.tag === tag);
  return r && r.value !== null ? Number(r.value) : null;
}

/* ─── sparkline (simple SVG) ─── */
function Sparkline({ data, color = '#0ea5e9', width = 120, height = 40 }: { data: number[]; color?: string; width?: number; height?: number }) {
  if (!data.length) return <div className="h-10" />;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1 || 1)) * width;
    const y = height - ((v - min) / range) * height;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={width} height={height} className="overflow-visible">
      <polyline points={pts} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ─── KPI Card ─── */
function KpiCard({
  label, value, unit, icon: Icon, color, sparkData
}: {
  label: string; value: string; unit: string; icon: any; color: string; sparkData: number[];
}) {
  return (
    <Card className="p-4 flex flex-col justify-between min-h-[140px]">
      <div className="flex items-start justify-between">
        <span className="text-xs font-medium text-stone-500 uppercase tracking-wide">{label}</span>
        <Icon className="w-4 h-4" style={{ color }} />
      </div>
      <div className="mt-2">
        <span className="text-3xl font-bold" style={{ color }}>{value}</span>
        <span className="text-sm text-stone-400 ml-1">{unit}</span>
      </div>
      <div className="mt-auto pt-2">
        <Sparkline data={sparkData} color={color} />
      </div>
    </Card>
  );
}

/* ─── Circular Gauge ─── */
function CircularGauge({ value, label, subLabel }: { value: number; label: string; subLabel?: string }) {
  const data = [
    { name: 'done', value: Math.min(value, 100) },
    { name: 'remaining', value: Math.max(100 - value, 0) },
  ];
  const COLORS = ['#0ea5e9', '#e5e7eb'];

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-40 h-40">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={55}
              outerRadius={70}
              startAngle={90}
              endAngle={-270}
              dataKey="value"
              stroke="none"
            >
              {data.map((_, i) => (
                <Cell key={i} fill={COLORS[i]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-stone-800">{value.toFixed(1)}%</span>
          {subLabel && <span className="text-xs text-stone-400">{subLabel}</span>}
        </div>
      </div>
      <span className="text-sm font-medium text-stone-600 mt-1">{label}</span>
    </div>
  );
}

/* ─── main dashboard ─── */
export default function BatchDashboard({
  order, recipe, plcId, onStart, onHold, onAbort, onReset, onInit, isBusy
}: BatchDashboardProps) {
  const { data: batchStatus } = useBatchStatus(plcId);
  const tagNames = recipe?.parameters ? recipe.parameters.map((p: any) => p.plc_tag).filter(Boolean) : [];
  const { data: tagValuesData } = usePlcTagValues(plcId, tagNames);

  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingCmd, setPendingCmd] = useState<string | null>(null);
  const [sparkHistory, setSparkHistory] = useState<Record<string, number[]>>({});

  /* collect sparkline history */
  useEffect(() => {
    if (!tagValuesData?.results) return;
    setSparkHistory(prev => {
      const next = { ...prev };
      tagValuesData.results.forEach((r: any) => {
        const v = Number(r.value);
        if (!Number.isNaN(v)) {
          const arr = next[r.tag] ? [...next[r.tag], v] : [v];
          next[r.tag] = arr.slice(-20);
        }
      });
      return next;
    });
  }, [tagValuesData]);

  const results = tagValuesData?.results || [];

  /* KPI values */
  const beanTemp = tagVal(results, 'RoasterA.BeanTemp');
  const burnerPower = tagVal(results, 'RoasterA.BurnerPower');
  const airFlow = tagVal(results, 'RoasterA.AirFlow');
  const drumSpeed = tagVal(results, 'RoasterA.DrumSpeed');
  const chargeTemp = tagVal(results, 'RoasterA.ChargeTemp');
  const devRatio = tagVal(results, 'RoasterA.DevelopmentRatio');

  /* other params */
  const beanTempStart = tagVal(results, 'RoasterA.BeanTempStart');
  const beanTempEnd = tagVal(results, 'RoasterA.BeanTempEnd');
  const coolTime = tagVal(results, 'RoasterA.CoolTime');
  const devTime = tagVal(results, 'RoasterA.DevTime');
  const batchSize = tagVal(results, 'RoasterA.BatchSize');

  /* progress (mock from state or time) */
  const bs = batchStatus?.batch_status;
  const progress = bs === 3 ? 72.8 : bs === 9 ? 100 : 0;

  const isThisBatch = batchStatus?.batch_id === order?.po_number;
  const canInit = batchStatus?.can_initialize;

  const handleCmd = (cmd: string) => {
    if (cmd === 'abort' || cmd === 'reset') {
      setPendingCmd(cmd);
      setConfirmOpen(true);
      return;
    }
    if (cmd === 'start') onStart();
    if (cmd === 'hold') onHold();
  };

  const handleConfirm = () => {
    if (pendingCmd === 'abort') onAbort();
    if (pendingCmd === 'reset') onReset();
    setConfirmOpen(false);
    setPendingCmd(null);
  };

  const confirmCfg: Record<string, { title: string; desc: string; btn: string }> = {
    abort: { title: 'Abort Batch?', desc: 'This will immediately stop the current batch and discard progress.', btn: 'Abort Batch' },
    reset: { title: 'Reset Batch?', desc: 'This will reset the batch state machine to IDLE.', btn: 'Reset' },
  };
  const cfg = pendingCmd ? confirmCfg[pendingCmd] : null;

  return (
    <div className="space-y-6 w-full">
      {/* ── TOP KPI ROW ── */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <KpiCard label="Bean Temp" value={fmt3(beanTemp)} unit="°C" icon={Thermometer} color="#0ea5e9" sparkData={sparkHistory['RoasterA.BeanTemp'] || []} />
        <KpiCard label="Burner Power" value={fmt3(burnerPower)} unit="%" icon={Zap} color="#f59e0b" sparkData={sparkHistory['RoasterA.BurnerPower'] || []} />
        <KpiCard label="Air Flow" value={fmt3(airFlow)} unit="m³/h" icon={Wind} color="#10b981" sparkData={sparkHistory['RoasterA.AirFlow'] || []} />
        <KpiCard label="Drum Speed" value={fmt3(drumSpeed)} unit="rpm" icon={Gauge} color="#8b5cf6" sparkData={sparkHistory['RoasterA.DrumSpeed'] || []} />
        <KpiCard label="Charge Temp" value={fmt3(chargeTemp)} unit="°C" icon={Thermometer} color="#ef4444" sparkData={sparkHistory['RoasterA.ChargeTemp'] || []} />
        <KpiCard label="Dev Ratio" value={fmt3(devRatio)} unit="%" icon={TrendingUp} color="#06b6d4" sparkData={sparkHistory['RoasterA.DevelopmentRatio'] || []} />
      </div>

      {/* ── MIDDLE SECTION ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT: Batch / Order Info */}
        <Card className="p-6">
          <h3 className="text-sm font-bold text-stone-700 mb-4 flex items-center gap-2">
            <Coffee className="w-4 h-4" />
            Production Status
          </h3>

          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg font-bold text-sky-700">{order?.po_number}</span>
            <Badge variant={order?.status === 'running' ? 'success' : order?.status === 'pending' ? 'warning' : 'default'}>
              {order?.status?.toUpperCase()}
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm mb-4">
            <div>
              <p className="text-stone-400 text-xs">Recipe</p>
              <p className="font-medium text-stone-700">{recipe?.recipe_code || '--'}</p>
            </div>
            <div>
              <p className="text-stone-400 text-xs">Product</p>
              <p className="font-medium text-stone-700">{recipe?.product_name || '--'}</p>
            </div>
            <div>
              <p className="text-stone-400 text-xs">Batch Size</p>
              <p className="font-medium text-stone-700">{fmt3(batchSize)} kg</p>
            </div>
            <div>
              <p className="text-stone-400 text-xs">Weight</p>
              <p className="font-medium text-stone-700">{order?.weight_kg || '--'} kg</p>
            </div>
          </div>

          {/* Status indicators */}
          <div className="space-y-2">
            <div className="flex items-center justify-between bg-green-50 rounded-lg px-3 py-2">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium text-green-700">Running</span>
              </div>
              <Badge variant="success" className="text-xs">GOOD</Badge>
            </div>
            <div className="flex items-center justify-between bg-red-50 rounded-lg px-3 py-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                <span className="text-sm font-medium text-red-700">Alarms</span>
              </div>
              <Badge variant="error" className="text-xs">0</Badge>
            </div>
          </div>

          {/* Batch Control Buttons */}
          <div className="mt-4 pt-4 border-t border-stone-100">
            <h4 className="text-xs font-medium text-stone-500 mb-2 flex items-center gap-1">
              <Activity className="w-3 h-3" />
              Batch Control
            </h4>
            {isThisBatch ? (
              <div className="grid grid-cols-4 gap-2">
                <Button size="sm" onClick={() => handleCmd('start')} disabled={!batchStatus?.can_start || isBusy} className={batchStatus?.can_start ? 'bg-green-600 hover:bg-green-700 text-white' : ''}>
                  {isBusy ? <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Play className="w-3 h-3" />}
                  Start
                </Button>
                <Button size="sm" onClick={() => handleCmd('hold')} disabled={!batchStatus?.can_hold || isBusy} className={batchStatus?.can_hold ? 'bg-amber-500 hover:bg-amber-600 text-white' : ''}>
                  {isBusy ? <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Pause className="w-3 h-3" />}
                  Hold
                </Button>
                <Button size="sm" onClick={() => handleCmd('abort')} disabled={!batchStatus?.can_abort || isBusy} className={batchStatus?.can_abort ? 'bg-red-600 hover:bg-red-700 text-white' : ''}>
                  {isBusy ? <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Square className="w-3 h-3" />}
                  Abort
                </Button>
                <Button size="sm" onClick={() => handleCmd('reset')} disabled={!batchStatus?.can_reset || isBusy} className={batchStatus?.can_reset ? 'bg-gray-500 hover:bg-gray-600 text-white' : ''}>
                  {isBusy ? <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <RotateCcw className="w-3 h-3" />}
                  Reset
                </Button>
              </div>
            ) : canInit ? (
              <Button size="sm" onClick={onInit} disabled={isBusy} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                {isBusy ? <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" /> : <Play className="w-3 h-3 mr-2" />}
                Initialize Batch to PLC
              </Button>
            ) : (
              <p className="text-xs text-stone-400">PLC busy with another batch.</p>
            )}
          </div>
        </Card>

        {/* CENTER: Gauge */}
        <Card className="p-6 flex flex-col items-center justify-center">
          <h3 className="text-sm font-bold text-stone-700 mb-6 self-start flex items-center gap-2">
            <Gauge className="w-4 h-4" />
            Roasting Progress
          </h3>
          <CircularGauge value={progress} label="Batch Progress" subLabel={BATCH_STATE_NAMES[bs ?? 0] || 'IDLE'} />
          <div className="mt-6 grid grid-cols-2 gap-4 w-full">
            <div className="text-center">
              <p className="text-2xl font-bold text-stone-800">{fmt3(beanTempStart)}</p>
              <p className="text-xs text-stone-400">Start Temp (°C)</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-stone-800">{fmt3(beanTempEnd)}</p>
              <p className="text-xs text-stone-400">End Temp (°C)</p>
            </div>
          </div>
        </Card>

        {/* RIGHT: Other Parameters */}
        <Card className="p-6">
          <h3 className="text-sm font-bold text-stone-700 mb-4">Other Parameters</h3>
          <div className="grid grid-cols-2 gap-4">
            <ParamBox label="Bean Temp Start" value={fmt3(beanTempStart)} unit="°C" />
            <ParamBox label="Bean Temp End" value={fmt3(beanTempEnd)} unit="°C" />
            <ParamBox label="Cool Time" value={fmt3(coolTime)} unit="sec" />
            <ParamBox label="Dev Time" value={fmt3(devTime)} unit="sec" />
            <ParamBox label="Batch Size" value={fmt3(batchSize)} unit="kg" />
            <ParamBox label="Air Flow" value={fmt3(airFlow)} unit="m³/h" />
          </div>

          <div className="mt-4 pt-4 border-t border-stone-100">
            <h4 className="text-xs font-medium text-stone-500 mb-2">PLC Batch State</h4>
            <div className="flex items-center gap-2">
              <Badge variant={batchStatus?.is_online ? 'success' : 'error'}>
                {batchStatus?.is_online ? 'Online' : 'Offline'}
              </Badge>
              <span className="text-sm font-mono font-semibold text-amber-700">
                {BATCH_STATE_NAMES[bs ?? -1] || 'UNKNOWN'}
              </span>
            </div>
            <p className="text-xs text-stone-400 mt-1 font-mono">{batchStatus?.batch_id || '--'}</p>
          </div>
        </Card>
      </div>

      {/* ── BOTTOM: Next Order ── */}
      {order?.next_order && (
        <Card className="p-4">
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2 text-stone-500">
              <Package className="w-4 h-4" />
              <span className="font-medium">Next Order</span>
            </div>
            <div className="flex items-center gap-2">
              <Hash className="w-3 h-3 text-stone-400" />
              <span className="font-mono font-medium">{order.next_order.po_number}</span>
            </div>
            <div className="flex items-center gap-2">
              <FileText className="w-3 h-3 text-stone-400" />
              <span>{order.next_order.recipe_name}</span>
            </div>
            <div className="flex items-center gap-2">
              <Coffee className="w-3 h-3 text-stone-400" />
              <span>{order.next_order.product_name}</span>
            </div>
            <ChevronRight className="w-4 h-4 text-stone-300 ml-auto" />
          </div>
        </Card>
      )}

      {/* Confirm Dialog */}
      {cfg && (
        <ConfirmDialog
          open={confirmOpen}
          onClose={() => { setConfirmOpen(false); setPendingCmd(null); }}
          onConfirm={handleConfirm}
          title={cfg.title}
          description={cfg.desc}
          confirmText={cfg.btn}
          confirmVariant="destructive"
          isLoading={isBusy}
        />
      )}
    </div>
  );
}

function ParamBox({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="bg-stone-50 rounded-lg p-3">
      <p className="text-xs text-stone-400 mb-1">{label}</p>
      <p className="text-lg font-bold text-stone-800">{value}<span className="text-xs font-normal text-stone-400 ml-1">{unit}</span></p>
    </div>
  );
}
