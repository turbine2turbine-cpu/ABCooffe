import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useOrders, useOrder, useCreateOrder, useUpdateOrder } from '@/hooks/useOrders';
import { useRecipes, useRecipe } from '@/hooks/useRecipes';
import { useBatchStatus, useBatchControl, usePlcStatus, usePlcTagValues } from '@/hooks/usePlc';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Alert from '@/components/ui/Alert';
import {
  Save, ArrowLeft, Loader2, Tag, Activity, Play,
  Pause, Square, RefreshCw, Power
} from 'lucide-react';
import { formatDate, statusColor } from '@/lib/utils';

function fmt3(val: unknown): string {
  if (val === null || val === undefined) return '--';
  const n = Number(val);
  if (Number.isNaN(n)) return String(val);
  return n.toFixed(3);
}

const ROASTER_OPTIONS = [
  { id: 'LINE_A_PLC', name: 'Roaster A' },
  { id: 'LINE_B_PLC', name: 'Roaster B' },
  { id: 'LINE_C_PLC', name: 'Roaster C' },
];

const BATCH_STATE_NAMES: Record<number, string> = {
  0: 'IDLE', 1: 'INITIALIZING', 2: 'READY', 3: 'RUNNING',
  4: 'HOLDING', 5: 'HELD', 6: 'ABORTING', 7: 'ABORTED',
  8: 'COMPLETING', 9: 'COMPLETED',
};

const BATCH_STATE_COLORS: Record<number, string> = {
  0: 'bg-stone-100 text-stone-600', 1: 'bg-blue-100 text-blue-700',
  2: 'bg-cyan-100 text-cyan-700', 3: 'bg-orange-100 text-orange-700',
  4: 'bg-yellow-100 text-yellow-700', 5: 'bg-amber-100 text-amber-700',
  6: 'bg-red-100 text-red-700', 7: 'bg-red-50 text-red-500',
  8: 'bg-green-100 text-green-700', 9: 'bg-green-50 text-green-600',
};

export default function OrderEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isNew = !id;
  const { data: existing, isLoading: isLoadingOrder, error: orderError } = useOrder(id || '');
  const { data: recipes, isLoading: isLoadingRecipes, error: recipesError } = useRecipes();
  const { data: allOrders } = useOrders();
  const createMutation = useCreateOrder();
  const updateMutation = useUpdateOrder();
  const { data: recipeDetail } = useRecipe(existing?.recipe_id || '');
  const { data: batchStatus } = useBatchStatus(existing?.plc_id || '');
  const { data: plcData } = usePlcStatus(existing?.plc_id || '');
  const controlMutation = useBatchControl();
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [loadingControl, setLoadingControl] = useState(false);

  /* Keep tag values in memory — merge new readings, never clear */
  const [tagMemory, setTagMemory] = useState<Record<string, number>>({});

  const runningPlcs = new Set(allOrders?.filter((o: any) => o.status === 'running').map((o: any) => o.plc_id) || []);

  const [poNumber, setPoNumber] = useState('');
  const [recipeId, setRecipeId] = useState('');
  const [plcId, setPlcId] = useState('LINE_A_PLC');
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (isNew && !poNumber) {
      const year = new Date().getFullYear();
      const random = Math.floor(Math.random() * 900) + 100;
      setPoNumber(`BTH-${year}-${random}`);
    }
  }, [isNew]);

  useEffect(() => {
    if (existing) {
      setPoNumber(existing.po_number || '');
      setRecipeId(existing.recipe_id || '');
      setPlcId(existing.plc_id || 'LINE_A_PLC');
      setQuantity(existing.quantity || 1);
      setNotes(existing.notes || '');
    }
  }, [existing]);

  // Auto-read recipe parameter tags from PLC every 3 seconds
  const tagNames = !isNew && recipeDetail?.parameters
    ? recipeDetail.parameters.map((p: any) => p.plc_tag).filter(Boolean)
    : [];
  const { data: tagValuesData } = usePlcTagValues(existing?.plc_id || '', tagNames);

  useEffect(() => {
    if (tagValuesData) {
      setLastUpdated(new Date().toLocaleTimeString());
      setTagMemory(prev => {
        const next = { ...prev };
        tagValuesData.results?.forEach((r: any) => {
          if (r.value !== null && r.value !== undefined) {
            const v = Number(r.value);
            if (!Number.isNaN(v)) next[r.tag] = v;
          }
        });
        return next;
      });
    }
  }, [tagValuesData]);

  const validate = (): boolean => {
    const errors: Record<string, string> = {};
    if (!poNumber.trim()) errors.poNumber = 'Batch number is required';
    if (!recipeId) errors.recipeId = 'Please select a roasting profile';
    if (!plcId) errors.plcId = 'Please select a target roaster';
    if (!quantity || quantity <= 0) errors.quantity = 'Weight must be greater than 0';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!validate()) return;

    try {
      await createMutation.mutateAsync({
        po_number: poNumber,
        recipe_id: recipeId,
        plc_id: plcId,
        quantity,
        notes,
      });
      navigate('/orders', { replace: true });
    } catch (e: any) {
      console.error('Create batch error:', e);
      const message = e?.response?.data?.detail || e?.message || 'Failed to create batch. Please try again.';
      setError(message);
    }
  };

  const handleInit = async () => {
    if (!existing?.plc_id || !existing?.recipe_id) return;
    setError(''); setLoadingControl(true);
    try {
      await controlMutation.mutateAsync({
        plcId: existing.plc_id,
        command: 'initialize',
        data: {
          recipe_id: existing.recipe_id,
          po_number: existing.po_number,
          order_id: existing.id,
        }
      });
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Init failed');
    } finally { setLoadingControl(false); }
  };

  const handleStart = async () => {
    if (!id || !existing?.plc_id) return;
    setError(''); setLoadingControl(true);
    try {
      await controlMutation.mutateAsync({
        plcId: existing.plc_id,
        command: 'start',
        data: {
          po_number: existing.po_number,
          order_id: existing.id,
        }
      });
      await updateMutation.mutateAsync({ id, data: { status: 'running' } });
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Start failed');
    } finally { setLoadingControl(false); }
  };

  const handleHold = async () => {
    if (!existing?.plc_id) return;
    setError(''); setLoadingControl(true);
    try {
      await controlMutation.mutateAsync({ plcId: existing.plc_id, command: 'hold' });
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Hold failed');
    } finally { setLoadingControl(false); }
  };

  const handleAbort = async () => {
    if (!confirm('Abort current batch? This cannot be undone.')) return;
    if (!existing?.plc_id) return;
    setError(''); setLoadingControl(true);
    try {
      await controlMutation.mutateAsync({ plcId: existing.plc_id, command: 'abort' });
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Abort failed');
    } finally { setLoadingControl(false); }
  };

  const handleReset = async () => {
    if (!confirm('Reset batch state? This will clear the current batch from PLC.')) return;
    if (!existing?.plc_id) return;
    setError(''); setLoadingControl(true);
    try {
      await controlMutation.mutateAsync({ plcId: existing.plc_id, command: 'reset' });
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Reset failed');
    } finally { setLoadingControl(false); }
  };

  const isBusy = loadingControl || controlMutation.isPending || updateMutation.isPending;

  if (!isNew && isLoadingOrder) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-amber-600" />
        <span className="ml-3 text-stone-600">Loading batch details...</span>
      </div>
    );
  }

  if (!isNew && orderError) {
    return (
      <div className="space-y-6 max-w-3xl">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/orders')}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h2 className="text-xl font-bold">Error</h2>
        </div>
        <Alert variant="error">
          Failed to load batch details. {(orderError as any)?.message || 'Please try again.'}
        </Alert>
        <Button onClick={() => navigate('/orders')}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Batches
        </Button>
      </div>
    );
  }

  const batchState = batchStatus?.batch_status ?? 0;
  const batchStateName = BATCH_STATE_NAMES[batchState] || 'UNKNOWN';
  const batchStateColor = BATCH_STATE_COLORS[batchState] || 'bg-stone-100 text-stone-600';

  return (
    <div className="space-y-6 w-full">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={() => navigate('/orders')}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <h2 className="text-xl font-bold">{isNew ? 'New Roasting Batch' : 'Batch Details'}</h2>
        {existing && (
          <span className={"px-2 py-0.5 rounded-full text-xs font-medium " + statusColor(existing.status)}>
            {existing.status}
          </span>
        )}
      </div>

      {error && <Alert variant="error">{error}</Alert>}
      {recipesError && (
        <Alert variant="warning">
          Failed to load recipes. Some features may be limited.
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-stone-200 shadow-sm p-6 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">PO Number / Batch Number</label>
            <Input
              value={poNumber}
              onChange={e => { setPoNumber(e.target.value); setFieldErrors(prev => ({ ...prev, poNumber: '' })); }}
              disabled={!isNew}
              placeholder="e.g. BTH-2026-001 or PO-12345"
              className={fieldErrors.poNumber ? 'border-red-300 focus:border-red-500' : ''}
            />
            <p className="mt-1 text-xs text-stone-400">Format: BTH-YYYY-### or your PO number. This will be written to PLC.</p>
            {fieldErrors.poNumber && <p className="mt-1 text-xs text-red-600">{fieldErrors.poNumber}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Weight (kg)</label>
            <Input
              type="number"
              value={quantity}
              onChange={e => { setQuantity(Number(e.target.value)); setFieldErrors(prev => ({ ...prev, quantity: '' })); }}
              min={0.1}
              step={0.1}
              disabled={!isNew}
              className={fieldErrors.quantity ? 'border-red-300 focus:border-red-500' : ''}
            />
            {fieldErrors.quantity && <p className="mt-1 text-xs text-red-600">{fieldErrors.quantity}</p>}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {!isNew && existing ? (
            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1">Roasting Profile</label>
              <div className="px-3 py-2 bg-stone-50 rounded-md border border-stone-200 text-stone-800">
                {existing.recipe_code} - {existing.recipe_name}
              </div>
              <p className="mt-1 text-xs text-stone-400">This profile will be loaded to PLC when initialized.</p>
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1">Roasting Profile</label>
              <Select 
                value={recipeId} 
                onChange={e => { setRecipeId(e.target.value); setFieldErrors(prev => ({ ...prev, recipeId: '' })); }} 
                disabled={isLoadingRecipes}
                className={fieldErrors.recipeId ? 'border-red-300 focus:border-red-500' : ''}
              >
                <option value="">{isLoadingRecipes ? 'Loading profiles...' : '-- Select Profile --'}</option>
                {recipes?.map((r: any) => (
                  <option key={r.id} value={r.id}>{r.recipe_code} - {r.recipe_name}</option>
                ))}
              </Select>
              {fieldErrors.recipeId && <p className="mt-1 text-xs text-red-600">{fieldErrors.recipeId}</p>}
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Target Roaster</label>
            {isNew ? (
              <Select 
                value={plcId} 
                onChange={e => { setPlcId(e.target.value); setFieldErrors(prev => ({ ...prev, plcId: '' })); }} 
                className={fieldErrors.plcId ? 'border-red-300 focus:border-red-500' : ''}
              >
                {ROASTER_OPTIONS.map(p => {
                  const busy = runningPlcs.has(p.id);
                  return (
                    <option key={p.id} value={p.id} disabled={busy}>
                      {p.name}{busy ? ' (Busy)' : ' (Available)'}
                    </option>
                  );
                })}
              </Select>
            ) : (
              <div className="px-3 py-2 bg-stone-50 rounded-md border border-stone-200 text-stone-800">
                {ROASTER_OPTIONS.find(p => p.id === plcId)?.name || plcId}
              </div>
            )}
            {fieldErrors.plcId && <p className="mt-1 text-xs text-red-600">{fieldErrors.plcId}</p>}
            {runningPlcs.has(plcId) && (
              <p className="text-xs text-red-600 mt-1">This roaster is currently running a batch. Please select another or wait.</p>
            )}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-stone-700 mb-1">Notes</label>
          <Input 
            value={notes} 
            onChange={e => setNotes(e.target.value)} 
            placeholder="Origin notes, bean variety..." 
            disabled={!isNew}
          />
        </div>

        {isNew && (
          <Button type="submit" disabled={createMutation.isPending || isLoadingRecipes} className="w-full">
            {createMutation.isPending ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Creating...</>
            ) : (
              <><Save className="w-4 h-4 mr-2" /> Create Batch</>
            )}
          </Button>
        )}
      </form>

      {/* PLC Batch State */}
      {!isNew && batchStatus && (
        <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6">
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Activity className="w-4 h-4" />
            PLC Batch State
          </h4>
          <div className="flex items-center gap-3 mb-2">
            <span className={`px-3 py-1 rounded-full text-sm font-bold ${batchStateColor}`}>
              {batchStateName} ({batchState})
            </span>
            {batchStatus.is_online ? (
              <span className="text-xs text-green-600 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-green-500 inline-block" /> Online
              </span>
            ) : (
              <span className="text-xs text-red-600 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-red-500 inline-block" /> Offline
              </span>
            )}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs text-stone-500 mt-3">
            <div className="bg-stone-50 rounded px-2 py-1">
              <span className="block text-stone-400">Batch ID</span>
              <span className="font-mono font-medium">{batchStatus.batch_id || '--'}</span>
            </div>
            <div className="bg-stone-50 rounded px-2 py-1">
              <span className="block text-stone-400">Recipe ID</span>
              <span className="font-mono font-medium">{batchStatus.recipe_id || '--'}</span>
            </div>
            <div className="bg-stone-50 rounded px-2 py-1">
              <span className="block text-stone-400">Can Start</span>
              <span className={batchStatus.can_start ? 'text-green-600 font-medium' : 'text-stone-400'}>
                {batchStatus.can_start ? 'Yes' : 'No'}
              </span>
            </div>
            <div className="bg-stone-50 rounded px-2 py-1">
              <span className="block text-stone-400">Can Hold</span>
              <span className={batchStatus.can_hold ? 'text-green-600 font-medium' : 'text-stone-400'}>
                {batchStatus.can_hold ? 'Yes' : 'No'}
              </span>
            </div>
            <div className="bg-stone-50 rounded px-2 py-1">
              <span className="block text-stone-400">Can Reset</span>
              <span className={batchStatus.can_reset ? 'text-green-600 font-medium' : 'text-stone-400'}>
                {batchStatus.can_reset ? 'Yes' : 'No'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Batch Control */}
      {!isNew && (
        <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6 space-y-4">
          <h4 className="font-medium">Batch Control</h4>
          
          {batchStatus ? (() => {
            const isThisBatchInPlc = existing && batchStatus.batch_id === existing.po_number;
            
            if (!isThisBatchInPlc && batchStatus.can_initialize) {
              return (
                <Button
                  size="sm"
                  onClick={handleInit}
                  disabled={isBusy}
                  variant="default"
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {isBusy ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Power className="w-4 h-4 mr-2" />}
                  Initialize Batch to PLC
                </Button>
              );
            }
            
            if (isThisBatchInPlc) {
              return (
                <>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <Button
                      size="sm"
                      onClick={handleStart}
                      disabled={!batchStatus.can_start || isBusy}
                      variant={batchStatus.can_start ? 'default' : 'outline'}
                      className={batchStatus.can_start ? 'bg-green-600 hover:bg-green-700' : ''}
                    >
                      {isBusy ? <Loader2 className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3 mr-1" />}
                      Start
                    </Button>
                    <Button
                      size="sm"
                      onClick={handleHold}
                      disabled={!batchStatus.can_hold || isBusy}
                      variant={batchStatus.can_hold ? 'default' : 'outline'}
                      className={batchStatus.can_hold ? 'bg-amber-600 hover:bg-amber-700' : ''}
                    >
                      {isBusy ? <Loader2 className="w-3 h-3 animate-spin" /> : <Pause className="w-3 h-3 mr-1" />}
                      Hold
                    </Button>
                    <Button
                      size="sm"
                      onClick={handleAbort}
                      disabled={!batchStatus.can_abort || isBusy}
                      className={batchStatus.can_abort ? 'bg-red-600 hover:bg-red-700' : ''}
                      variant={batchStatus.can_abort ? 'default' : 'outline'}
                    >
                      {isBusy ? <Loader2 className="w-3 h-3 animate-spin" /> : <Square className="w-3 h-3 mr-1" />}
                      Abort
                    </Button>
                    <Button
                      size="sm"
                      onClick={handleReset}
                      disabled={!batchStatus.can_reset || isBusy}
                      variant={batchStatus.can_reset ? 'default' : 'outline'}
                      className={batchStatus.can_reset ? 'bg-stone-600 hover:bg-stone-700' : ''}
                    >
                      {isBusy ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3 mr-1" />}
                      Reset
                    </Button>
                  </div>
                  <p className="text-xs text-green-600">
                    This batch is linked to PLC. Ready to control.
                  </p>
                </>
              );
            }
            
            return (
              <div className="text-sm text-stone-500">
                {batchStatus.batch_id ? (
                  <p>Batch <span className="font-mono font-medium">{batchStatus.batch_id}</span> is currently active in PLC.</p>
                ) : (
                  <p>PLC is busy. Please wait for current batch to complete.</p>
                )}
              </div>
            );
          })() : (
            <div className="text-sm text-stone-400">Loading batch control...</div>
          )}
          
          {batchStatus && !batchStatus.is_online && (
            <Alert variant="warning">PLC offline. Commands disabled.</Alert>
          )}
        </div>
      )}

      {/* Profile Parameters */}
      {!isNew && recipeDetail && recipeDetail.parameters && (
        <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6">
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Tag className="w-4 h-4" />
            Profile Parameters to PLC
            <span className="text-xs text-stone-400 font-normal">
              ({recipeDetail.parameters.length} tags)
            </span>
            {lastUpdated && (
              <span className="text-xs text-green-600 ml-auto flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                Live — Last updated: {lastUpdated}
              </span>
            )}
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-stone-50 border-b border-stone-200">
                <tr>
                  <th className="px-3 py-2 text-left font-medium text-stone-600">#</th>
                  <th className="px-3 py-2 text-left font-medium text-stone-600">Parameter</th>
                  <th className="px-3 py-2 text-left font-medium text-stone-600">PLC Tag</th>
                  <th className="px-3 py-2 text-right font-medium text-stone-600">Current</th>
                  <th className="px-3 py-2 text-right font-medium text-stone-600">Default</th>
                  <th className="px-3 py-2 text-right font-medium text-stone-600">Min</th>
                  <th className="px-3 py-2 text-right font-medium text-stone-600">Max</th>
                  <th className="px-3 py-2 text-left font-medium text-stone-600">Unit</th>
                  <th className="px-3 py-2 text-left font-medium text-stone-600">Updated At</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {recipeDetail.parameters.map((param: any, idx: number) => {
                  const currentValue = tagMemory[param.plc_tag] ?? null;
                  return (
                    <tr key={param.id} className="hover:bg-stone-50">
                      <td className="px-3 py-2 text-stone-400">{idx + 1}</td>
                      <td className="px-3 py-2 font-medium text-stone-700">{param.param_name}</td>
                      <td className="px-3 py-2 font-mono text-xs text-amber-700">{param.plc_tag}</td>
                      <td className="px-3 py-2 text-right font-mono font-semibold text-blue-700">
                        {fmt3(currentValue)}
                      </td>
                      <td className="px-3 py-2 text-right font-mono font-semibold text-stone-800">
                        {fmt3(param.value_default)}
                      </td>
                      <td className="px-3 py-2 text-right text-stone-500">
                        {param.value_min ?? '--'}
                      </td>
                      <td className="px-3 py-2 text-right text-stone-500">
                        {param.value_max ?? '--'}
                      </td>
                      <td className="px-3 py-2 text-stone-500 text-xs">{param.unit || '--'}</td>
                      <td className="px-3 py-2 text-stone-400 text-xs font-mono">
                        {lastUpdated || '--'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Batch Timeline */}
      {!isNew && existing && (
        <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-6 space-y-2 text-sm">
          <h4 className="font-medium mb-2">Batch Timeline</h4>
          <div className="flex justify-between text-stone-600">
            <span>Created</span>
            <span>{formatDate(existing.created_at)}</span>
          </div>
          {existing.started_at && (
            <div className="flex justify-between text-stone-600">
              <span>Started</span>
              <span>{formatDate(existing.started_at)}</span>
            </div>
          )}
          {existing.completed_at && (
            <div className="flex justify-between text-stone-600">
              <span>Completed</span>
              <span>{formatDate(existing.completed_at)}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
