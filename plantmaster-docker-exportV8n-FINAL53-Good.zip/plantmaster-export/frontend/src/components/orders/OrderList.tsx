import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useOrders } from '@/hooks/useOrders';
import { useBatchControl, useBatchStatus } from '@/hooks/usePlc';
import Button from '@/components/ui/Button';
import { Plus, FileText, Power, Loader2, AlertCircle } from 'lucide-react';
import { formatDate } from '@/lib/utils';

const BATCH_STATE_NAMES: Record<number, string> = {
  0: 'IDLE', 1: 'INITIALIZING', 2: 'READY', 3: 'RUNNING',
  4: 'HOLDING', 5: 'HELD', 6: 'ABORTING', 7: 'ABORTED',
  8: 'COMPLETING', 9: 'COMPLETED',
};

const BATCH_STATE_COLORS: Record<number, string> = {
  0: 'bg-stone-100 text-stone-600', 1: 'bg-blue-100 text-blue-700',
  2: 'bg-cyan-100 text-cyan-700', 3: 'bg-orange-100 text-orange-700',
  4: 'bg-yellow-100 text-yellow-700', 5: 'bg-amber-100 text-amber-700',
  6: 'bg-red-100 text-red-700', 7: 'bg-red-50 text-red-500',
  8: 'bg-green-100 text-green-700', 9: 'bg-green-50 text-green-600',
};

function OrderRow({ order }: { order: any }) {
  const navigate = useNavigate();
  const { data: batchStatus, isLoading: batchLoading } = useBatchStatus(order.plc_id);
  const batchControl = useBatchControl();
  const [loading, setLoading] = useState(false);

  // PLC state is the primary indicator of whether a roaster is busy
  const plcState = batchStatus?.batch_status ?? 0;
  const isPlcIdle = plcState === 0 || plcState === 7 || plcState === 9; // IDLE, ABORTED, COMPLETED
  
  // BatchID from PLC (or memory fallback from backend)
  const batchIdFromPlc = batchStatus?.batch_id;
  
  // Is THIS batch the one currently loaded into the PLC?
  const isThisBatchInPlc = !!batchIdFromPlc && batchIdFromPlc === order.po_number;
  
  // Interlocked = PLC is busy (not idle/completed/aborted) AND this is NOT the active batch
  const isInterlocked = !isPlcIdle && !isThisBatchInPlc;

  const handleInit = async () => {
    setLoading(true);
    try {
      await batchControl.mutateAsync({
        plcId: order.plc_id,
        command: 'initialize',
        data: { recipe_id: order.recipe_id, po_number: order.po_number, order_id: order.id }
      });
    } finally {
      setLoading(false);
    }
  };

  // Determine batch state display
  // CRITICAL FIX: If DB status is terminal (completed/cancelled), always show DB status
  // regardless of current PLC state. Don't let a new running batch on the same PLC
  // override the display of a completed batch.
  let stateDisplay;
  if (batchLoading) {
    stateDisplay = <span className="text-stone-300 text-xs">...</span>;
  } else if (order.status === 'completed') {
    stateDisplay = (
      <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">
        COMPLETED
      </span>
    );
  } else if (order.status === 'cancelled') {
    stateDisplay = (
      <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-red-50 text-red-500">
        CANCELLED
      </span>
    );
  } else if (isInterlocked) {
    stateDisplay = (
      <div className="flex flex-col items-start">
        <span className="text-stone-400 font-mono text-sm">----</span>
        <span className="text-xs text-red-500 font-medium">Interlocking</span>
      </div>
    );
  } else if (isThisBatchInPlc) {
    // This batch is active in PLC → show PLC state
    const name = BATCH_STATE_NAMES[plcState] || 'UNKNOWN';
    const color = BATCH_STATE_COLORS[plcState] || 'bg-stone-100 text-stone-400';
    stateDisplay = (
      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${color}`}>
        {name}
      </span>
    );
  } else {
    // Not active in PLC → show DB status
    const dbStatus = order.status?.toUpperCase() || 'PENDING';
    const dbColor = order.status === 'pending' ? 'bg-stone-100 text-stone-500' :
                    order.status === 'running' ? 'bg-orange-100 text-orange-700' :
                    'bg-stone-100 text-stone-500';
    stateDisplay = (
      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${dbColor}`}>
        {dbStatus}
      </span>
    );
  }

  // Determine actions
  let actionContent = null;
  if (!isInterlocked) {
    // Can init when PLC is IDLE/COMPLETED/ABORTED
    const canInit = order.status === 'pending' && isPlcIdle;
    const isBusy = loading || batchControl.isPending;

    if (canInit) {
      actionContent = (
        <>
          <Button
            size="sm"
            variant="outline"
            onClick={(e) => { e.stopPropagation(); handleInit(); }}
            disabled={isBusy}
            title="Initialize roaster with this recipe"
            className="text-blue-600 border-blue-200 hover:bg-blue-50"
          >
            {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Power className="w-3 h-3 mr-1" />}
            <span className="hidden sm:inline">Init</span>
          </Button>
          <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); navigate(`/orders/${order.id}`); }} title="View order details">
            <FileText className="w-4 h-4" />
          </Button>
        </>
      );
    } else if (order.status === 'completed' || order.status === 'cancelled') {
      actionContent = (
        <Button
          size="sm"
          variant="outline"
          onClick={(e) => { e.stopPropagation(); navigate(`/production-data/${order.id}`); }}
          className="text-amber-700 border-amber-200 hover:bg-amber-50"
        >
          <FileText className="w-3.5 h-3.5 mr-1" /> Production Data
        </Button>
      );
    } else {
      actionContent = (
        <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); navigate(`/orders/${order.id}`); }} title="View order details">
          <FileText className="w-4 h-4" />
        </Button>
      );
    }
  }

  const isRunning = order.status === 'running' || (isThisBatchInPlc && plcState === 3);

  return (
    <tr
      className={`cursor-pointer ${isRunning ? 'bg-[#4CAF50] hover:bg-[#388E3C]' : 'hover:bg-stone-50'}`}
      onClick={() => navigate(`/orders/${order.id}`)}
    >
      <td className="px-4 py-3 font-mono font-semibold text-amber-700">{order.po_number}</td>
      <td className="px-4 py-3">{order.recipe_code} - {order.recipe_name}</td>
      <td className="px-4 py-3 font-mono text-xs">{order.plc_id}</td>
      <td className="px-4 py-3">{order.quantity} kg</td>
      <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
        {stateDisplay}
      </td>
      <td className="px-4 py-3 text-stone-500">{formatDate(order.created_at)}</td>
      <td className="px-4 py-3">
        <div className="flex justify-end gap-1.5" onClick={e => e.stopPropagation()}>
          {actionContent}
        </div>
      </td>
    </tr>
  );
}

export default function OrderList() {
  const navigate = useNavigate();
  const { data: orders, isLoading, error } = useOrders();
  const [filter, setFilter] = useState('all');

  const filtered = filter === 'all' ? orders : orders?.filter((o: any) => o.status === filter);

  if (isLoading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-8 h-8 animate-spin text-amber-600" />
      <span className="ml-3 text-stone-600">Loading roasting batches...</span>
    </div>
  );

  if (error) return (
    <div className="text-center py-20">
      <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
      <h2 className="text-xl font-bold text-red-700 mb-2">Failed to load batches</h2>
      <p className="text-stone-500 mb-4">{(error as any)?.message || 'Please check your connection and try again.'}</p>
      <Button onClick={() => window.location.reload()}>Retry</Button>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-stone-800">Roasting Batches</h2>
        <Button onClick={() => navigate('/orders/new')}>
          <Plus className="w-4 h-4 mr-2" /> New Batch
        </Button>
      </div>

      <div className="flex gap-2 items-center flex-wrap">
        {['all', 'pending', 'running', 'completed', 'cancelled'].map((s) => {
          const count = s === 'all' ? (orders?.length ?? 0) : (orders?.filter((o: any) => o.status === s).length ?? 0);
          return (
            <button key={s} onClick={() => setFilter(s)}
              className={"px-3 py-1 rounded-full text-sm font-medium capitalize transition-colors " +
                (filter === s ? "bg-amber-900 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200")}>
              {s} <span className="ml-1 opacity-70">({count})</span>
            </button>
          );
        })}
      </div>

      <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-stone-50 border-b border-stone-200">
            <tr>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Batch No.</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Profile</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Roaster</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Weight</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Batch State</th>
              <th className="px-4 py-3 text-left font-medium text-stone-600">Created</th>
              <th className="px-4 py-3 text-right font-medium text-stone-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {filtered?.map((order: any) => (
              <OrderRow key={order.id} order={order} />
            ))}
          </tbody>
        </table>
        {(!filtered || filtered.length === 0) && (
          <div className="text-center py-12 text-stone-500">
            <p className="text-lg mb-2">No batches found</p>
            <p className="text-sm">Create a new batch to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
}
