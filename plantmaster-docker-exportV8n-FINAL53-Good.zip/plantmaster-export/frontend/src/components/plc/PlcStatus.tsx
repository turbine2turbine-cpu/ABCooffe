import { usePlcStatus, useBatchStatus } from '@/hooks/usePlc';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import Badge from '@/components/ui/Badge';
import {
  Thermometer, Wifi, WifiOff, Flame
} from 'lucide-react';

const ROASTER_IDS = ['LINE_A_PLC', 'LINE_B_PLC', 'LINE_C_PLC'];

const STATUS_COLORS: Record<string, string> = {
  IDLE: 'bg-gray-100 text-gray-700',
  INITIALIZING: 'bg-yellow-100 text-yellow-700',
  READY: 'bg-blue-100 text-blue-700',
  RUNNING: 'bg-green-100 text-green-700',
  HOLDING: 'bg-orange-100 text-orange-700',
  HELD: 'bg-orange-100 text-orange-700',
  ABORTING: 'bg-red-100 text-red-700',
  ABORTED: 'bg-red-100 text-red-700',
  COMPLETING: 'bg-purple-100 text-purple-700',
  COMPLETED: 'bg-green-100 text-green-700',
  UNKNOWN: 'bg-gray-100 text-gray-400',
  OFFLINE: 'bg-gray-100 text-gray-400',
};

export default function PlcStatusPanel() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-stone-800">Roaster Status Overview</h2>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {ROASTER_IDS.map(plcId => (
          <PlcCard key={plcId} plcId={plcId} />
        ))}
      </div>
    </div>
  );
}

function PlcCard({ plcId }: { plcId: string }) {
  const { data: plcData, isLoading: plcLoading } = usePlcStatus(plcId);
  const { data: batchData, isLoading: batchLoading } = useBatchStatus(plcId);

  const isLoading = plcLoading || batchLoading;
  const status = batchData;
  const runningBatch = plcData?.running_batch;
  const completedCount = plcData?.completed_batches ?? 0;

  if (isLoading) {
    return (
      <Card className="h-64 animate-pulse bg-stone-100">
        <div />
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Thermometer className="w-4 h-4" />
            {plcId.replace('LINE_', 'Roaster ').replace('_PLC', '')}
          </CardTitle>
          {plcData?.is_online ? (
            <Badge variant="success"><Wifi className="w-3 h-3 mr-1" /> Online</Badge>
          ) : (
            <Badge variant="error"><WifiOff className="w-3 h-3 mr-1" /> Offline</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 text-sm">
          {/* Batch Status */}
          <div className="flex items-center justify-between">
            <span className="text-stone-500">Batch State</span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${STATUS_COLORS[status?.status_name || 'UNKNOWN']}`}>
              {status?.status_name || 'UNKNOWN'}
            </span>
          </div>

          {/* Running Batch Info */}
          {runningBatch ? (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-2">
              <div className="flex items-center gap-2 text-orange-800 font-medium">
                <Flame className="w-4 h-4" />
                <span>{String(runningBatch.po_number || '')}</span>
              </div>
              <div className="text-xs text-orange-600 mt-0.5 ml-6">
                {String(runningBatch.recipe_code || '')} — {String(runningBatch.quantity || '0')} kg
              </div>
            </div>
          ) : (
            <div className="bg-green-50 border border-green-200 rounded-lg p-2">
              <div className="flex items-center gap-2 text-green-800 font-medium">
                <Wifi className="w-4 h-4" />
                <span>Idle — Ready for next batch</span>
              </div>
            </div>
          )}

          {/* Stats */}
          <div className="flex justify-between">
            <span className="text-stone-500">Completed</span>
            <span className="font-medium">{completedCount}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-500">Sensors</span>
            <span className="font-medium">{plcData?.active_tags ?? 0}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone-500">Alarms</span>
            <span className="font-medium">{plcData?.unack_alarms ?? 0}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
