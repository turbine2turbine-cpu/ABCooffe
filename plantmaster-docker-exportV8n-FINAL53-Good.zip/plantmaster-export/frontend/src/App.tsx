import { Routes, Route } from 'react-router-dom';
import Layout from '@/components/layout/Layout';
import ErrorBoundary from '@/components/ui/ErrorBoundary';
import RecipesPage from '@/pages/RecipesPage';
import RecipeEditPage from '@/pages/RecipeEditPage';
import OrdersPage from '@/pages/OrdersPage';
import OrderEditPage from '@/pages/OrderEditPage';
import PlcPage from '@/pages/PlcPage';
import MonitoringPage from '@/pages/MonitoringPage';
import PlcConfigPage from '@/pages/PlcConfigPage';
import BatchesPage from '@/pages/BatchesPage';
import BatchDetailsPage from '@/pages/BatchDetailsPage';
import ProductionDataPage from '@/pages/ProductionDataPage';
import SimulatorPage from '@/pages/SimulatorPage';

function App() {
  return (
    <ErrorBoundary>
      <Layout>
        <Routes>
          <Route path="/" element={<OrdersPage />} />
          <Route path="/orders" element={<OrdersPage />} />
          <Route path="/orders/new" element={<OrderEditPage />} />
          <Route path="/orders/:id" element={<OrderEditPage />} />
          <Route path="/recipes" element={<RecipesPage />} />
          <Route path="/recipes/new" element={<RecipeEditPage />} />
          <Route path="/recipes/:id" element={<RecipeEditPage />} />
          <Route path="/batches" element={<BatchesPage />} />
          <Route path="/batches/:plcId" element={<BatchDetailsPage />} />
          <Route path="/production-data/:orderId" element={<ProductionDataPage />} />
          <Route path="/simulator" element={<SimulatorPage />} />
          <Route path="/plc" element={<PlcPage />} />
          <Route path="/monitoring" element={<MonitoringPage />} />
          <Route path="/plc-configs" element={<PlcConfigPage />} />
          <Route path="*" element={
            <div className="text-center py-20">
              <h2 className="text-2xl font-bold text-stone-800 mb-2">Page Not Found</h2>
              <p className="text-stone-500">The page you are looking for does not exist.</p>
            </div>
          } />
        </Routes>
      </Layout>
    </ErrorBoundary>
  );
}

export default App;
